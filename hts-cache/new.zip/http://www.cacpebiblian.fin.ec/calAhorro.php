<html class="no-js">

    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">

        <meta name="description" content="">
        <meta name="viewport" content="width=device-width">

        <link rel="stylesheet" href="css/bootstrap.min.css">
        <link rel="stylesheet" href="css/bootstrap-responsive.min.css">
        <link rel="stylesheet" href="css/font-awesome.min.css">
        <link rel="stylesheet" href="css/main.css">
        <link rel="stylesheet" href="css/sl-slide.css">

        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
        <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
        <link rel="stylesheet" href="css/social.css">

        <script src="js/vendor/modernizr-2.6.2-respond-1.1.0.min.js"></script>
        <script type="text/javascript" src="js/validar.js"></script>
        <script src="js/vendor/bootstrap.min.js"></script>
        <script src="js/vendor/jquery-1.9.1.min.js"></script>
        <script type="text/javascript" src="js/funciones.js"></script>
        <script type="text/javascript" src="lib/Gruntfile/Gruntfile.js"></script>
        <script type="text/javascript" src="lib/Gruntfile/js/easy-loading.min.js"></script>
        <link rel="stylesheet" href="lib/Gruntfile/css/easy-loading.min.css">
        <script async src="//pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
        <!-- Le fav and touch icons -->
        <link rel="shortcut icon" href="images/ico/icon.ico">
        <link rel="apple-touch-icon-precomposed" sizes="144x144" href="images/ico/apple-touch-icon-144-precomposed.png">
        <link rel="apple-touch-icon-precomposed" sizes="114x114" href="images/ico/apple-touch-icon-114-precomposed.png">
        <link rel="apple-touch-icon-precomposed" sizes="72x72" href="images/ico/apple-touch-icon-72-precomposed.png">
        <link rel="apple-touch-icon-precomposed" href="images/ico/apple-touch-icon-57-precomposed.png">
        <link rel="stylesheet" href="css/img-efect.css">
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
        <script src="js/jquery-3.2.1.min.js"></script>
        <link rel="stylesheet" href="css/progress-bar.css">
        <script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
        <!--carousel-->
        <script src="js/jssor.slider-26.1.5.min.js" type="text/javascript"></script>
        <script>
            $(document).ready(function(){
                //===========FUNCION PARA PONER EL PIE DE PAGINA=============//
                $("#pie").after('<!--Bottom--><section id="bottom" class="main"><!--Container--><div class="container"><!--row-fluids--><div class="row-fluid"><!--Contact Form--><div class="span7"><h4>UBIQUENOS</h4><ul class="unstyled address"><li><i class="icon-home"></i><strong>Dirección:</strong> Mariscal Sucre 3-38 y Daniel Muñoz<br></li><li><i class="icon-envelope"></i><strong>Email: </strong> info@cbcooperativa.fin.ec</li><li><i class="icon-phone"></i><strong>Teléfono:</strong> 072230836</li></ul></div><!--End Contact Form--><!--Important Links--><div id="tweets" class="span5"><h4>&nbsp;NOSOTROS</h4><div class="span3"><ul class="arrow"><li><a href="reconocimientos.php">Información</a></li><li><a href="sucursales.php">Contactos</a></li><li><a href="mensual.php">Transparencia</a></li></ul></div><div class="span6"><ul class="arrow"><li><a href="creditos.php#pricing-table">Productos y Servicios</a></li><li><a href="solitudCredito.php">Solicite su Crédito</a></li></ul></div></div><!--Important Links--></div><!--/row-fluid--></div><!--/container--></section><!--/bottom--><!--Footer--><footer id="footer"><div class="container"><div class="row-fluid"><div class="span5 cp">&copy; 2017 <a target="_blank" href="#" title="Free Twitter Bootstrap WordPress Themes and HTML templates">CB COOPERATIVA </a>. All Rights Reserved.</div><!--/Copyright--><div class="span6"><ul class="social pull-right"><li><a href="#"><i class="icon-facebook"></i></a></li><li><a href="#"><i class="icon-twitter"></i></a></li><li><a href="#"><i class="icon-youtube"></i></a></li><li><a href="#"><i class="icon-instagram"></i></a></li></ul></div><div class="span1"><a id="gototop" class="gototop pull-right" href="#"><i class="icon-angle-up"></i></a></div><!--/Goto Top--></div></div></footer><!--/Footer-->');              
            });
        </script>

   
     <style>    
        .whatsapp {
            position:fixed;
            width:60px;
            height:60px;
            bottom:87px;
            right:25px;
            background-color:#25d366;
            color:#FFF;
            border-radius:50px;
            text-align:center;
            font-size:30px;
            z-index:100;
        }

        .whatsapp-icon {
          margin-top:15px;
        }
        
    </style>        
   
    </head>

    <body oncontextmenu="return false" onload="active();redirigirNot();" style="background-color:rgb(255,255,255)">

        <!--Header-->
        <header class="navbar navbar-fixed-top">
            <div class="navbar-inner">
                <div class="container">
                    <a class="btn btn-navbar" data-toggle="collapse" data-target=".nav-collapse">
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </a>
                    <a id="logo" class="pull-left" href="index.php"></a>
                    <div class="nav-collapse collapse pull-right">
                        <ul class="nav">
                            <li id="liIndex"><a href="index.php">Inicio</a></li>
                            <li class="dropdown" id="liNos">
                                <a href="#" class="dropdown-toggle" data-toggle="dropdown">Nosotros <i class="icon-angle-down"></i></a>
                                <ul class="dropdown-menu">
                                    <li id="liMV"><a href="misionvision.php">Misión y Visión</a></li>
                                    <li id="liRH"><a href="reconocimientos.php">Reseña Histórica</a></li>
                                    <li id="liNot"><a href="noticias.php">Noticias</a></li>
                                </ul>
                            </li>
                            <li id="liPS" class="dropdown">
                                <a href="#" class="dropdown-toggle" data-toggle="dropdown">Productos y Servicios <i class="icon-angle-down"></i></a>
                                <ul class="dropdown-menu">
                                    <li id="liCred" ><a href="creditos.php#pricing-table">Créditos</a></li>
                                    <li id="liPA" ><a href="planesAhorro.php#pricing-table">Planes de Ahorro</a></li>
                                </ul>
                            </li>

                            <li id="liCont" class="dropdown">
                                <a href="#" class="dropdown-toggle" data-toggle="dropdown">Contactos <i class="icon-angle-down"></i></a>
                                <ul class="dropdown-menu">
                                    <li id="liDS"><a href="sucursales.php">Directorio de Sucursales</a></li>
                                    <li id="liDCA"><a href="cajeros.php">Directorio de Cajeros Automáticos</a></li>

                                </ul>
                            </li>

                            <li id="liSim" class="dropdown">
                                <a href="#" class="dropdown-toggle" data-toggle="dropdown">Simuladores <i class="icon-angle-down"></i></a>
                                <ul class="dropdown-menu">
                                    <li id="liCalCred"><a href="calcCredit.php">Calcule su Crédito</a></li>
                                    <li id="liCalAho"><a href="calAhorro.php">Calcule su Ahorro</a></li>
                                </ul>
                            </li>

                            <li id="liSerOnl" class="dropdown">
                                <a href="#" class="dropdown-toggle" data-toggle="dropdown">Servicios Online <i class="icon-angle-down"></i></a>
                                <ul class="dropdown-menu">
                                    <li id="liSolCred"><a href="solitudCredito.php">Solicite su Crédito</a></li>
                                    <li id="liAbCuAq"><a href="abrircuenta.php">Abra su Cuenta Aquí</a></li>
                                </ul>
                            </li>


                            <li id="liTransp" class="dropdown">
                                <a href="#" class="dropdown-toggle" data-toggle="dropdown">Transparencia <i class="icon-angle-down"></i></a>
                                <ul class="dropdown-menu">
                                    <li id="liInfMens"><a href="mensual.php">Informacion Mensual</a></li>
                                    <li id="liInfTrim"><a href="trimestral.php">Informacion Trimestral</a></li>
                                    <li id="liInfTrim"><a href="anual.php">Informacion Anual</a></li>                                    
                                    <li id="liCosFin"><a href="costos.php">Costos Financieros</a></li>
                                    <li id="liCalifi"><a href="calificacion.php">Calificacion</a></li>
                                    <li><a href="resolucion.php">Resolución SEPS-IGT...0320</a></li>
                                </ul>
                            </li>

                            <li class="login">
                                <a data-toggle="modal" href="#loginForm"><i class="icon-lock"></i></a>
                            </li>
                        </ul>
                    </div>
                    <!--/.nav-collapse -->
                </div>
            </div>


        </header>
        <!-- /header -->
        <!-------------------------CHAT------------------------>
       <div style=" position: fixed;right: 90px;   border-color:transparent;bottom: 0; z-index: 3000;width: 350px; height: auto; align-content: right; text-align: right;">
            <button type="button" class="btn btn-lg btn-info collapsed" data-toggle="collapse" data-target="#chat_cliente" style="width: 350px;border-radius:10px;  outline:none; margin:0px; border-color:transparent;">Dejar un mensaje <i class="fa fa-comments" aria-hidden="true"></i></button>
            <div id="chat_cliente" class="collapse" style="width:100%; border: 1px solid #398aa4; border-radius: 7px">
                <div style="background-color: rgba(255,255,255,0.7); color: #444;">
                    <div class="center">
                        <br>
                        <img src="images/chat.png" style="border-radius:25px;" />
                    </div>
                    <table style="text-align: justify; font-size: 12px; margin-left: 20px;">
                        <tr>
                            <td colspan="2" style="color:#000000 ">Para consultas y sugerencias, por favor ingrese sus datos personales y presione enviar. <br>Lo antes posible nuestro personal se comunicará con usted. <strong>Gracias por su mensaje</strong> <b class="text-success">CB Cooperativa LTDA.</b></td>
                        </tr>
                        <tr>
                            <td><strong>Nombres:</strong></td>
                            <td><input name="ms1" id="ms1" type="text" onkeypress="return soloLetras(event)" required style="background:#B4CCDE     ; color:#444;border:1px solid #2A608A "></td>
                        </tr>
                        <tr>
                            <td><strong>Email:</strong></td>
                            <td><input name="ms2" id="ms2" type="email" required onkeypress="return soloCorreo(event)" style="background:#B4CCDE     ; color:#444;border:1px solid #2A608A "></td>
                        </tr>
                        <tr>
                            <td><strong>Tel&eacute;fono:</strong></td>
                            <td><input name="ms3" id="ms3" type="tel" maxlength="10" onkeypress="return soloNumeros(event)" style="background:#B4CCDE     ; color:#444;border:1px solid #2A608A "></td>
                        </tr>
                        <tr>
                            <td><strong>Direcci&oacute;n:</strong></td>
                            <td><input name="ms4" id="ms4" type="text" required onkeypress="return soloValidos(event)" style="background:#B4CCDE     ; color:#444;border:1px solid #2A608A "></td>
                        </tr>
                        <tr>
                            <td><strong>Ciudad:</strong></td>
                            <td><input name="ms5" id="ms5" type="text" required onkeypress="return soloLetras(event)" style="background:#B4CCDE     ; color:#444;border:1px solid #2A608A "></td>
                        </tr>
                        <tr>
                            <td><strong>Tema:</strong></td>
                            <td><input name="ms6" id="ms6" type="text" required onkeypress="return soloLetras(event)" style="background:#B4CCDE     ; color:#444;border:1px solid #2A608A "></td>
                        </tr>
                        <tr>
                            <td><strong>Mensaje:</strong></td>
                            <td><textarea name="ms7" id="ms7" rows="4" required onkeypress="return soloLetras(event)" style="background:#B4CCDE     ; color:#444;border:1px solid #2A608A "></textarea></td>
                        </tr>
                        <tr>
                            <td colspan="2" style="text-align: center"><input style="border-radius:10px;" class="btn zoom inputC" type="button" onclick="validarChat();" value="ENVIAR"></td>
                        </tr>
                        <tr>
                            <td colspan="2"> <br></td>
                        </tr>
                    </table>
                </div>
            </div>
        </div>
        <!-------------------------//CHAT//------------------------>
        <!-------------------------CARTILLA DE ACTUALIZACION------------------------>
        <!--
           <div style=" position: fixed;right: 302px;   border-color:transparent;bottom: 0px; z-index: 3000;width: 350px; height: auto; align-content: right; text-align: center;">
            <button type="button" class="btn btn-lg btn-info collapsed" data-toggle="collapse" data-target="#cart_actual" style="width: 250px;border-radius:10px;  outline:none; margin:0px; border-color:transparent;background: #ffa251" onclick="window.location='cartilla_actualizacion.php'">Cartilla de Actualizacion <i class="fa fa-address-card" aria-hidden="true" ></i></button>            
        </div>
        -->
        <!-------------------------//CARTILLA DE ACTUALIZACION//------------------------>

        <!--REDES SOCIALES-->
        <div class="sociales">
        <ul>
                     
            <li>
                <a href="https://www.facebook.com/cacpebiblian/?fref=ts" target="_blank" class="icon-facebook" title = "Facebook"></a>
            </li>
            <li>
                <a href="https://twitter.com/cacpe_biblian?lang=es" target="_blank" class="icon-twitter" title = "Twitter"></a>
            </li>
            <li>
                <a href="https://www.cosede.gob.ec/informacion-para-entidades-financieras/" target="_blank" class="icon-lock" style= 'background: #edb140' title = "Cosede"></a>
            </li>            
        </ul>
        </div>
        <!--/REDES SOCIALES/-->
      
     
    <!-- Load Facebook SDK for JavaScript -->
<div id="fb-root"></div>
<script>
  window.fbAsyncInit = function() {
    FB.init({
      xfbml            : true,
      version          : 'v3.3'
    });
  };

  (function(d, s, id) {
  var js, fjs = d.getElementsByTagName(s)[0];
  if (d.getElementById(id)) return;
  js = d.createElement(s); js.id = id;
  js.src = 'https://connect.facebook.net/es_ES/sdk/xfbml.customerchat.js';
  fjs.parentNode.insertBefore(js, fjs);
}(document, 'script', 'facebook-jssdk'));</script>

<!-- Your customer chat code -->
<div class="fb-customerchat"
  attribution=setup_tool
  page_id="950390831753046"
  theme_color="#0084ff"
  logged_in_greeting="¡Hola! como podemos ayudarte?"
  logged_out_greeting="¡Hola! como podemos ayudarte?">
</div>
        <a href="http://bit.ly/2UhY0ID" class="whatsapp" target="_blank"> <i class="fa fa-whatsapp whatsapp-icon"></i></a>
<script>
    function active()
    {
        document.getElementById("liSim").className = "dropdown active";
        //document.getElementById("liCalCred").className = "active";
        document.getElementById("liCalAho").className = "active";
    }
    </script>
    <title>Cacpe | Calcule su Crédito</title>

    <section class="title">
        <div class="container">
            <div class="row-fluid">
                <div class="span6">
                    <h1>Calcule Su Ahorro</h1>
                </div>
                <div class="span6">
                    <ul class="breadcrumb pull-right">
                        <li><a href="index.php">Inicio</a> <span class="divider">/</span></li>
                        <li><a href="#">Productos y Servicios</a> <span class="divider">/</span></li>
                        <li class="active">Calcule Su Ahorro</li>
                    </ul>
                </div>
            </div>
        </div>
    </section>
    <!-- / .title -->

    <style>
        .formulario {
            width: 70%;
            align-content: center;
            text-align: center;
            margin: auto;
        }

        .botonForm {
            font-family: Fjalla One;
            width: 100%;
            font-size: 16px;
            border-radius: 7px;
            background: #444;
            color: white;
            padding: 10px 20px 10px 20px;
        }

        .botonForm:hover {
            background: darkgreen;
            position: relative;
            transform: scale3d(1.1, 1.1, 1.5);
        }


        .botonForm1 {
            font-family: Fjalla One;
            width: 100%;
            font-size: 16px;
            border-radius: 7px;
            background: #444;
            color: white;
            padding: 10px 20px 10px 20px;
        }

        .botonForm1:hover {
            background: darkred;
            position: relative;
            transform: scale3d(1.1, 1.1, 1.5);
        }


        .botonForm:active {
            background: darkgreen;
            padding: 13px 23px 13px 23px;
        }



        select {
            width: 100%;
            text-align: center;
            font-size: 15px;
            padding-left: 10px
        }

        select:required:invalid {
            color: gray;
        }

        option[value=""][disabled] {
            display: none;
        }

        option {
            color: black;
            text-align: center;
            font-size: 15px;
            padding-left: 10px
        }

        td {
            text-align: justify;
            align-content: center;
            margin: auto;
            font-size: 14px;
        }

        .tablaScroll {
            overflow: scroll;
            height: 400px;

        }
    </style>
    <section id="faqs" class="container">
        <div class="row-fluid">
            <!--izquierda-->
            <div class="span5">
                <form id="formulario" name="formulario" method="post" action="calAhorro.php">
                    <table width="100%">

                        <tr>
                            <td colspan="2"><strong style="text-align:center; font-size:15px; padding-left:10px;">Monto a Invertir: $</strong>
                                <input name="monto" required pattern="[0-9]{3,6}"  title="Monto mínimo: 100. Tamaño máximo: 100000" style="border-color:#C9D0CC " type="text" class="required" id="monto" size="10"  /><strong style="text-align:center; font-size:15px; padding-left:10px; ">,00</strong></td>
                        </tr>


                        <tr>
                            <td colspan="2">
                                <select class="required" name="plazo" id="plazo" required>
        <option value="" disabled selected>-- Seleccione Plazo --</option>

            <option value="30">30 días</option>
            <option value="31">31 días</option>
            <option value="32">32 días</option>
            <option value="33">33 días</option>
            <option value="34">34 días</option>
            <option value="35">35 días</option>
            <option value="36">36 días</option>
            <option value="37">37 días</option>
            <option value="38">38 días</option>
            <option value="39">39 días</option>
            <option value="40">40 días</option>
            <option value="41">41 días</option>
            <option value="42">42 días</option>
            <option value="43">43 días</option>
            <option value="44">44 días</option>
            <option value="45">45 días</option>
            <option value="46">46 días</option>
            <option value="47">47 días</option>
            <option value="48">48 días</option>
            <option value="49">49 días</option>
            <option value="50">50 días</option>
            <option value="51">51 días</option>
            <option value="52">52 días</option>
            <option value="53">53 días</option>
            <option value="54">54 días</option>
            <option value="55">55 días</option>
            <option value="56">56 días</option>
            <option value="57">57 días</option>
            <option value="58">58 días</option>
            <option value="59">59 días</option>
            <option value="60">60 días</option>
            <option value="61">61 días</option>
            <option value="62">62 días</option>
            <option value="63">63 días</option>
            <option value="64">64 días</option>
            <option value="65">65 días</option>
            <option value="66">66 días</option>
            <option value="67">67 días</option>
            <option value="68">68 días</option>
            <option value="69">69 días</option>
            <option value="70">70 días</option>
            <option value="71">71 días</option>
            <option value="72">72 días</option>
            <option value="73">73 días</option>
            <option value="74">74 días</option>
            <option value="75">75 días</option>
            <option value="76">76 días</option>
            <option value="77">77 días</option>
            <option value="78">78 días</option>
            <option value="79">79 días</option>
            <option value="80">80 días</option>
            <option value="81">81 días</option>
            <option value="82">82 días</option>
            <option value="83">83 días</option>
            <option value="84">84 días</option>
            <option value="85">85 días</option>
            <option value="86">86 días</option>
            <option value="87">87 días</option>
            <option value="88">88 días</option>
            <option value="89">89 días</option>
            <option value="90">90 días</option>
            <option value="91">91 días</option>
            <option value="92">92 días</option>
            <option value="93">93 días</option>
            <option value="94">94 días</option>
            <option value="95">95 días</option>
            <option value="96">96 días</option>
            <option value="97">97 días</option>
            <option value="98">98 días</option>
            <option value="99">99 días</option>
            <option value="100">100 días</option>
            <option value="101">101 días</option>
            <option value="102">102 días</option>
            <option value="103">103 días</option>
            <option value="104">104 días</option>
            <option value="105">105 días</option>
            <option value="106">106 días</option>
            <option value="107">107 días</option>
            <option value="108">108 días</option>
            <option value="109">109 días</option>
            <option value="110">110 días</option>
            <option value="111">111 días</option>
            <option value="112">112 días</option>
            <option value="113">113 días</option>
            <option value="114">114 días</option>
            <option value="115">115 días</option>
            <option value="116">116 días</option>
            <option value="117">117 días</option>
            <option value="118">118 días</option>
            <option value="119">119 días</option>
            <option value="120">120 días</option>
            <option value="121">121 días</option>
            <option value="122">122 días</option>
            <option value="123">123 días</option>
            <option value="124">124 días</option>
            <option value="125">125 días</option>
            <option value="126">126 días</option>
            <option value="127">127 días</option>
            <option value="128">128 días</option>
            <option value="129">129 días</option>
            <option value="130">130 días</option>
            <option value="131">131 días</option>
            <option value="132">132 días</option>
            <option value="133">133 días</option>
            <option value="134">134 días</option>
            <option value="135">135 días</option>
            <option value="136">136 días</option>
            <option value="137">137 días</option>
            <option value="138">138 días</option>
            <option value="139">139 días</option>
            <option value="140">140 días</option>
            <option value="141">141 días</option>
            <option value="142">142 días</option>
            <option value="143">143 días</option>
            <option value="144">144 días</option>
            <option value="145">145 días</option>
            <option value="146">146 días</option>
            <option value="147">147 días</option>
            <option value="148">148 días</option>
            <option value="149">149 días</option>
            <option value="150">150 días</option>
            <option value="151">151 días</option>
            <option value="152">152 días</option>
            <option value="153">153 días</option>
            <option value="154">154 días</option>
            <option value="155">155 días</option>
            <option value="156">156 días</option>
            <option value="157">157 días</option>
            <option value="158">158 días</option>
            <option value="159">159 días</option>
            <option value="160">160 días</option>
            <option value="161">161 días</option>
            <option value="162">162 días</option>
            <option value="163">163 días</option>
            <option value="164">164 días</option>
            <option value="165">165 días</option>
            <option value="166">166 días</option>
            <option value="167">167 días</option>
            <option value="168">168 días</option>
            <option value="169">169 días</option>
            <option value="170">170 días</option>
            <option value="171">171 días</option>
            <option value="172">172 días</option>
            <option value="173">173 días</option>
            <option value="174">174 días</option>
            <option value="175">175 días</option>
            <option value="176">176 días</option>
            <option value="177">177 días</option>
            <option value="178">178 días</option>
            <option value="179">179 días</option>
            <option value="180">180 días</option>
            <option value="181">181 días</option>
            <option value="182">182 días</option>
            <option value="183">183 días</option>
            <option value="184">184 días</option>
            <option value="185">185 días</option>
            <option value="186">186 días</option>
            <option value="187">187 días</option>
            <option value="188">188 días</option>
            <option value="189">189 días</option>
            <option value="190">190 días</option>
            <option value="191">191 días</option>
            <option value="192">192 días</option>
            <option value="193">193 días</option>
            <option value="194">194 días</option>
            <option value="195">195 días</option>
            <option value="196">196 días</option>
            <option value="197">197 días</option>
            <option value="198">198 días</option>
            <option value="199">199 días</option>
            <option value="200">200 días</option>
            <option value="201">201 días</option>
            <option value="202">202 días</option>
            <option value="203">203 días</option>
            <option value="204">204 días</option>
            <option value="205">205 días</option>
            <option value="206">206 días</option>
            <option value="207">207 días</option>
            <option value="208">208 días</option>
            <option value="209">209 días</option>
            <option value="210">210 días</option>
            <option value="211">211 días</option>
            <option value="212">212 días</option>
            <option value="213">213 días</option>
            <option value="214">214 días</option>
            <option value="215">215 días</option>
            <option value="216">216 días</option>
            <option value="217">217 días</option>
            <option value="218">218 días</option>
            <option value="219">219 días</option>
            <option value="220">220 días</option>
            <option value="221">221 días</option>
            <option value="222">222 días</option>
            <option value="223">223 días</option>
            <option value="224">224 días</option>
            <option value="225">225 días</option>
            <option value="226">226 días</option>
            <option value="227">227 días</option>
            <option value="228">228 días</option>
            <option value="229">229 días</option>
            <option value="230">230 días</option>
            <option value="231">231 días</option>
            <option value="232">232 días</option>
            <option value="233">233 días</option>
            <option value="234">234 días</option>
            <option value="235">235 días</option>
            <option value="236">236 días</option>
            <option value="237">237 días</option>
            <option value="238">238 días</option>
            <option value="239">239 días</option>
            <option value="240">240 días</option>
            <option value="241">241 días</option>
            <option value="242">242 días</option>
            <option value="243">243 días</option>
            <option value="244">244 días</option>
            <option value="245">245 días</option>
            <option value="246">246 días</option>
            <option value="247">247 días</option>
            <option value="248">248 días</option>
            <option value="249">249 días</option>
            <option value="250">250 días</option>
            <option value="251">251 días</option>
            <option value="252">252 días</option>
            <option value="253">253 días</option>
            <option value="254">254 días</option>
            <option value="255">255 días</option>
            <option value="256">256 días</option>
            <option value="257">257 días</option>
            <option value="258">258 días</option>
            <option value="259">259 días</option>
            <option value="260">260 días</option>
            <option value="261">261 días</option>
            <option value="262">262 días</option>
            <option value="263">263 días</option>
            <option value="264">264 días</option>
            <option value="265">265 días</option>
            <option value="266">266 días</option>
            <option value="267">267 días</option>
            <option value="268">268 días</option>
            <option value="269">269 días</option>
            <option value="270">270 días</option>
            <option value="271">271 días</option>
            <option value="272">272 días</option>
            <option value="273">273 días</option>
            <option value="274">274 días</option>
            <option value="275">275 días</option>
            <option value="276">276 días</option>
            <option value="277">277 días</option>
            <option value="278">278 días</option>
            <option value="279">279 días</option>
            <option value="280">280 días</option>
            <option value="281">281 días</option>
            <option value="282">282 días</option>
            <option value="283">283 días</option>
            <option value="284">284 días</option>
            <option value="285">285 días</option>
            <option value="286">286 días</option>
            <option value="287">287 días</option>
            <option value="288">288 días</option>
            <option value="289">289 días</option>
            <option value="290">290 días</option>
            <option value="291">291 días</option>
            <option value="292">292 días</option>
            <option value="293">293 días</option>
            <option value="294">294 días</option>
            <option value="295">295 días</option>
            <option value="296">296 días</option>
            <option value="297">297 días</option>
            <option value="298">298 días</option>
            <option value="299">299 días</option>
            <option value="300">300 días</option>
            <option value="301">301 días</option>
            <option value="302">302 días</option>
            <option value="303">303 días</option>
            <option value="304">304 días</option>
            <option value="305">305 días</option>
            <option value="306">306 días</option>
            <option value="307">307 días</option>
            <option value="308">308 días</option>
            <option value="309">309 días</option>
            <option value="310">310 días</option>
            <option value="311">311 días</option>
            <option value="312">312 días</option>
            <option value="313">313 días</option>
            <option value="314">314 días</option>
            <option value="315">315 días</option>
            <option value="316">316 días</option>
            <option value="317">317 días</option>
            <option value="318">318 días</option>
            <option value="319">319 días</option>
            <option value="320">320 días</option>
            <option value="321">321 días</option>
            <option value="322">322 días</option>
            <option value="323">323 días</option>
            <option value="324">324 días</option>
            <option value="325">325 días</option>
            <option value="326">326 días</option>
            <option value="327">327 días</option>
            <option value="328">328 días</option>
            <option value="329">329 días</option>
            <option value="330">330 días</option>
            <option value="331">331 días</option>
            <option value="332">332 días</option>
            <option value="333">333 días</option>
            <option value="334">334 días</option>
            <option value="335">335 días</option>
            <option value="336">336 días</option>
            <option value="337">337 días</option>
            <option value="338">338 días</option>
            <option value="339">339 días</option>
            <option value="340">340 días</option>
            <option value="341">341 días</option>
            <option value="342">342 días</option>
            <option value="343">343 días</option>
            <option value="344">344 días</option>
            <option value="345">345 días</option>
            <option value="346">346 días</option>
            <option value="347">347 días</option>
            <option value="348">348 días</option>
            <option value="349">349 días</option>
            <option value="350">350 días</option>
            <option value="351">351 días</option>
            <option value="352">352 días</option>
            <option value="353">353 días</option>
            <option value="354">354 días</option>
            <option value="355">355 días</option>
            <option value="356">356 días</option>
            <option value="357">357 días</option>
            <option value="358">358 días</option>
            <option value="359">359 días</option>
            <option value="360">360 días</option>
            <option value="361">361 días</option>
            <option value="362">362 días</option>
            <option value="363">363 días</option>
            <option value="364">364 días</option>
            <option value="365">365 días</option>
            <option value="366">366 días</option>
            <option value="367">367 días</option>
            <option value="368">368 días</option>
            <option value="369">369 días</option>
            <option value="370">370 días</option>
            <option value="371">371 días</option>
            <option value="372">372 días</option>
            <option value="373">373 días</option>
            <option value="374">374 días</option>
            <option value="375">375 días</option>
            <option value="376">376 días</option>
            <option value="377">377 días</option>
            <option value="378">378 días</option>
            <option value="379">379 días</option>
            <option value="380">380 días</option>
            <option value="381">381 días</option>
            <option value="382">382 días</option>
            <option value="383">383 días</option>
            <option value="384">384 días</option>
            <option value="385">385 días</option>
            <option value="386">386 días</option>
            <option value="387">387 días</option>
            <option value="388">388 días</option>
            <option value="389">389 días</option>
            <option value="390">390 días</option>
            <option value="391">391 días</option>
            <option value="392">392 días</option>
            <option value="393">393 días</option>
            <option value="394">394 días</option>
            <option value="395">395 días</option>
            <option value="396">396 días</option>
            <option value="397">397 días</option>
            <option value="398">398 días</option>
            <option value="399">399 días</option>
            <option value="400">400 días</option>
            <option value="401">401 días</option>
            <option value="402">402 días</option>
            <option value="403">403 días</option>
            <option value="404">404 días</option>
            <option value="405">405 días</option>
            <option value="406">406 días</option>
            <option value="407">407 días</option>
            <option value="408">408 días</option>
            <option value="409">409 días</option>
            <option value="410">410 días</option>
            <option value="411">411 días</option>
            <option value="412">412 días</option>
            <option value="413">413 días</option>
            <option value="414">414 días</option>
            <option value="415">415 días</option>
            <option value="416">416 días</option>
            <option value="417">417 días</option>
            <option value="418">418 días</option>
            <option value="419">419 días</option>
            <option value="420">420 días</option>
            <option value="421">421 días</option>
            <option value="422">422 días</option>
            <option value="423">423 días</option>
            <option value="424">424 días</option>
            <option value="425">425 días</option>
            <option value="426">426 días</option>
            <option value="427">427 días</option>
            <option value="428">428 días</option>
            <option value="429">429 días</option>
            <option value="430">430 días</option>
            <option value="431">431 días</option>
            <option value="432">432 días</option>
            <option value="433">433 días</option>
            <option value="434">434 días</option>
            <option value="435">435 días</option>
            <option value="436">436 días</option>
            <option value="437">437 días</option>
            <option value="438">438 días</option>
            <option value="439">439 días</option>
            <option value="440">440 días</option>
            <option value="441">441 días</option>
            <option value="442">442 días</option>
            <option value="443">443 días</option>
            <option value="444">444 días</option>
            <option value="445">445 días</option>
            <option value="446">446 días</option>
            <option value="447">447 días</option>
            <option value="448">448 días</option>
            <option value="449">449 días</option>
            <option value="450">450 días</option>
            <option value="451">451 días</option>
            <option value="452">452 días</option>
            <option value="453">453 días</option>
            <option value="454">454 días</option>
            <option value="455">455 días</option>
            <option value="456">456 días</option>
            <option value="457">457 días</option>
            <option value="458">458 días</option>
            <option value="459">459 días</option>
            <option value="460">460 días</option>
            <option value="461">461 días</option>
            <option value="462">462 días</option>
            <option value="463">463 días</option>
            <option value="464">464 días</option>
            <option value="465">465 días</option>
            <option value="466">466 días</option>
            <option value="467">467 días</option>
            <option value="468">468 días</option>
            <option value="469">469 días</option>
            <option value="470">470 días</option>
            <option value="471">471 días</option>
            <option value="472">472 días</option>
            <option value="473">473 días</option>
            <option value="474">474 días</option>
            <option value="475">475 días</option>
            <option value="476">476 días</option>
            <option value="477">477 días</option>
            <option value="478">478 días</option>
            <option value="479">479 días</option>
            <option value="480">480 días</option>
            <option value="481">481 días</option>
            <option value="482">482 días</option>
            <option value="483">483 días</option>
            <option value="484">484 días</option>
            <option value="485">485 días</option>
            <option value="486">486 días</option>
            <option value="487">487 días</option>
            <option value="488">488 días</option>
            <option value="489">489 días</option>
            <option value="490">490 días</option>
            <option value="491">491 días</option>
            <option value="492">492 días</option>
            <option value="493">493 días</option>
            <option value="494">494 días</option>
            <option value="495">495 días</option>
            <option value="496">496 días</option>
            <option value="497">497 días</option>
            <option value="498">498 días</option>
            <option value="499">499 días</option>
            <option value="500">500 días</option>
            <option value="501">501 días</option>
            <option value="502">502 días</option>
            <option value="503">503 días</option>
            <option value="504">504 días</option>
            <option value="505">505 días</option>
            <option value="506">506 días</option>
            <option value="507">507 días</option>
            <option value="508">508 días</option>
            <option value="509">509 días</option>
            <option value="510">510 días</option>
            <option value="511">511 días</option>
            <option value="512">512 días</option>
            <option value="513">513 días</option>
            <option value="514">514 días</option>
            <option value="515">515 días</option>
            <option value="516">516 días</option>
            <option value="517">517 días</option>
            <option value="518">518 días</option>
            <option value="519">519 días</option>
            <option value="520">520 días</option>
            <option value="521">521 días</option>
            <option value="522">522 días</option>
            <option value="523">523 días</option>
            <option value="524">524 días</option>
            <option value="525">525 días</option>
            <option value="526">526 días</option>
            <option value="527">527 días</option>
            <option value="528">528 días</option>
            <option value="529">529 días</option>
            <option value="530">530 días</option>
            <option value="531">531 días</option>
            <option value="532">532 días</option>
            <option value="533">533 días</option>
            <option value="534">534 días</option>
            <option value="535">535 días</option>
            <option value="536">536 días</option>
            <option value="537">537 días</option>
            <option value="538">538 días</option>
            <option value="539">539 días</option>
            <option value="540">540 días</option>
            <option value="541">541 días</option>
            <option value="542">542 días</option>
            <option value="543">543 días</option>
            <option value="544">544 días</option>
            <option value="545">545 días</option>
            <option value="546">546 días</option>
            <option value="547">547 días</option>
            <option value="548">548 días</option>
            <option value="549">549 días</option>
            <option value="550">550 días</option>
            <option value="551">551 días</option>
            <option value="552">552 días</option>
            <option value="553">553 días</option>
            <option value="554">554 días</option>
            <option value="555">555 días</option>
            <option value="556">556 días</option>
            <option value="557">557 días</option>
            <option value="558">558 días</option>
            <option value="559">559 días</option>
            <option value="560">560 días</option>
            <option value="561">561 días</option>
            <option value="562">562 días</option>
            <option value="563">563 días</option>
            <option value="564">564 días</option>
            <option value="565">565 días</option>
            <option value="566">566 días</option>
            <option value="567">567 días</option>
            <option value="568">568 días</option>
            <option value="569">569 días</option>
            <option value="570">570 días</option>
            <option value="571">571 días</option>
            <option value="572">572 días</option>
            <option value="573">573 días</option>
            <option value="574">574 días</option>
            <option value="575">575 días</option>
            <option value="576">576 días</option>
            <option value="577">577 días</option>
            <option value="578">578 días</option>
            <option value="579">579 días</option>
            <option value="580">580 días</option>
            <option value="581">581 días</option>
            <option value="582">582 días</option>
            <option value="583">583 días</option>
            <option value="584">584 días</option>
            <option value="585">585 días</option>
            <option value="586">586 días</option>
            <option value="587">587 días</option>
            <option value="588">588 días</option>
            <option value="589">589 días</option>
            <option value="590">590 días</option>
            <option value="591">591 días</option>
            <option value="592">592 días</option>
            <option value="593">593 días</option>
            <option value="594">594 días</option>
            <option value="595">595 días</option>
            <option value="596">596 días</option>
            <option value="597">597 días</option>
            <option value="598">598 días</option>
            <option value="599">599 días</option>
            <option value="600">600 días</option>
            <option value="601">601 días</option>
            <option value="602">602 días</option>
            <option value="603">603 días</option>
            <option value="604">604 días</option>
            <option value="605">605 días</option>
            <option value="606">606 días</option>
            <option value="607">607 días</option>
            <option value="608">608 días</option>
            <option value="609">609 días</option>
            <option value="610">610 días</option>
            <option value="611">611 días</option>
            <option value="612">612 días</option>
            <option value="613">613 días</option>
            <option value="614">614 días</option>
            <option value="615">615 días</option>
            <option value="616">616 días</option>
            <option value="617">617 días</option>
            <option value="618">618 días</option>
            <option value="619">619 días</option>
            <option value="620">620 días</option>
            <option value="621">621 días</option>
            <option value="622">622 días</option>
            <option value="623">623 días</option>
            <option value="624">624 días</option>
            <option value="625">625 días</option>
            <option value="626">626 días</option>
            <option value="627">627 días</option>
            <option value="628">628 días</option>
            <option value="629">629 días</option>
            <option value="630">630 días</option>
            <option value="631">631 días</option>
            <option value="632">632 días</option>
            <option value="633">633 días</option>
            <option value="634">634 días</option>
            <option value="635">635 días</option>
            <option value="636">636 días</option>
            <option value="637">637 días</option>
            <option value="638">638 días</option>
            <option value="639">639 días</option>
            <option value="640">640 días</option>
            <option value="641">641 días</option>
            <option value="642">642 días</option>
            <option value="643">643 días</option>
            <option value="644">644 días</option>
            <option value="645">645 días</option>
            <option value="646">646 días</option>
            <option value="647">647 días</option>
            <option value="648">648 días</option>
            <option value="649">649 días</option>
            <option value="650">650 días</option>
            <option value="651">651 días</option>
            <option value="652">652 días</option>
            <option value="653">653 días</option>
            <option value="654">654 días</option>
            <option value="655">655 días</option>
            <option value="656">656 días</option>
            <option value="657">657 días</option>
            <option value="658">658 días</option>
            <option value="659">659 días</option>
            <option value="660">660 días</option>
            <option value="661">661 días</option>
            <option value="662">662 días</option>
            <option value="663">663 días</option>
            <option value="664">664 días</option>
            <option value="665">665 días</option>
            <option value="666">666 días</option>
            <option value="667">667 días</option>
            <option value="668">668 días</option>
            <option value="669">669 días</option>
            <option value="670">670 días</option>
            <option value="671">671 días</option>
            <option value="672">672 días</option>
            <option value="673">673 días</option>
            <option value="674">674 días</option>
            <option value="675">675 días</option>
            <option value="676">676 días</option>
            <option value="677">677 días</option>
            <option value="678">678 días</option>
            <option value="679">679 días</option>
            <option value="680">680 días</option>
            <option value="681">681 días</option>
            <option value="682">682 días</option>
            <option value="683">683 días</option>
            <option value="684">684 días</option>
            <option value="685">685 días</option>
            <option value="686">686 días</option>
            <option value="687">687 días</option>
            <option value="688">688 días</option>
            <option value="689">689 días</option>
            <option value="690">690 días</option>
            <option value="691">691 días</option>
            <option value="692">692 días</option>
            <option value="693">693 días</option>
            <option value="694">694 días</option>
            <option value="695">695 días</option>
            <option value="696">696 días</option>
            <option value="697">697 días</option>
            <option value="698">698 días</option>
            <option value="699">699 días</option>
            <option value="700">700 días</option>
            <option value="701">701 días</option>
            <option value="702">702 días</option>
            <option value="703">703 días</option>
            <option value="704">704 días</option>
            <option value="705">705 días</option>
            <option value="706">706 días</option>
            <option value="707">707 días</option>
            <option value="708">708 días</option>
            <option value="709">709 días</option>
            <option value="710">710 días</option>
            <option value="711">711 días</option>
            <option value="712">712 días</option>
            <option value="713">713 días</option>
            <option value="714">714 días</option>
            <option value="715">715 días</option>
            <option value="716">716 días</option>
            <option value="717">717 días</option>
            <option value="718">718 días</option>
            <option value="719">719 días</option>
            <option value="720">720 días</option>
                                    
                                    
                                    
                                    
                                    
                                    
        </select></td>
                        </tr>

                        <tr>
                            <td><button type="submit" class="botonForm" name="Submit" value="Calcular"  >Calcular&nbsp;&nbsp;&nbsp;&nbsp;<i class="fa fa-calculator" aria-hidden="true" ></i></button></td>
                            <td><a href=# onclick=document.location.href=('calAhorro.php');><button class="botonForm1">Limpiar&nbsp;<i class="fa fa-trash" aria-hidden="true" ></i></button></a></td>
                        </tr>
                    </table>

                    <br>
                    <div >
                
                    </form>
            </div>


            </div>
            <!--derecha-->
<div class="span7">
                <img class="img-rounded" src="images/simuladores/sim2.jpg"/>
</div>

        </div>
    </section>
    <div id="pie" style="display:none"></div>

    <script src="js/vendor/jquery-1.9.1.min.js"></script>
    <script src="js/vendor/bootstrap.min.js"></script>
    <script src="js/main.js"></script>


<script>
    $("#formulario").validate();
</script>
