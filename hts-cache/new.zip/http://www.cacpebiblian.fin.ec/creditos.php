<html class="no-js">

    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">

        <meta name="description" content="">
        <meta name="viewport" content="width=device-width">

        <link rel="stylesheet" href="css/bootstrap.min.css">
        <link rel="stylesheet" href="css/bootstrap-responsive.min.css">
        <link rel="stylesheet" href="css/font-awesome.min.css">
        <link rel="stylesheet" href="css/main.css">
        <link rel="stylesheet" href="css/sl-slide.css">

        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
        <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
        <link rel="stylesheet" href="css/social.css">

        <script src="js/vendor/modernizr-2.6.2-respond-1.1.0.min.js"></script>
        <script type="text/javascript" src="js/validar.js"></script>
        <script src="js/vendor/bootstrap.min.js"></script>
        <script src="js/vendor/jquery-1.9.1.min.js"></script>
        <script type="text/javascript" src="js/funciones.js"></script>
        <script type="text/javascript" src="lib/Gruntfile/Gruntfile.js"></script>
        <script type="text/javascript" src="lib/Gruntfile/js/easy-loading.min.js"></script>
        <link rel="stylesheet" href="lib/Gruntfile/css/easy-loading.min.css">
        <script async src="//pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
        <!-- Le fav and touch icons -->
        <link rel="shortcut icon" href="images/ico/icon.ico">
        <link rel="apple-touch-icon-precomposed" sizes="144x144" href="images/ico/apple-touch-icon-144-precomposed.png">
        <link rel="apple-touch-icon-precomposed" sizes="114x114" href="images/ico/apple-touch-icon-114-precomposed.png">
        <link rel="apple-touch-icon-precomposed" sizes="72x72" href="images/ico/apple-touch-icon-72-precomposed.png">
        <link rel="apple-touch-icon-precomposed" href="images/ico/apple-touch-icon-57-precomposed.png">
        <link rel="stylesheet" href="css/img-efect.css">
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
        <script src="js/jquery-3.2.1.min.js"></script>
        <link rel="stylesheet" href="css/progress-bar.css">
        <script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
        <!--carousel-->
        <script src="js/jssor.slider-26.1.5.min.js" type="text/javascript"></script>
        <script>
            $(document).ready(function(){
                //===========FUNCION PARA PONER EL PIE DE PAGINA=============//
                $("#pie").after('<!--Bottom--><section id="bottom" class="main"><!--Container--><div class="container"><!--row-fluids--><div class="row-fluid"><!--Contact Form--><div class="span7"><h4>UBIQUENOS</h4><ul class="unstyled address"><li><i class="icon-home"></i><strong>Dirección:</strong> Mariscal Sucre 3-38 y Daniel Muñoz<br></li><li><i class="icon-envelope"></i><strong>Email: </strong> info@cbcooperativa.fin.ec</li><li><i class="icon-phone"></i><strong>Teléfono:</strong> 072230836</li></ul></div><!--End Contact Form--><!--Important Links--><div id="tweets" class="span5"><h4>&nbsp;NOSOTROS</h4><div class="span3"><ul class="arrow"><li><a href="reconocimientos.php">Información</a></li><li><a href="sucursales.php">Contactos</a></li><li><a href="mensual.php">Transparencia</a></li></ul></div><div class="span6"><ul class="arrow"><li><a href="creditos.php#pricing-table">Productos y Servicios</a></li><li><a href="solitudCredito.php">Solicite su Crédito</a></li></ul></div></div><!--Important Links--></div><!--/row-fluid--></div><!--/container--></section><!--/bottom--><!--Footer--><footer id="footer"><div class="container"><div class="row-fluid"><div class="span5 cp">&copy; 2017 <a target="_blank" href="#" title="Free Twitter Bootstrap WordPress Themes and HTML templates">CB COOPERATIVA </a>. All Rights Reserved.</div><!--/Copyright--><div class="span6"><ul class="social pull-right"><li><a href="#"><i class="icon-facebook"></i></a></li><li><a href="#"><i class="icon-twitter"></i></a></li><li><a href="#"><i class="icon-youtube"></i></a></li><li><a href="#"><i class="icon-instagram"></i></a></li></ul></div><div class="span1"><a id="gototop" class="gototop pull-right" href="#"><i class="icon-angle-up"></i></a></div><!--/Goto Top--></div></div></footer><!--/Footer-->');              
            });
        </script>

   
     <style>    
        .whatsapp {
            position:fixed;
            width:60px;
            height:60px;
            bottom:87px;
            right:25px;
            background-color:#25d366;
            color:#FFF;
            border-radius:50px;
            text-align:center;
            font-size:30px;
            z-index:100;
        }

        .whatsapp-icon {
          margin-top:15px;
        }
        
    </style>        
   
    </head>

    <body oncontextmenu="return false" onload="active();redirigirNot();" style="background-color:rgb(255,255,255)">

        <!--Header-->
        <header class="navbar navbar-fixed-top">
            <div class="navbar-inner">
                <div class="container">
                    <a class="btn btn-navbar" data-toggle="collapse" data-target=".nav-collapse">
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </a>
                    <a id="logo" class="pull-left" href="index.php"></a>
                    <div class="nav-collapse collapse pull-right">
                        <ul class="nav">
                            <li id="liIndex"><a href="index.php">Inicio</a></li>
                            <li class="dropdown" id="liNos">
                                <a href="#" class="dropdown-toggle" data-toggle="dropdown">Nosotros <i class="icon-angle-down"></i></a>
                                <ul class="dropdown-menu">
                                    <li id="liMV"><a href="misionvision.php">Misión y Visión</a></li>
                                    <li id="liRH"><a href="reconocimientos.php">Reseña Histórica</a></li>
                                    <li id="liNot"><a href="noticias.php">Noticias</a></li>
                                </ul>
                            </li>
                            <li id="liPS" class="dropdown">
                                <a href="#" class="dropdown-toggle" data-toggle="dropdown">Productos y Servicios <i class="icon-angle-down"></i></a>
                                <ul class="dropdown-menu">
                                    <li id="liCred" ><a href="creditos.php#pricing-table">Créditos</a></li>
                                    <li id="liPA" ><a href="planesAhorro.php#pricing-table">Planes de Ahorro</a></li>
                                </ul>
                            </li>

                            <li id="liCont" class="dropdown">
                                <a href="#" class="dropdown-toggle" data-toggle="dropdown">Contactos <i class="icon-angle-down"></i></a>
                                <ul class="dropdown-menu">
                                    <li id="liDS"><a href="sucursales.php">Directorio de Sucursales</a></li>
                                    <li id="liDCA"><a href="cajeros.php">Directorio de Cajeros Automáticos</a></li>

                                </ul>
                            </li>

                            <li id="liSim" class="dropdown">
                                <a href="#" class="dropdown-toggle" data-toggle="dropdown">Simuladores <i class="icon-angle-down"></i></a>
                                <ul class="dropdown-menu">
                                    <li id="liCalCred"><a href="calcCredit.php">Calcule su Crédito</a></li>
                                    <li id="liCalAho"><a href="calAhorro.php">Calcule su Ahorro</a></li>
                                </ul>
                            </li>

                            <li id="liSerOnl" class="dropdown">
                                <a href="#" class="dropdown-toggle" data-toggle="dropdown">Servicios Online <i class="icon-angle-down"></i></a>
                                <ul class="dropdown-menu">
                                    <li id="liSolCred"><a href="solitudCredito.php">Solicite su Crédito</a></li>
                                    <li id="liAbCuAq"><a href="abrircuenta.php">Abra su Cuenta Aquí</a></li>
                                </ul>
                            </li>


                            <li id="liTransp" class="dropdown">
                                <a href="#" class="dropdown-toggle" data-toggle="dropdown">Transparencia <i class="icon-angle-down"></i></a>
                                <ul class="dropdown-menu">
                                    <li id="liInfMens"><a href="mensual.php">Informacion Mensual</a></li>
                                    <li id="liInfTrim"><a href="trimestral.php">Informacion Trimestral</a></li>
                                    <li id="liInfTrim"><a href="anual.php">Informacion Anual</a></li>                                    
                                    <li id="liCosFin"><a href="costos.php">Costos Financieros</a></li>
                                    <li id="liCalifi"><a href="calificacion.php">Calificacion</a></li>
                                    <li><a href="resolucion.php">Resolución SEPS-IGT...0320</a></li>
                                </ul>
                            </li>

                            <li class="login">
                                <a data-toggle="modal" href="#loginForm"><i class="icon-lock"></i></a>
                            </li>
                        </ul>
                    </div>
                    <!--/.nav-collapse -->
                </div>
            </div>


        </header>
        <!-- /header -->
        <!-------------------------CHAT------------------------>
       <div style=" position: fixed;right: 90px;   border-color:transparent;bottom: 0; z-index: 3000;width: 350px; height: auto; align-content: right; text-align: right;">
            <button type="button" class="btn btn-lg btn-info collapsed" data-toggle="collapse" data-target="#chat_cliente" style="width: 350px;border-radius:10px;  outline:none; margin:0px; border-color:transparent;">Dejar un mensaje <i class="fa fa-comments" aria-hidden="true"></i></button>
            <div id="chat_cliente" class="collapse" style="width:100%; border: 1px solid #398aa4; border-radius: 7px">
                <div style="background-color: rgba(255,255,255,0.7); color: #444;">
                    <div class="center">
                        <br>
                        <img src="images/chat.png" style="border-radius:25px;" />
                    </div>
                    <table style="text-align: justify; font-size: 12px; margin-left: 20px;">
                        <tr>
                            <td colspan="2" style="color:#000000 ">Para consultas y sugerencias, por favor ingrese sus datos personales y presione enviar. <br>Lo antes posible nuestro personal se comunicará con usted. <strong>Gracias por su mensaje</strong> <b class="text-success">CB Cooperativa LTDA.</b></td>
                        </tr>
                        <tr>
                            <td><strong>Nombres:</strong></td>
                            <td><input name="ms1" id="ms1" type="text" onkeypress="return soloLetras(event)" required style="background:#B4CCDE     ; color:#444;border:1px solid #2A608A "></td>
                        </tr>
                        <tr>
                            <td><strong>Email:</strong></td>
                            <td><input name="ms2" id="ms2" type="email" required onkeypress="return soloCorreo(event)" style="background:#B4CCDE     ; color:#444;border:1px solid #2A608A "></td>
                        </tr>
                        <tr>
                            <td><strong>Tel&eacute;fono:</strong></td>
                            <td><input name="ms3" id="ms3" type="tel" maxlength="10" onkeypress="return soloNumeros(event)" style="background:#B4CCDE     ; color:#444;border:1px solid #2A608A "></td>
                        </tr>
                        <tr>
                            <td><strong>Direcci&oacute;n:</strong></td>
                            <td><input name="ms4" id="ms4" type="text" required onkeypress="return soloValidos(event)" style="background:#B4CCDE     ; color:#444;border:1px solid #2A608A "></td>
                        </tr>
                        <tr>
                            <td><strong>Ciudad:</strong></td>
                            <td><input name="ms5" id="ms5" type="text" required onkeypress="return soloLetras(event)" style="background:#B4CCDE     ; color:#444;border:1px solid #2A608A "></td>
                        </tr>
                        <tr>
                            <td><strong>Tema:</strong></td>
                            <td><input name="ms6" id="ms6" type="text" required onkeypress="return soloLetras(event)" style="background:#B4CCDE     ; color:#444;border:1px solid #2A608A "></td>
                        </tr>
                        <tr>
                            <td><strong>Mensaje:</strong></td>
                            <td><textarea name="ms7" id="ms7" rows="4" required onkeypress="return soloLetras(event)" style="background:#B4CCDE     ; color:#444;border:1px solid #2A608A "></textarea></td>
                        </tr>
                        <tr>
                            <td colspan="2" style="text-align: center"><input style="border-radius:10px;" class="btn zoom inputC" type="button" onclick="validarChat();" value="ENVIAR"></td>
                        </tr>
                        <tr>
                            <td colspan="2"> <br></td>
                        </tr>
                    </table>
                </div>
            </div>
        </div>
        <!-------------------------//CHAT//------------------------>
        <!-------------------------CARTILLA DE ACTUALIZACION------------------------>
        <!--
           <div style=" position: fixed;right: 302px;   border-color:transparent;bottom: 0px; z-index: 3000;width: 350px; height: auto; align-content: right; text-align: center;">
            <button type="button" class="btn btn-lg btn-info collapsed" data-toggle="collapse" data-target="#cart_actual" style="width: 250px;border-radius:10px;  outline:none; margin:0px; border-color:transparent;background: #ffa251" onclick="window.location='cartilla_actualizacion.php'">Cartilla de Actualizacion <i class="fa fa-address-card" aria-hidden="true" ></i></button>            
        </div>
        -->
        <!-------------------------//CARTILLA DE ACTUALIZACION//------------------------>

        <!--REDES SOCIALES-->
        <div class="sociales">
        <ul>
                     
            <li>
                <a href="https://www.facebook.com/cacpebiblian/?fref=ts" target="_blank" class="icon-facebook" title = "Facebook"></a>
            </li>
            <li>
                <a href="https://twitter.com/cacpe_biblian?lang=es" target="_blank" class="icon-twitter" title = "Twitter"></a>
            </li>
            <li>
                <a href="https://www.cosede.gob.ec/informacion-para-entidades-financieras/" target="_blank" class="icon-lock" style= 'background: #edb140' title = "Cosede"></a>
            </li>            
        </ul>
        </div>
        <!--/REDES SOCIALES/-->
      
     
    <!-- Load Facebook SDK for JavaScript -->
<div id="fb-root"></div>
<script>
  window.fbAsyncInit = function() {
    FB.init({
      xfbml            : true,
      version          : 'v3.3'
    });
  };

  (function(d, s, id) {
  var js, fjs = d.getElementsByTagName(s)[0];
  if (d.getElementById(id)) return;
  js = d.createElement(s); js.id = id;
  js.src = 'https://connect.facebook.net/es_ES/sdk/xfbml.customerchat.js';
  fjs.parentNode.insertBefore(js, fjs);
}(document, 'script', 'facebook-jssdk'));</script>

<!-- Your customer chat code -->
<div class="fb-customerchat"
  attribution=setup_tool
  page_id="950390831753046"
  theme_color="#0084ff"
  logged_in_greeting="¡Hola! como podemos ayudarte?"
  logged_out_greeting="¡Hola! como podemos ayudarte?">
</div>
        <a href="http://bit.ly/2UhY0ID" class="whatsapp" target="_blank"> <i class="fa fa-whatsapp whatsapp-icon"></i></a>        <title>Cacpe | Créditos</title>
        
        <script>
            function openCity(evt, cityName) {
                var i, tabcontent, tablinks;
                var dis = document.getElementById(cityName).style.display;
                if(dis=="none"||dis==""){
                    tabcontent = document.getElementsByClassName("tabcontent");
                    for (i = 0; i < tabcontent.length; i++) {
                        tabcontent[i].style.display = "none";
                    }
                    tablinks = document.getElementsByClassName("tablinks");
                    for (i = 0; i < tablinks.length; i++) {
                        tablinks[i].className = tablinks[i].className.replace(" active", "");
                    }

                    document.getElementById(cityName).style.display = "block";
                    evt.currentTarget.className += " active";
                }
                else{
                    document.getElementById(cityName).style.display = "none";}
            }
            function active()
            {
                document.getElementById("liPS").className = "dropdown active";
                document.getElementById("liCred").className = "active";
            }
        </script>
        <style>
            /* Style the tab */
            .tab {
                overflow: hidden;
                background-color: rgb(255,255,255);
            }

            /* Style the buttons inside the tab */
            .tab button {
                background-color: inherit;
                float: left;
                border: none;
                outline: none;
                cursor: pointer;
                padding: 5px 5px;
                transition: 0.4s;
                width: 233px;
            }

            /* Change background color of buttons on hover */
            .tab button:hover {
                background-color: rgb(255,255,255);
            }

            /* Create an active/current tablink class */
            .tab button.active {
                background-color: #ccc;
                border-radius: 10px;
            }

            /* Style the tab content */
            .tabcontent {
                display: none;
                margin: 5px;
                padding: 0px 0px;
                border-top: none;                
            }
        </style>
    

        <section class="title"  >
            <div class="container">
                <div class="row-fluid">
                    <div class="span6">
                        <h1>Créditos</h1>
                    </div>
                    <div class="span6">
                        <ul class="breadcrumb pull-right">
                            <li><a href="index.php">Inicio</a> <span class="divider">/</span></li>
                            <li><a href="#">Productos y Servicios</a> <span class="divider">/</span></li>
                            <li class="active">Créditos</li>
                        </ul>
                    </div>
                </div>
            </div>
        </section>
        <!-- / .title -->

        <section id="pricing-table" class="container" >
            <div class="container" id="pricing-table">
                <img src="images/credito/bannerCred2.jpg" alt="" class="img-rounded" >
            </div>
            <br>
            <div class="tab">
                <button class="tablinks" onclick="openCity(event, 'uno')"><ul class="plan plan1" style="border-radius: 5px;">
                    <li class="plan-name" style="border-radius: 5px;">
                        <center><img src="images/credito/cp.jpg" alt="" class="img-rounded" ><img src="images/credito/scrooll.gif" alt="" width="25px">
                        </center>
                    </li>
                    </ul></button>
                <button class="tablinks" onclick="openCity(event, 'dos')"> <ul class="plan plan2 " style="border-radius: 5px;">
                    <li class="plan-name" style="border-radius: 5px;">
                        <center><img src="images/credito/ca.png" alt="" class="img-rounded" >
                            <img src="images/credito/scrooll.gif" alt="" width="25px"></center>
                    </li>
                    </ul></button>
                <button class="tablinks" onclick="openCity(event, 'tres')"><ul class="plan plan3" style="border-radius: 5px;">
                    <li class="plan-name"  style="border-radius: 5px;">
                        <center><img src="images/credito/cm.png" alt="" class="img-rounded" >
                            <img src="images/credito/scrooll.gif" alt="" width="25px">
                        </center>
                    </li>
                    </ul></button>
                <button class="tablinks" onclick="openCity(event, 'cuatro')"><ul class="plan plan1" style="border-radius: 5px;">
                    <li class="plan-name"  style="border-radius: 5px;">
                        <center><img src="images/credito/cc.png" alt="" class="img-rounded" ><img src="images/credito/scrooll.gif" alt="" width="25px"></center>
                    </li>
                    </ul></button>
                <button class="tablinks" onclick="openCity(event, 'cinco')"><ul class="plan plan1" style="border-radius: 5px;">
                    <li class="plan-name"  style="border-radius: 5px;">
                        <center><img src="images/credito/ci.png" alt="" class="img-rounded" ><img src="images/credito/scrooll.gif" alt="" width="25px"></center>
                    </li>
                    </ul></button>
            </div>
            <div id="uno" class="tabcontent">
                <ul class="plan plan4" align="justify" style="border-radius: 5px;font-size: 10pt">
                    <li class="plan-price" >
                        Montos hasta $30.000 dólares para un plazo de 6 meses.
                    </li>

                    <li>
                        Su mejor opción para oportunidades de negocio, compra de vehículo, imprevistos, emergencias, pago del estudio de sus hijos, viajes y más.
                    </li>

                    <li >
                        Disponibilidad inmediata y paga menos interés que en cualquier otro crédito.Puede cancelar totalmente el crédito antes del plazo de vencimiento.
                    </li>

                    <li align="center" class="plan-action">
                        <a href="solitudCredito.php" class="btn btn-success">Solicitar Ahora</a>
                    </li>

                </ul>
            </div>
            <div id="dos" class="tabcontent">
                <ul class="plan plan4" align="justify" style="border-radius: 5px;font-size: 10pt">
                    <li align="justify" class="plan-price">
                        Es un crédito de cupo rotativo que está disponible las 24 horas del día sin necesidad de ir a la cooperativa para hacer el retiro del mismo ya que puede hacerlo a través cualquier cajero automático del país.
                    </li>
                    <!--<li>
El monto máximo a disponer es de $2.000, para ser pagaderos hasta en un año. Además, usted  paga intereses solo por el monto que utiliza cada vez que realiza una extracción y no por el cupo que tiene asignado.
</li>-->
                    <li  align="center" class="plan-action">
                        <a href="solitudCredito.php" class="btn btn-success">Solicitar Ahora</a>
                    </li>
                </ul>
            </div>
            <div id="tres" class="tabcontent">
                <ul class="plan plan4" align="justify" style="border-radius: 5px;font-size: 10pt">
                    <li class="plan-price">
                        Orientados para financiar actividades en pequeña escala de producción, comercialización o servicios, cuya fuente principal de pago constituye el producto de las ventas o ingresos generados por dichas actividades.
                    </li>
                    <!-- <li>
Hasta $<strong>50.000 </strong>dólares
</li>
<li>
La tasa de interés más conveniente a nivel del mercado financiero.
</li>-->
                    <li  align="center" class="plan-action">
                        <a href="solitudCredito.php" class="btn btn-success">Solicitar Ahora</a>
                    </li>
                </ul>
            </div>
            <div id="cuatro" class="tabcontent">
                <ul class="plan plan4" align="justify" style="border-radius: 5px;font-size: 10pt">
                    <!--<li class="plan-price">
Plazos y montos acordes a sus necesidades, hasta $50.000 Orientado a satisfacer necesidades familiares como:
</li>
<li>
1. Nivelación del presupuesto familiar, compras de artículos del hogar, salud, vestuario, estudios, viajes, vehículos de uso particular, etc.
</li>
<li>
2. La tasa de interés más competitiva del mercado financiero.
</li>-->
                    <li class="plan-price">
                        Orientado a satisfacer necesidades familiares como:
                    </li>
                    <li>
                        Nivelación del presupuesto familiar, compra de artículos para el hogar, vestuario, estudios, viajes, vehículos de uso particular, salud, etc. 
                    </li>
                    <li  align="center" class="plan-action">
                        <a href="solitudCredito.php" class="btn btn-success">Solicitar Ahora</a>
                    </li>
                </ul>
            </div>
            <div id="cinco" class="tabcontent">
                <ul class="plan plan4" align="justify" style="border-radius: 5px;font-size: 10pt">
                    <li class="plan-price">
                        Para compra y construcción de su vivienda créditos de hasta $<strong>100.000 </strong>dólares con un plazo máximo de 15 años.
                    </li>

                    <li  align="center" class="plan-action">
                        <a href="solitudCredito.php" class="btn btn-success">Solicitar Ahora</a>
                    </li>
                </ul>
            </div>

        </section>

<div id="pie" style="display:none"></div>

        <script src="js/vendor/jquery-1.9.1.min.js"></script>
        <script src="js/vendor/bootstrap.min.js"></script>
        <script src="js/main.js"></script>
    </body>
</html>
