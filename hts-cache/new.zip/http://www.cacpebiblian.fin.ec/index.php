<!DOCTYPE html>
<!--[if lt IE 7]>      <html class="no-js lt-ie9 lt-ie8 lt-ie7"> <![endif]-->
<!--[if IE 7]>         <html class="no-js lt-ie9 lt-ie8"> <![endif]-->
<!--[if IE 8]>         <html class="no-js lt-ie9"> <![endif]-->
<!--[if gt IE 8]><!-->
<html class="no-js">
<!--<![endif]-->

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
    <title>CB Cooperativa | Inicio</title>
    <meta name="description" content="">
    <meta name="viewport" content="width=device-width">
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="css/bootstrap-responsive.min.css">
    <link rel="stylesheet" href="css/font-awesome.min.css">
    <link rel="stylesheet" href="css/main.css">
    <link rel="stylesheet" href="css/sl-slide.css">
    <link rel="stylesheet" href="css/img-efect.css">
    <link rel="stylesheet" href="css/accordion.css">
    <link rel="stylesheet" href="css/social.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="css/social.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <script type="text/javascript" src="js/validar.js"></script>
    <script src="js/vendor/modernizr-2.6.2-respond-1.1.0.min.js"></script>
    <!-- Le fav and touch icons -->
    <link rel="shortcut icon" href="images/ico/icon.ico">
    <script src="js/jquery-3.2.1.min.js"></script>
    <script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
    <!--carousel-->
    <script src="js/jssor.slider-26.1.5.min.js" type="text/javascript"></script>
    <script src="js/funciones.js" type="text/javascript"></script>
    <script type="text/javascript" src="js/objetoAjax.js"></script>
    <script>
        $(document).ready(function() {
            $('.myCarousel').carousel()
            
                //$('#modal-13').modal({ keyboard: false }).load   // initialized with no keyboard
        });

    </script>
    <script>
        function redirigir(id)
        {
            location.href ="noticias.html?modal="+id;
        }
        function cargarModal()
        {
            $('#modal-publiEmp').modal('show');      
            setTimeout("ocultarModal()", 15000 );
        } 
        function ocultarModal()
        {
            // $('#modal-publiEmp').modal('hide');                   
            location.href ="https://enlinea.cbcooperativa.fin.ec:4432";
        }

    </script>
    <style>
        .contenedor-slider {
            margin: auto;
            width: 100%;
            position: relative;
            overflow: hidden;
        }

        .slider {
            display: flex;
            width: 400%;
        }

        .slider__section {
            width: 100%;
        }

        .slider__img {
            display: block;
            width: 100%;
            height: 100%;
        }

        .btn-prev,
        .btn-next {
            width: 40px;
            height: 40px;
            background: rgba(255, 255, 255, 0.7);
            position: absolute;
            top: 50%;
            transform: translateY(-50%);
            line-height: 40px;
            font-size: 30px;
            font-weight: bold;
            text-align: center;
            border-radius: 50%;
            font-family: monospace;
            cursor: pointer;
        }

        .btn-prev:hover,
        .btn-next:hover {
            background: white;
        }

        .btn-prev {
            left: 5%;
        }

        .btn-next {
            right: 5%;
        }
        .modal-body{ height: 550px;}
    </style>
<script async src="//pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
<script>
  (adsbygoogle = window.adsbygoogle || []).push({
    google_ad_client: "ca-pub-8905289264367489",
    enable_page_level_ads: true
  });
</script>
    
    <style>    
        .whatsapp {
            position:fixed;
            width:60px;
            height:60px;
            bottom:87px;
            right:25px;
            background-color:#25d366;
            color:#FFF;
            border-radius:50px;
            text-align:center;
            font-size:30px;
            z-index:100;
        }

        .whatsapp-icon {
          margin-top:15px;
        }
        
    </style>   
    
         <!-- Facebook Pixel Code -->
        <script>
          !function(f,b,e,v,n,t,s)
          {if(f.fbq)return;n=f.fbq=function(){n.callMethod?
          n.callMethod.apply(n,arguments):n.queue.push(arguments)};
          if(!f._fbq)f._fbq=n;n.push=n;n.loaded=!0;n.version='2.0';
          n.queue=[];t=b.createElement(e);t.async=!0;
          t.src=v;s=b.getElementsByTagName(e)[0];
          s.parentNode.insertBefore(t,s)}(window, document,'script',
          'https://connect.facebook.net/en_US/fbevents.js');
          fbq('init', '138315876779205');
          fbq('track', 'PageView');
        </script>
        <noscript><img height="1" width="1" style="display:none"
          src="https://www.facebook.com/tr?id=138315876779205&ev=PageView&noscript=1"
        /></noscript>
        <!-- End Facebook Pixel Code -->
                   
</head>

    <body oncontextmenu="return false"  style="background-color: #fff" >
<script>
  fbq('track', 'PaginaPrincipal');
</script>
    <!--Header-->
    <header class="navbar navbar-fixed-top">
        <div class="navbar-inner">
            <div class="container">
                <a class="btn btn-navbar" data-toggle="collapse" data-target=".nav-collapse">
          <span class="icon-bar"></span>
          <span class="icon-bar"></span>
          <span class="icon-bar"></span>
        </a>
                <a id="logo" class="pull-left" href="index.html"></a>
                <div class="nav-collapse collapse pull-right">
                    <ul class="nav">
                        <li class="active"><a href="index.html">Inicio</a></li>

                        <li class="dropdown">
                            <a href="#" class="dropdown-toggle" data-toggle="dropdown">Nosotros <i class="icon-angle-down"></i></a>
                            <ul class="dropdown-menu">
                                <li><a href="misionvision.html">Misión y Visión</a></li>
                                <li><a href="reconocimientos.html">Reseña Histórica</a></li>
                                <li><a href="noticias.html">Noticias</a></li>
                            </ul>
                        </li>

                        <li class="dropdown">
                            <a href="#" class="dropdown-toggle" data-toggle="dropdown">Productos y Servicios <i class="icon-angle-down"></i></a>
                            <ul class="dropdown-menu">
                                <li><a href="creditos.html#pricing-table">Créditos</a></li>
                                <li><a href="planesAhorro.html#pricing-table">Planes de Ahorro</a></li>
                            </ul>
                        </li>

                        <li class="dropdown">
                            <a href="#" class="dropdown-toggle" data-toggle="dropdown">Ubícanos <i class="icon-angle-down"></i></a>
                            <ul class="dropdown-menu">
                                <li><a href="sucursales.html">Directorio de Sucursales</a></li>
                                <li><a href="cajeros.html">Directorio de Cajeros Automáticos</a></li>
                            </ul>
                        </li>

                        <li class="dropdown">
                            <a href="#" class="dropdown-toggle" data-toggle="dropdown">Simuladores <i class="icon-angle-down"></i></a>
                            <ul class="dropdown-menu">
                                <li><a href="calcCredit.php">Calcule su Crédito</a></li>
                                <li><a href="calAhorro.php">Calcule su Ahorro</a></li>
                            </ul>
                        </li>

                        <li class="dropdown">
                            <a href="#" class="dropdown-toggle" data-toggle="dropdown">Servicios Online <i class="icon-angle-down"></i></a>
                            <ul class="dropdown-menu">
                                <li><a href="solitudCredito.php">Solicite su Crédito</a></li>
                                <li><a href="abrircuenta.php">Abra su Cuenta Aquí</a></li>
                            </ul>
                        </li>

                        <li class="dropdown">
                            <a href="#" class="dropdown-toggle" data-toggle="dropdown">Transparencia <i class="icon-angle-down"></i></a>
                            <ul class="dropdown-menu">
                                <li><a href="mensual.php">Informacion Mensual</a></li>
                                <li><a href="trimestral.php">Informacion Trimestral</a></li>
                                <li><a href="anual.php">Informacion Anual</a></li>
                                <li><a href="costos.php">Costos Financieros</a></li>
                                <li><a href="calificacion.php">Calificación</a></li>
                                <li><a href="resolucion.php">Resolución SEPS-IGT...0320</a></li>
                            </ul>
                        </li>

                        <li class="login">
                            <a data-toggle="modal" href="#loginForm"><i class="icon-lock"></i></a>
                        </li>
                    </ul>
                </div>
                <!--/.nav-collapse -->
            </div>
        </div>


    </header>
    <!-- /header -->
    <!--Slider-->
    <div class="container">
        <section id="slide-show">
            <div id="contenedor-slider" class="contenedor-slider">
                <div id="slider" class="slider">                                 
                    <section class="slider__section"><a href="https://play.google.com/store/apps/details?id=com.coonecta.bimo&hl=en" target="_blank"><img src="images/banners/Web2019/banner2019_6.jpg" class="slider__img" ></a></section>                      
                    <section class="slider__section"><img src="images/banners/Web2019/bannerGanadores2019.jpg" class="slider_img" onclick="window.location='ganadores_sorteo.html'" ></section>
                    <section class="slider__section"><img src="images/banners/Web2019/banner2019_1.jpg" class="slider__img"></section>
                    <section class="slider__section"><a href="https://www.cosede.gob.ec/informacion-para-entidades-financieras/" target="_blank"><img src="images/banners/Web2019/banner2019_5.jpg" class="slider__img"></a></section>
                </div>
            </div>                        
              <div id="btn-prev" class="btn-prev">&#60;</div>
              <div id="btn-next" class="btn-next">&#62;</div>
        </section>
        <br>
    </div>
    <!-- /slider-->

    <script>
        var slider = $('#slider');
        var siguiente = $('#btn-next');
        var anterior = $('#btn-prev');

        //mover ultima imagen al primer lugar
        $('#slider .slider__section:last').insertBefore('#slider .slider__section:first');
        //mostrar la primera imagen con un margen de -100%
        slider.css('margin-left', '-' + 100 + '%');

        function moverD() {
            slider.animate({
                marginLeft: '-' + 200 + '%'
            }, 700, function() {
                $('#slider .slider__section:first').insertAfter('#slider .slider__section:last');
                slider.css('margin-left', '-' + 100 + '%');
            });
        }

        function moverI() {
            slider.animate({
                marginLeft: 0
            }, 700, function() {
                $('#slider .slider__section:last').insertBefore('#slider .slider__section:first');
                slider.css('margin-left', '-' + 100 + '%');
            });
        }

        function autoplay() {
            interval = setInterval(function() {
                moverD();
            }, 5000);
        }
        siguiente.on('click', function() {
            moverD();
            clearInterval(interval);
            autoplay();
        });

        anterior.on('click', function() {
            moverI();
            clearInterval(interval);
            autoplay();
        });


        autoplay();

        function validar(e) {
            tecla = (document.all) ? e.keyCode : e.which;
            if (tecla==13)
            {
                Login();
            }
            }
    </script>

    <div class="container">
        <div class="row-fluid">
            <div class="span4 center">
                <!-- <a class="social pull-center zoom" href="https://enlinea.cbcooperativa.fin.ec:4432" target="_blank" class="shadow-top-down">-->
                <a class="social pull-center zoom" href="mensajeCB.html"  class="shadow-top-down">
                    <img src="images/btnCBenLinea.png"  style="width: 350px;" id="logoanimar"/>                
                </a>
            </div>
            <div class="span4 center">
                <h4 style="color:#666;text-align: center">Web Transaccional</h4>
                <p class="no-margin">Ahorra tu tiempo y realiza tus transferencias, consulta de saldos, pago de pensiones estudiantiles y mucho más a través de internet con nuestro nuevo servicio Online disponible las 24 horas del día</p>
            </div>            
            <div class="span4 center">
                <a class="social pull-center zoom" href="tarjetas.html" target="_blank" class="shadow-top-down">                
                <img src="images/btnTarjetas.png" style="width: 350px;" id="logoanimar"/>
                </a>
            </div>
        </div>
    </div>

    <div class="scrolldown">
        <h5 class="center" style="color:#777;">Servicios en Línea</h5>
        <a href="#services" class="scroll_btn"></a>
    </div>
    <!--Services-->
    <section id="services" style="background-image: url(images/portfolio/full/fondo1.jpg)"  style="text-align: center">
        <div class="container" style="text-align: justify">
            <div class="center gap">
                <h3>Servicios en Línea</h3>
                <p class="lead">
                    Fácil y rápido acceda a los servicios Online que le ofrecemos
                </p>
            </div>

            <div class="row-fluid">
                <div class="span4">
                    <div class="media">
                        <div class="pull-left">
                            <div class="zoom1">
                                <a class="social pull-center zoom" href="reconocimientos.html" target="_blank" class="shadow-top-down">
                  <img class="img-circle zoom1" src="images/banners/c1.png" style="width:98px;height:110;">
                </a>
                            </div>
                        </div>

                        <div class="media-body">
                            <h4 class="media-heading">Reconocimientos</h4>
                            <p>Una breve descripción de los inicios de la Cooperativa y sus reconocimientos obtenidos a lo largo de su amplia trayectoria.</p>
                        </div>
                    </div>
                </div>

                <div class="span4">
                    <div class="media">
                        <div class="pull-left">
                            <div class="zoom1">
                                <a href="calcCredit.php">
                  <img class="zoom1 img-circle" src="images/banners/c2.png" />
                </a>
                            </div>
                        </div>

                        <div class="media-body">
                            <h4 class="media-heading">Calcule su crédito</h4>
                            <p> Le brindamos la tasa de interés más conveniente del mercado y su crédito aprobado en 24 horas. </p>
                        </div>
                    </div>
                </div>

                <div class="span4">
                    <div class="media">
                        <div class="pull-left">
                            <div class="zoom1">
                                <a href="manual.html">
                 <img class="zoom1 img-circle" src="images/banners/c3.png">
                </a>
                            </div>
                        </div>

                        <div class="media-body">
                            <h4 class="media-heading">Instructivo CB en línea</h4>
                            <p> Activa tu usuario en tan solo 3 pasos y disfruta los beneficios de realizar transferencias, consulta de saldos, pago de créditos y mucho más a través del sistema transaccional web CB en línea.</p>
                        </div>
                    </div>
                </div>
            </div>

            <div class="gap"></div>

            
        </div>

    </section>
    
    <section id="recent-works">
        <div class="container">
            <div class="center">
                <h3> Mira algunos de los recientes proyectos completados por nosotros</h3>
            </div>

            <div class="gap"></div>
            <ul class="gallery col-4">
                <li>
                    <div class="preview">
                        <img alt=" " class="img-rounded" src="images/noticias/RUTA-NOCTURNA-7K/7.jpg" width="100%" style="max-height:400px">
                        <div class="overlay center">
                            Ruta Nocturna 7K "25 Años Junto a CB Cooperativa"
                        </div>
                        <div class="links center">
                            <a href="javascript:void(0);" onclick="javascript:redirigir('modal-r7k7');"><i class="icon-eye-open"></i></a> 
                        </div>
                    </div>
                </li>

                <li>
                    <div class="preview">
                        <img class="img-rounded" alt=" " src="images/noticias/NUEVA-SUCURSAL-SIGSIG/1.jpg" width="100%" style="max-height:400px">
                        <div class="overlay center">
                            Inaguración de nuestra nueva Sucursal en el Cantón Sigsig
                        </div>
                        <div class="links center">
                            <a href="javascript:void(0);" onclick="javascript:redirigir('modal-sigsig1');"><i class="icon-eye-open"></i></a> 
                        </div>
                    </div>
                </li>

                <li>
                    <div class="preview">
                        <img class="img-rounded" alt=" " src="images/noticias/CANTONIZACION-DE-PAUTE-158/1.jpg" width="100%" style="max-height:400px">
                        <div class="overlay center">
                            Desfile cívico por los 158 años de Cantonización de Paute
                        </div>
                        <div class="links center">
                            <a href="javascript:void(0);" onclick="javascript:redirigir('modal-cpaute1');"><i class="icon-eye-open"></i></a> 
                        </div>
                    </div>
                </li>

                <li>
                    <div class="preview">
                        <img alt=" " class="img-rounded" src="images/noticias/UCACSUR/1.jpg" width="100%" style="max-height:460px">
                        <div class="overlay center">
                           Asamblea General Ucacsur (Unión de Cooperativas de Ahorro y Crédito del Sur)
                        </div>
                        <div class="links center">
                            <a href="javascript:void(0);" onclick="javascript:redirigir('modal-ucacsur1');"><i class="icon-eye-open"></i></a> 
                        </div>
                    </div>
                </li>

            </ul>
        </div>
    </section>
      
           <!--
            <div id="modal-publiEmp" class="modal hide fade" style="display: none; width: 430px;height: 600px;top:10px;">
                    <a class="close-modal" href="javascript:;" data-dismiss="modal" aria-hidden="true"><i class="icon-remove"></i></a>
                    <div class="modal-inv" style="overflow: hidden;height: 600px;width: 430px;">
                        <a href="inscripcion_empredimientos.html"><img src="images/publicidadEmprendedores.png" style="width: 100%;height: 100%;" ></a>
                    </div>
                </div>
                -->
                
                 <div id="modal-publiEmp" class="modal hide fade" style="display: none; width: 632px;height: 610px;top:20px">
                    <a class="close-modal" href="javascript:;" data-dismiss="modal" aria-hidden="true"><i class="icon-remove"></i></a>
                    <div class="modal-inv" style="overflow: hidden;height: 600px;width: 622px;margin: auto">
                        <a href="https://enlinea.cbcooperativa.fin.ec:4432"><img src="images/ComunicadoCB2.jpg" style="width: 100%;height: 100%;" ></a>
                    </div>
                </div>
        
    <section id="clients" class="main">
        <div class="container">
            <div class="row-fluid">
                <div class="span2">
                    <div class="clearfix">
                        <h4 class="pull-left">Multiples Servicios</h4>
                    </div>
                    <p>Realize el Pago de Multiples Impuestos y Otros Servicios</p>
                </div>

                <div class="span10">
                    <div id="jssor_1" style="position:relative;margin:0 auto;top:0px;left:0px;width:980px;height:100px;overflow:hidden;visibility:hidden;">
                        <!-- Loading Screen -->
                        <div data-u="slides" style="cursor:default;position:relative;top:0px;left:0px;width:980px;height:100px;overflow:hidden;">
                            <div>
                                <img width="100px" height="100px" alt="" src="images/sample/clients/rise.png">
                            </div>
                            <div>
                                <img width="100px" height="100px" alt="" src="images/sample/clients/tv-cable.png">
                            </div>
                            <div>
                                <img width="100px" height="100px" alt="" src="images/sample/clients/emapal.png">
                            </div>
                            <div>
                                <img width="100px" height="100px" alt="" src="images/sample/clients/cnt.png">
                            </div>
                            <div>
                                <img width="100px" height="100px" alt="" src="images/sample/clients/sri.png">
                            </div>
                            <div>
                                <img width="100px" height="100px" alt="" src="images/sample/clients/movistar.png">
                            </div>
                            <div>
                                <img width="100px" height="100px" alt="" src="images/sample/clients/claro.png">
                            </div>
                            <div>
                                <img width="100px" height="100px" alt="" src="images/sample/clients/avon.png">
                            </div>
                            <div>
                                <img width="100px" height="100px" alt="" src="images/sample/clients/yanbal.png">
                            </div>
                            <div>
                                <img width="100px" height="100px" alt="" src="images/sample/clients/centrosur.png">
                            </div>
                            <div>
                                <img width="100px" height="100px" alt="" src="images/sample/clients/oriflame.png">
                            </div>
                            <div>
                                <img width="100px" height="100px" alt="" src="images/sample/clients/empresaElectrica.png">
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!--Bottom-->
    <section id="bottom" class="main">
        <!--Container-->
        <div class="container">
            <!--row-fluids-->
            <div class="row-fluid">
                <!--Contact Form-->
                <div class="span7">
                    <h4>UBIQUENOS</h4>
                    <ul class="unstyled address">
                        <li>
                            <i class="icon-home"></i><strong>Dirección:</strong> Mariscal Sucre 3-38 y Daniel Muñoz<br>
                        </li>
                        <li>
                            <i class="icon-envelope"></i>
                            <strong>Email: </strong> info@cbcooperativa.fin.ec
                        </li>
                        <li>
                            <i class="icon-phone"></i>
                            <strong>Teléfono:</strong> 072230836
                        </li>
                        <li>
                            <i class="icon-phone"></i>
                            <strong>Celular:</strong> 0986699573
                        </li>                        
                    </ul>
                </div>
                <!--End Contact Form-->
                <!--Important Links-->
                <div id="tweets" class="span5">
                    <h4>&nbsp;NOSOTROS</h4>
                    <div class="span3">
                        <ul class="arrow">
                            <li><a href="reconocimientos.html">Información</a></li>
                            <li><a href="sucursales.html">Contactos</a></li>
                            <li><a href="mensual.php">Transparencia</a></li>
                        </ul>
                    </div>
                    <div class="span6">
                        <ul class="arrow">
                            <li><a href="creditos.html">Productos y Servicios</a></li>
                            <li><a href="solitudCredito.php">Solicite su Crédito</a></li>
                        </ul>
                    </div>
                </div>
                <!--Important Links-->
            </div>
            <!--/row-fluid-->
        </div>
        <!--/container-->
    </section>
    <!--/bottom-->

    <!--Footer-->
    <footer id="footer">
        <div class="container">
            <div class="row-fluid">
                <div class="span5 cp">
                    &copy; 2019 <a target="_blank" href="#" title="Free Twitter Bootstrap WordPress Themes and HTML templates">CB Cooperativa</a>. All Rights Reserved.
                </div>
                <!--/Copyright-->
                <div class="span6">
                    <ul class="social pull-right">
                        <li><a href="#"><i class="icon-facebook"></i></a></li>
                        <li><a href="#"><i class="icon-twitter"></i></a></li>
                        <li><a href="#"><i class="icon-youtube"></i></a></li>
                        <li><a href="#"><i class="icon-instagram"></i></a></li>
                    </ul>
                </div>
                <div class="span1">
                    <a id="gototop" class="gototop pull-right" href="#"><i class="icon-angle-up"></i></a>
                </div>
                <!--/Goto Top-->
            </div>
        </div>
    </footer>
    <!--/Footer-->
    <!--  Login form -->
    <div class="modal hide fade in" id="loginForm" aria-hidden="false" style="height: 150px;background-color:#444444;">
        <div class="modal-header">
            <i class="icon-remove" data-dismiss="modal" aria-hidden="true"></i>
            <h4 style="text-align: center;color: aliceblue">Iniciar Sesion</h4>
        </div>
        <!--Modal Body-->
        <div class="modal-body" style="height:auto; text-align: center;background-color: #999">
            
                <input type="text" class="input-small" placeholder="Usuario" id="usuario">
                <input type="password" onkeypress="validar(event)" class="input-small" placeholder="Password" id="password">            
                <br><button onclick="Login()" class="btn btn-primary zoom">Ingresar</button>
            
        </div>
        <!--/Modal Body-->
    </div>
    <!--  /Login form -->

    <script src="js/vendor/jquery-1.9.1.min.js"></script>
    <script src="js/vendor/bootstrap.min.js"></script>
    <script src="js/main.js"></script>
    <!-- Required javascript files for Slider -->
    <script src="js/jquery.ba-cond.min.js"></script>

    <div class="sociales">
        <ul>
                     
            <li>
                <a href="https://www.facebook.com/cacpebiblian/?fref=ts" target="_blank" class="icon-facebook" title = "Facebook"></a>
            </li>
            <li>
                <a href="https://twitter.com/cacpe_biblian?lang=es" target="_blank" class="icon-twitter" title = "Twitter"></a>
            </li>
            <li>
                <a href="https://www.cosede.gob.ec/informacion-para-entidades-financieras/" target="_blank" class="icon-lock" style= 'background: #edb140' title = "Cosede"></a>
            </li>            
        </ul>
    </div>

    <!-------------------------CHAT------------------------>
    <div style=" position: fixed;right: 90px;   border-color:transparent;bottom: 0; z-index: 3000;width: 350px; height: auto; align-content: right; text-align: right;">
        <button type="button" class="btn btn-lg btn-info collapsed" data-toggle="collapse" data-target="#demo" style="width: 350px;border-radius:10px;  outline:none; margin:0px; border-color:transparent;">Dejar un mensaje <i class="fa fa-comments" aria-hidden="true"></i></button>
        <div id="demo" class="collapse" style="width:100%; border: 1px solid #398aa4; border-radius: 7px">
            <div style="background-color: rgba(255,255,255,0.7); color: #444;">
                <div class="center">
                    <br>
                    <img src="images/chat.png" style="border-radius:25px;" />
                </div>
                <table style="text-align: justify; font-size: 12px; margin-left: 20px;">
                    <tr>
                        <td colspan="2" style="color:#000000 ">Para consultas y sugerencias, por favor ingrese sus datos personales y presione enviar. <br>Lo antes posible nuestro personal se comunicará con usted. <strong>Gracias por su mensaje</strong> <b class="text-success">CB COOPERATIVA LTDA.</b></td>
                    </tr>
                    <tr>
                        <td><strong>Nombres:</strong></td>
                        <td><input name="ms1" id="ms1" type="text" onkeypress="return soloLetras(event)" required style="background:#B4CCDE     ; color:#444;border:1px solid #2A608A "></td>
                    </tr>
                    <tr>
                        <td><strong>Email:</strong></td>
                        <td><input name="ms2" id="ms2" type="email" required onkeypress="return soloCorreo(event)" style="background:#B4CCDE     ; color:#444;border:1px solid #2A608A "></td>
                    </tr>
                    <tr>
                        <td><strong>Tel&eacute;fono:</strong></td>
                        <td><input name="ms3" id="ms3" type="tel" maxlength="10" onkeypress="return soloNumeros(event)" style="background:#B4CCDE     ; color:#444;border:1px solid #2A608A "></td>
                    </tr>
                    <tr>
                        <td><strong>Direcci&oacute;n:</strong></td>
                        <td><input name="ms4" id="ms4" type="text" required onkeypress="return soloValidos(event)" style="background:#B4CCDE     ; color:#444;border:1px solid #2A608A "></td>
                    </tr>
                    <tr>
                        <td><strong>Ciudad:</strong></td>
                        <td><input name="ms5" id="ms5" type="text" required onkeypress="return soloLetras(event)" style="background:#B4CCDE     ; color:#444;border:1px solid #2A608A "></td>
                    </tr>
                    <tr>
                        <td><strong>Tema:</strong></td>
                        <td><input name="ms6" id="ms6" type="text" required onkeypress="return soloLetras(event)" style="background:#B4CCDE     ; color:#444;border:1px solid #2A608A "></td>
                    </tr>
                    <tr>
                        <td><strong>Mensaje:</strong></td>
                        <td><textarea name="ms7" id="ms7" rows="4" required onkeypress="return soloLetras(event)" style="background:#B4CCDE     ; color:#444;border:1px solid #2A608A "></textarea></td>
                    </tr>
                    <tr>
                        <td colspan="2" style="text-align: center"><input style="border-radius:10px;" class="btn zoom inputC" type="button" onclick="validarChat();" value="ENVIAR"></td>
                    </tr>
                    <tr>
                        <td colspan="2"> <br></td>
                    </tr>
                </table>
            </div>
        </div>
    </div>
        
    <!-------------------------CARTILLA DE ACTUALIZACION----------------------->
    <!--
    <div style=" position: fixed;right: 302px;   border-color:transparent;bottom: 0px; z-index: 3000;width: 350px; height: auto; align-content: right; text-align: center;">
        <button type="button" class="btn btn-lg btn-info collapsed" data-toggle="collapse" data-target="#demo2" style="width: 250px;border-radius:10px;  outline:none; margin:0px; border-color:transparent;background: #ffa251" onclick="window.location='cartilla_actualizacion.html'">Cartilla de Actualizacion <i class="fa fa-address-card" aria-hidden="true" ></i></button>       
    </div>
    -->
    <style>
        input:invalid {
            border-color: red;
        }

        input,
        input:valid {
            border-color: #444;
        }

    </style>

    <!--/////////////////Carousel////////////////////-->
    <script type="text/javascript">
        jssor_1_slider_init = function() {

            var jssor_1_options = {
                $AutoPlay: 1,
                $Idle: 0,
                $SlideDuration: 5000,
                $SlideEasing: $Jease$.$Linear,
                $PauseOnHover: 4,
                $SlideWidth: 140,
                $Cols: 7
            };

            var jssor_1_slider = new $JssorSlider$("jssor_1", jssor_1_options);
            /*#region responsive code begin*/
            var MAX_WIDTH = 980;

            function ScaleSlider() {
                var containerElement = jssor_1_slider.$Elmt.parentNode;
                var containerWidth = containerElement.clientWidth;

                if (containerWidth) {
                    var expectedWidth = Math.min(MAX_WIDTH || containerWidth, containerWidth);
                    jssor_1_slider.$ScaleWidth(expectedWidth);
                } else {
                    window.setTimeout(ScaleSlider, 30);
                }
            }

            ScaleSlider();

            $Jssor$.$AddEvent(window, "load", ScaleSlider);
            $Jssor$.$AddEvent(window, "resize", ScaleSlider);
            $Jssor$.$AddEvent(window, "orientationchange", ScaleSlider);
            /*#endregion responsive code end*/
        };

    </script>

    <style>
        /* jssor slider loading skin spin css */

        .jssorl-009-spin img {
            animation-name: jssorl-009-spin;
            animation-duration: 1.6s;
            animation-iteration-count: infinite;
            animation-timing-function: linear;
        }

        @keyframes jssorl-009-spin {
            from {
                transform: rotate(0deg);
            }
            to {
                transform: rotate(360deg);
            }
        }

    </style>

    <script type="text/javascript">
        jssor_1_slider_init();

        function Login()
        {
            var usuario  =  document.getElementById("usuario").value;
            var password =  document.getElementById("password").value;
            
            //------------CONTROL DE VARIABLES----------------//
    	    var validarUsuario  = parseInt(usuario.length);
    	    var validarPassword = parseInt(password.length);
         
            if(validarUsuario == 0) //VALIDACION DE USUARIO
            { 
                swal({
                                    title: "ERROR",
                                    icon:  "error",
                                    text:  "Verifique, Ingrese un Usuario",
                                        }); 
            }

            if(validarPassword == 0)//VALIDACION DE CONTRASEÑA
            { 
                swal({
                                    title: "ERROR",
                                    icon:  "error",
                                    text:  "Verifique, Ingrese un Password",
                                        }); 
            }            

            //--------------------------ACCESO A LA FUNCION LOGIN-----------------------//    
            if( validarUsuario > 0 &&  validarPassword > 0)
            {	                    
                var valor=1;      
                cadena="procesa="+valor+"&usuario="+usuario+"&password="+password;
                pagina = new ObjetoAjax(); //instanciamos el objeto            
                ajax = pagina.objeto; //devolvemos el XMLHttpRequest
                ajax.open("POST","login_ajax.php",true); //preparamos envio                
                ajax.onreadystatechange=function() 
                {
                   if (ajax.readyState==4 && ajax.status==200) 
                   {				     
                        var rps   = ajax.responseText.split("&");    
                      
                        var error = rps[0]; //1 (OK) - 0 (ERROR)
                        var mjs   = rps[1];
                       
                  
                        if(error == 1)
                        {                                                        
                            window.location='/reportes/index.php';
                        }                    
                        if(error == 0)
                        {                           
                            swal({
                                    title: "ERROR",
                                    icon:  "error",
                                    text:  mjs,
                                        });                                                        
                        }

                   }
                }
                ajax.setRequestHeader("Content-Type","application/x-www-form-urlencoded");
                ajax.send(cadena)                                
            }  
              
        }
    </script>

<!-- Load Facebook SDK for JavaScript -->
<div id="fb-root"></div>
<script>
  window.fbAsyncInit = function() {
    FB.init({
      xfbml            : true,
      version          : 'v3.3'
    });
  };

  (function(d, s, id) {
  var js, fjs = d.getElementsByTagName(s)[0];
  if (d.getElementById(id)) return;
  js = d.createElement(s); js.id = id;
  js.src = 'https://connect.facebook.net/es_ES/sdk/xfbml.customerchat.js';
  fjs.parentNode.insertBefore(js, fjs);
}(document, 'script', 'facebook-jssdk'));</script>

<!-- Your customer chat code -->
<div class="fb-customerchat"
  attribution=setup_tool
  page_id="950390831753046"
  theme_color="#0084ff"
  logged_in_greeting="¡Hola! como podemos ayudarte?"
  logged_out_greeting="¡Hola! como podemos ayudarte?">
</div>
        <a href="http://bit.ly/2UhY0ID" class="whatsapp" target="_blank"> <i class="fa fa-whatsapp whatsapp-icon"></i></a>
                        
</body>

</html>
