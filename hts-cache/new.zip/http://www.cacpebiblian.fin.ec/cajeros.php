<html class="no-js">

    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">

        <meta name="description" content="">
        <meta name="viewport" content="width=device-width">

        <link rel="stylesheet" href="css/bootstrap.min.css">
        <link rel="stylesheet" href="css/bootstrap-responsive.min.css">
        <link rel="stylesheet" href="css/font-awesome.min.css">
        <link rel="stylesheet" href="css/main.css">
        <link rel="stylesheet" href="css/sl-slide.css">

        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
        <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
        <link rel="stylesheet" href="css/social.css">

        <script src="js/vendor/modernizr-2.6.2-respond-1.1.0.min.js"></script>
        <script type="text/javascript" src="js/validar.js"></script>
        <script src="js/vendor/bootstrap.min.js"></script>
        <script src="js/vendor/jquery-1.9.1.min.js"></script>
        <script type="text/javascript" src="js/funciones.js"></script>
        <script type="text/javascript" src="lib/Gruntfile/Gruntfile.js"></script>
        <script type="text/javascript" src="lib/Gruntfile/js/easy-loading.min.js"></script>
        <link rel="stylesheet" href="lib/Gruntfile/css/easy-loading.min.css">
        <script async src="//pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
        <!-- Le fav and touch icons -->
        <link rel="shortcut icon" href="images/ico/icon.ico">
        <link rel="apple-touch-icon-precomposed" sizes="144x144" href="images/ico/apple-touch-icon-144-precomposed.png">
        <link rel="apple-touch-icon-precomposed" sizes="114x114" href="images/ico/apple-touch-icon-114-precomposed.png">
        <link rel="apple-touch-icon-precomposed" sizes="72x72" href="images/ico/apple-touch-icon-72-precomposed.png">
        <link rel="apple-touch-icon-precomposed" href="images/ico/apple-touch-icon-57-precomposed.png">
        <link rel="stylesheet" href="css/img-efect.css">
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
        <script src="js/jquery-3.2.1.min.js"></script>
        <link rel="stylesheet" href="css/progress-bar.css">
        <script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
        <!--carousel-->
        <script src="js/jssor.slider-26.1.5.min.js" type="text/javascript"></script>
        <script>
            $(document).ready(function(){
                //===========FUNCION PARA PONER EL PIE DE PAGINA=============//
                $("#pie").after('<!--Bottom--><section id="bottom" class="main"><!--Container--><div class="container"><!--row-fluids--><div class="row-fluid"><!--Contact Form--><div class="span7"><h4>UBIQUENOS</h4><ul class="unstyled address"><li><i class="icon-home"></i><strong>Dirección:</strong> Mariscal Sucre 3-38 y Daniel Muñoz<br></li><li><i class="icon-envelope"></i><strong>Email: </strong> info@cbcooperativa.fin.ec</li><li><i class="icon-phone"></i><strong>Teléfono:</strong> 072230836</li></ul></div><!--End Contact Form--><!--Important Links--><div id="tweets" class="span5"><h4>&nbsp;NOSOTROS</h4><div class="span3"><ul class="arrow"><li><a href="reconocimientos.php">Información</a></li><li><a href="sucursales.php">Contactos</a></li><li><a href="mensual.php">Transparencia</a></li></ul></div><div class="span6"><ul class="arrow"><li><a href="creditos.php#pricing-table">Productos y Servicios</a></li><li><a href="solitudCredito.php">Solicite su Crédito</a></li></ul></div></div><!--Important Links--></div><!--/row-fluid--></div><!--/container--></section><!--/bottom--><!--Footer--><footer id="footer"><div class="container"><div class="row-fluid"><div class="span5 cp">&copy; 2017 <a target="_blank" href="#" title="Free Twitter Bootstrap WordPress Themes and HTML templates">CB COOPERATIVA </a>. All Rights Reserved.</div><!--/Copyright--><div class="span6"><ul class="social pull-right"><li><a href="#"><i class="icon-facebook"></i></a></li><li><a href="#"><i class="icon-twitter"></i></a></li><li><a href="#"><i class="icon-youtube"></i></a></li><li><a href="#"><i class="icon-instagram"></i></a></li></ul></div><div class="span1"><a id="gototop" class="gototop pull-right" href="#"><i class="icon-angle-up"></i></a></div><!--/Goto Top--></div></div></footer><!--/Footer-->');              
            });
        </script>

   
     <style>    
        .whatsapp {
            position:fixed;
            width:60px;
            height:60px;
            bottom:87px;
            right:25px;
            background-color:#25d366;
            color:#FFF;
            border-radius:50px;
            text-align:center;
            font-size:30px;
            z-index:100;
        }

        .whatsapp-icon {
          margin-top:15px;
        }
        
    </style>        
   
    </head>

    <body oncontextmenu="return false" onload="active();redirigirNot();" style="background-color:rgb(255,255,255)">

        <!--Header-->
        <header class="navbar navbar-fixed-top">
            <div class="navbar-inner">
                <div class="container">
                    <a class="btn btn-navbar" data-toggle="collapse" data-target=".nav-collapse">
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </a>
                    <a id="logo" class="pull-left" href="index.php"></a>
                    <div class="nav-collapse collapse pull-right">
                        <ul class="nav">
                            <li id="liIndex"><a href="index.php">Inicio</a></li>
                            <li class="dropdown" id="liNos">
                                <a href="#" class="dropdown-toggle" data-toggle="dropdown">Nosotros <i class="icon-angle-down"></i></a>
                                <ul class="dropdown-menu">
                                    <li id="liMV"><a href="misionvision.php">Misión y Visión</a></li>
                                    <li id="liRH"><a href="reconocimientos.php">Reseña Histórica</a></li>
                                    <li id="liNot"><a href="noticias.php">Noticias</a></li>
                                </ul>
                            </li>
                            <li id="liPS" class="dropdown">
                                <a href="#" class="dropdown-toggle" data-toggle="dropdown">Productos y Servicios <i class="icon-angle-down"></i></a>
                                <ul class="dropdown-menu">
                                    <li id="liCred" ><a href="creditos.php#pricing-table">Créditos</a></li>
                                    <li id="liPA" ><a href="planesAhorro.php#pricing-table">Planes de Ahorro</a></li>
                                </ul>
                            </li>

                            <li id="liCont" class="dropdown">
                                <a href="#" class="dropdown-toggle" data-toggle="dropdown">Contactos <i class="icon-angle-down"></i></a>
                                <ul class="dropdown-menu">
                                    <li id="liDS"><a href="sucursales.php">Directorio de Sucursales</a></li>
                                    <li id="liDCA"><a href="cajeros.php">Directorio de Cajeros Automáticos</a></li>

                                </ul>
                            </li>

                            <li id="liSim" class="dropdown">
                                <a href="#" class="dropdown-toggle" data-toggle="dropdown">Simuladores <i class="icon-angle-down"></i></a>
                                <ul class="dropdown-menu">
                                    <li id="liCalCred"><a href="calcCredit.php">Calcule su Crédito</a></li>
                                    <li id="liCalAho"><a href="calAhorro.php">Calcule su Ahorro</a></li>
                                </ul>
                            </li>

                            <li id="liSerOnl" class="dropdown">
                                <a href="#" class="dropdown-toggle" data-toggle="dropdown">Servicios Online <i class="icon-angle-down"></i></a>
                                <ul class="dropdown-menu">
                                    <li id="liSolCred"><a href="solitudCredito.php">Solicite su Crédito</a></li>
                                    <li id="liAbCuAq"><a href="abrircuenta.php">Abra su Cuenta Aquí</a></li>
                                </ul>
                            </li>


                            <li id="liTransp" class="dropdown">
                                <a href="#" class="dropdown-toggle" data-toggle="dropdown">Transparencia <i class="icon-angle-down"></i></a>
                                <ul class="dropdown-menu">
                                    <li id="liInfMens"><a href="mensual.php">Informacion Mensual</a></li>
                                    <li id="liInfTrim"><a href="trimestral.php">Informacion Trimestral</a></li>
                                    <li id="liInfTrim"><a href="anual.php">Informacion Anual</a></li>                                    
                                    <li id="liCosFin"><a href="costos.php">Costos Financieros</a></li>
                                    <li id="liCalifi"><a href="calificacion.php">Calificacion</a></li>
                                    <li><a href="resolucion.php">Resolución SEPS-IGT...0320</a></li>
                                </ul>
                            </li>

                            <li class="login">
                                <a data-toggle="modal" href="#loginForm"><i class="icon-lock"></i></a>
                            </li>
                        </ul>
                    </div>
                    <!--/.nav-collapse -->
                </div>
            </div>


        </header>
        <!-- /header -->
        <!-------------------------CHAT------------------------>
       <div style=" position: fixed;right: 90px;   border-color:transparent;bottom: 0; z-index: 3000;width: 350px; height: auto; align-content: right; text-align: right;">
            <button type="button" class="btn btn-lg btn-info collapsed" data-toggle="collapse" data-target="#chat_cliente" style="width: 350px;border-radius:10px;  outline:none; margin:0px; border-color:transparent;">Dejar un mensaje <i class="fa fa-comments" aria-hidden="true"></i></button>
            <div id="chat_cliente" class="collapse" style="width:100%; border: 1px solid #398aa4; border-radius: 7px">
                <div style="background-color: rgba(255,255,255,0.7); color: #444;">
                    <div class="center">
                        <br>
                        <img src="images/chat.png" style="border-radius:25px;" />
                    </div>
                    <table style="text-align: justify; font-size: 12px; margin-left: 20px;">
                        <tr>
                            <td colspan="2" style="color:#000000 ">Para consultas y sugerencias, por favor ingrese sus datos personales y presione enviar. <br>Lo antes posible nuestro personal se comunicará con usted. <strong>Gracias por su mensaje</strong> <b class="text-success">CB Cooperativa LTDA.</b></td>
                        </tr>
                        <tr>
                            <td><strong>Nombres:</strong></td>
                            <td><input name="ms1" id="ms1" type="text" onkeypress="return soloLetras(event)" required style="background:#B4CCDE     ; color:#444;border:1px solid #2A608A "></td>
                        </tr>
                        <tr>
                            <td><strong>Email:</strong></td>
                            <td><input name="ms2" id="ms2" type="email" required onkeypress="return soloCorreo(event)" style="background:#B4CCDE     ; color:#444;border:1px solid #2A608A "></td>
                        </tr>
                        <tr>
                            <td><strong>Tel&eacute;fono:</strong></td>
                            <td><input name="ms3" id="ms3" type="tel" maxlength="10" onkeypress="return soloNumeros(event)" style="background:#B4CCDE     ; color:#444;border:1px solid #2A608A "></td>
                        </tr>
                        <tr>
                            <td><strong>Direcci&oacute;n:</strong></td>
                            <td><input name="ms4" id="ms4" type="text" required onkeypress="return soloValidos(event)" style="background:#B4CCDE     ; color:#444;border:1px solid #2A608A "></td>
                        </tr>
                        <tr>
                            <td><strong>Ciudad:</strong></td>
                            <td><input name="ms5" id="ms5" type="text" required onkeypress="return soloLetras(event)" style="background:#B4CCDE     ; color:#444;border:1px solid #2A608A "></td>
                        </tr>
                        <tr>
                            <td><strong>Tema:</strong></td>
                            <td><input name="ms6" id="ms6" type="text" required onkeypress="return soloLetras(event)" style="background:#B4CCDE     ; color:#444;border:1px solid #2A608A "></td>
                        </tr>
                        <tr>
                            <td><strong>Mensaje:</strong></td>
                            <td><textarea name="ms7" id="ms7" rows="4" required onkeypress="return soloLetras(event)" style="background:#B4CCDE     ; color:#444;border:1px solid #2A608A "></textarea></td>
                        </tr>
                        <tr>
                            <td colspan="2" style="text-align: center"><input style="border-radius:10px;" class="btn zoom inputC" type="button" onclick="validarChat();" value="ENVIAR"></td>
                        </tr>
                        <tr>
                            <td colspan="2"> <br></td>
                        </tr>
                    </table>
                </div>
            </div>
        </div>
        <!-------------------------//CHAT//------------------------>
        <!-------------------------CARTILLA DE ACTUALIZACION------------------------>
        <!--
           <div style=" position: fixed;right: 302px;   border-color:transparent;bottom: 0px; z-index: 3000;width: 350px; height: auto; align-content: right; text-align: center;">
            <button type="button" class="btn btn-lg btn-info collapsed" data-toggle="collapse" data-target="#cart_actual" style="width: 250px;border-radius:10px;  outline:none; margin:0px; border-color:transparent;background: #ffa251" onclick="window.location='cartilla_actualizacion.php'">Cartilla de Actualizacion <i class="fa fa-address-card" aria-hidden="true" ></i></button>            
        </div>
        -->
        <!-------------------------//CARTILLA DE ACTUALIZACION//------------------------>

        <!--REDES SOCIALES-->
        <div class="sociales">
        <ul>
                     
            <li>
                <a href="https://www.facebook.com/cacpebiblian/?fref=ts" target="_blank" class="icon-facebook" title = "Facebook"></a>
            </li>
            <li>
                <a href="https://twitter.com/cacpe_biblian?lang=es" target="_blank" class="icon-twitter" title = "Twitter"></a>
            </li>
            <li>
                <a href="https://www.cosede.gob.ec/informacion-para-entidades-financieras/" target="_blank" class="icon-lock" style= 'background: #edb140' title = "Cosede"></a>
            </li>            
        </ul>
        </div>
        <!--/REDES SOCIALES/-->
      
     
    <!-- Load Facebook SDK for JavaScript -->
<div id="fb-root"></div>
<script>
  window.fbAsyncInit = function() {
    FB.init({
      xfbml            : true,
      version          : 'v3.3'
    });
  };

  (function(d, s, id) {
  var js, fjs = d.getElementsByTagName(s)[0];
  if (d.getElementById(id)) return;
  js = d.createElement(s); js.id = id;
  js.src = 'https://connect.facebook.net/es_ES/sdk/xfbml.customerchat.js';
  fjs.parentNode.insertBefore(js, fjs);
}(document, 'script', 'facebook-jssdk'));</script>

<!-- Your customer chat code -->
<div class="fb-customerchat"
  attribution=setup_tool
  page_id="950390831753046"
  theme_color="#0084ff"
  logged_in_greeting="¡Hola! como podemos ayudarte?"
  logged_out_greeting="¡Hola! como podemos ayudarte?">
</div>
        <a href="http://bit.ly/2UhY0ID" class="whatsapp" target="_blank"> <i class="fa fa-whatsapp whatsapp-icon"></i></a>        <title>Cacpe | Cajeros Automáticos</title>
        
        <link rel="stylesheet" href="css/accordion.css">
        
        <style>
            .accordion {
                height: 40px;
            }

            .ico {

                list-style-image: url(images/cajeros/check.png);
                font-size: 11pt;
                color: black;
            }

            body {
                background-color: white;
            }

        </style>
<script>
    function active()
    {
        document.getElementById("liCont").className = "dropdown active";
        //document.getElementById("liDS").className = "active";
        document.getElementById("liDCA").className = "active";
    }
</script>
        <section class="title">
            <div class="container">
                <div class="row-fluid">
                    <div class="span6">
                        <h1>Nuestros Cajeros</h1>
                    </div>
                    <div class="span6">
                        <ul class="breadcrumb pull-right">
                            <li><a href="index.php">Inicio</a> <span class="divider">/</span></li>
                            <li><a href="#">Contactos</a> <span class="divider">/</span></li>
                            <li class="active">Nuestros Cajeros</li>
                        </ul>
                    </div>
                </div>
            </div>
        </section>
        <!-- / .title -->
        <!-- Career -->
        <section id="career" class="container">
            <div class="center">
                <h2>Red de Cajeros Automáticos a Nivel Nacional</h2>
            </div>
            <hr>
            <!-- Panel Direcciones -->
            <div class="row-fluid">
                <!-- Mapa -->
                <div class="span6">
                    <ul class="gallery">
                        <li>
                            <div class="preview">
                                <img alt=" " src="images/mapas/mapaB.png" usemap="billar">
                            </div>
                            <div class="links">
                                <map name="billar">
                                    <a data-toggle="modal" href="#modal-1">
                                        <area alt="Gualaceo"  shape="circle"  coords="402,381,17" ></a>
                                    <a data-toggle="modal" href="#modal-2"> <area alt="Azogues1"  shape="circle" coords="399,311,17" ></a>
                                    <a data-toggle="modal" href="#modal-3"> <area alt="Paute"  shape="circle" coords="458,272,17" ></a>
                                    <a data-toggle="modal" href="#modal-4"> <area alt="Azogues2"  shape="circle" coords="417,255,17" ></a>
                                    <a data-toggle="modal" href="#modal-6"> <area alt="Biblian2"  shape="circle" coords="366,239,17" ></a>
                                    <a data-toggle="modal" href="#modal-7"> <area alt="Nazon"  shape="circle" coords="304,241,17" ></a>
                                    <a data-toggle="modal" href="#modal-8"> <area alt="Cañar"  shape="circle" coords="258,208,17" ></a>
                                    <a data-toggle="modal" href="#modal-9"> <area alt="Tambo"  shape="circle" coords="369,163,17" ></a>
                                    <a data-toggle="modal" href="#modal-10"> <area alt="Suscal"  shape="circle" coords="300,124,17" ></a>
                                    <a data-toggle="modal" href="#modal-11"> <area alt="Troncal"  shape="circle" coords="129,113,17" ></a>
                                    <a data-toggle="modal" href="#modal-12"> <area alt="Cuenca1"  shape="circle" coords="287,360,17" ></a>
                                    <a data-toggle="modal" href="#modal-13"> <area alt="Cuenca2"  shape="circle" coords="221,374,17" ></a>
                                    <a data-toggle="modal" href="#modal-14"> <area alt="Cuenca3"  shape="circle" coords="192,313,15" ></a>
                                </map>
                            </div>
                            <div class="desc">
                            </div>
                            <!-- Gualaceo listo-->
                            <div id="modal-1" class="modal hide fade">
                                <a class="close-modal" href="javascript:;" data-dismiss="modal" aria-hidden="true"><i class="icon-remove"></i></a>
                                <div class="modal-body">
                                    <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3984.7401774595123!2d-78.77661239129257!3d-2.8910766253804225!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x0%3A0x97f0d88b044cb8f6!2sCooperativa+De+Ahorro+Y+Credito+CACPE+Biblian!5e0!3m2!1ses!2sec!4v1503007361449" width="540" height="400" frameborder="0" style="border:0" allowfullscreen></iframe>
                                </div>
                            </div>
                            <!-- Azogues1 listo-->
                            <div id="modal-2" class="modal hide fade">
                                <a class="close-modal" href="javascript:;" data-dismiss="modal" aria-hidden="true"><i class="icon-remove"></i></a>
                                <div class="modal-body">
                                    <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d7306.789622745113!2d-78.85372851399092!3d-2.7404053076529653!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x0%3A0x2836f638fb27e79c!2sCacpe+Biblian+Cooperativa!5e1!3m2!1ses-419!2sus!4v1502917541598" width="540" height="400" frameborder="0" style="border:0" allowfullscreen></iframe>
                                </div>
                            </div>
                            <!-- Paute listo-->
                            <div id="modal-3" class="modal hide fade">
                                <a class="close-modal" href="javascript:;" data-dismiss="modal" aria-hidden="true"><i class="icon-remove"></i></a>
                                <div class="modal-body">
                                    <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d996.2815093666959!2d-78.76168117083554!3d-2.7790459998734636!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x0%3A0x0!2zMsKwNDYnNDQuNiJTIDc4wrA0NSc0MC4xIlc!5e0!3m2!1ses!2sec!4v1503007603960" width="540" height="400" frameborder="0" style="border:0" allowfullscreen></iframe>
                                </div>
                            </div>
                            <!-- Azogues2 listo-->
                            <div id="modal-4" class="modal hide fade">
                                <a class="close-modal" href="javascript:;" data-dismiss="modal" aria-hidden="true"><i class="icon-remove"></i></a>
                                <div class="modal-body">
                                    <iframe src="https://www.google.com/maps/embed?pb=!1m17!1m11!1m3!1d908.5564811648131!2d-78.84665532762325!3d-2.736472938545494!2m2!1f0!2f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x91cd12a59ec02fd9%3A0x61c9cd8e91a29b5c!2sCacpe+Biblian+Cooperativa!5e1!3m2!1ses-419!2sus!4v1502917276639" width="540" height="400" frameborder="0" style="border:0" allowfullscreen></iframe>
                                </div>
                            </div>
                            <!-- Biblian1 listo-->
                            <div id="modal-5" class="modal hide fade">
                                <a class="close-modal" href="javascript:;" data-dismiss="modal" aria-hidden="true"><i class="icon-remove"></i></a>
                                <div class="modal-body">
                                    <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d1510.941303691589!2d-78.89018990364683!3d-2.7140344385322615!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x91d58e94c4bec091%3A0xf9a8449dc8b7f1b8!2sCarr+35%2C+Bibli%C3%A1n%2C+Ecuador!5e1!3m2!1ses-419!2sec!4v1502920031238" width="540" height="400" frameborder="0" style="border:0" allowfullscreen></iframe>
                                </div>
                            </div>
                            <!-- Biblian2 listo-->
                            <div id="modal-6" class="modal hide fade">
                                <a class="close-modal" href="javascript:;" data-dismiss="modal" aria-hidden="true"><i class="icon-remove"></i></a>
                                <div class="modal-body">
                                    <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3985.338763944603!2d-78.88912515158185!3d-2.7153087336000064!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x0%3A0xf7d6c974443c0c37!2sCACPE+BIBLIAN!5e0!3m2!1ses!2sec!4v1503007893333" width="540" height="400" frameborder="0" style="border:0" allowfullscreen></iframe>
                                </div>
                            </div>
                            <!-- Nazon listo-->
                            <div id="modal-7" class="modal hide fade">
                                <a class="close-modal" href="javascript:;" data-dismiss="modal" aria-hidden="true"><i class="icon-remove"></i></a>
                                <div class="modal-body">
                                    <iframe src="https://www.google.com/maps/embed?pb=!1m14!1m8!1m3!1d1992.6902583539973!2d-78.91007227116394!3d-2.7026224124212628!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x0%3A0x21ec571a4ed028bb!2sCACPE+BIBLIAN+NAZON!5e0!3m2!1ses!2sec!4v1503461652655" width="540" height="400" frameborder="0" style="border:0" allowfullscreen></iframe>
                                </div>
                            </div>
                            <!-- Cañar listo-->
                            <div id="modal-8" class="modal hide fade">
                                <a class="close-modal" href="javascript:;" data-dismiss="modal" aria-hidden="true"><i class="icon-remove"></i></a>
                                <div class="modal-body">
                                    <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3985.8346272904423!2d-78.93748848570192!3d-2.5605905981342536!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x91cd6605f7dbfef9%3A0x5ff75ac4b586b1e6!2sCACPE+BIBLIAN!5e0!3m2!1ses!2sec!4v1503008022137" width="540" height="400" frameborder="0" style="border:0" allowfullscreen></iframe>
                                </div>
                            </div>
                            <!-- Tambo listo-->
                            <div id="modal-9" class="modal hide fade">
                                <a class="close-modal" href="javascript:;" data-dismiss="modal" aria-hidden="true"><i class="icon-remove"></i></a>
                                <div class="modal-body">
                                    <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d249.12427796605235!2d-78.92845127227997!3d-2.5106605386481413!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x0%3A0x4fec249100fffc62!2sCacpe+Biblian+Cooperativa!5e0!3m2!1ses!2sec!4v1503008149797" width="540" height="400" frameborder="0" style="border:0" allowfullscreen></iframe>
                                </div>
                            </div>
                            <!-- Suscal listo-->
                            <div id="modal-10" class="modal hide fade">
                                <a class="close-modal" href="javascript:;" data-dismiss="modal" aria-hidden="true"><i class="icon-remove"></i></a>
                                <div class="modal-body">
                                    <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d1993.106284047245!2d-79.05443334209673!3d-2.4360809995561734!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x0%3A0x0!2zMsKwMjYnMDkuOSJTIDc5wrAwMycxMi4wIlc!5e0!3m2!1ses!2sec!4v1503008478153" width="540" height="400" frameborder="0" style="border:0" allowfullscreen></iframe>
                                </div>
                            </div>
                            <!-- Troncal listo-->
                            <div id="modal-11" class="modal hide fade">
                                <a class="close-modal" href="javascript:;" data-dismiss="modal" aria-hidden="true"><i class="icon-remove"></i></a>
                                <div class="modal-body">
                                    <iframe src="https://www.google.com/maps/embed?pb=!1m14!1m12!1m3!1d249.1405385687084!2d-79.34193822472098!3d-2.423871056507468!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!5e0!3m2!1ses-419!2sec!4v1503083767951" width="540" height="400" frameborder="0" style="border:0" allowfullscreen></iframe>
                                </div>
                            </div>
                            <!-- Cuenca1 -->
                            <div id="modal-12" class="modal hide fade">
                                <a class="close-modal" href="javascript:;" data-dismiss="modal" aria-hidden="true"><i class="icon-remove"></i></a>
                                <div class="modal-body">
                                    <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d1992.351439546776!2d-78.99413399282113!3d-2.9016767724395187!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x0%3A0x6ecdce96c9d9a16d!2sCACPE+Cooperativa+Bibli%C3%A1n!5e0!3m2!1ses-419!2s!4v1502919404004" width="540" height="400" frameborder="0" style="border:0" allowfullscreen></iframe>
                                </div>
                            </div>
                            <!-- Cuenca2 -->
                            <div id="modal-13" class="modal hide fade">
                                <a class="close-modal" href="javascript:;" data-dismiss="modal" aria-hidden="true"><i class="icon-remove"></i></a>
                                <div class="modal-body">
                                    <iframe src="https://www.google.com/maps/embed?pb=!1m14!1m8!1m3!1d249.04478228835822!2d-79.0070835!3d-2.8978055!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x0%3A0x12e4d3504f935cad!2sCacpe!5e0!3m2!1ses-419!2sec!4v1503596484774" width="600" height="450" frameborder="0" style="border:0" allowfullscreen></iframe>
                                </div>
                            </div>
                            <!-- Cuenca3 -->
                            <div id="modal-14" class="modal hide fade">
                                <a class="close-modal" href="javascript:;" data-dismiss="modal" aria-hidden="true"><i class="icon-remove"></i></a>
                                <div class="modal-body">
                                    <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d249.04392744398697!2d-78.99339414101958!3d-2.901688116711274!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x0%3A0x6ecdce96c9d9a16d!2sCACPE+Cooperativa+Bibli%C3%A1n!5e0!3m2!1ses!2sec!4v1503008921211" width="540" height="400" frameborder="0" style="border:0" allowfullscreen></iframe>
                                </div>
                            </div>
                        </li>
                    </ul>
                </div>
                <!-- /Mapa -->
                <!-- CAJEROS -->
                <div class="span6">
                    <button class="img3 accordion center">
                        <b>  &nbsp; &nbsp; &nbsp; Cajeros en Azogues </b>  </button>
                    <div class="panel">
                        <div class="row-fluid">
                            <!-- Direccion 1 -->
                            <div class="span12">
                                <ul class="ico">
                                    <li>Av. 24 de Mayo y 10 de Agosto</li>
                                    <li>Azuay entre Ayacucho y Bolívar</li>
                                    <li>Solano y Bolívar (Municipio de Azogues)</li>
                                    <li>Av. Che Guevara (Junto al Terminal Terrestre)</li>
                                    <li>Parroquia Guapán (Frente a la U.E. Guapán)</li>
                                    <li>Frente al Hospital Homero Castanier Crespo (Junto a la Clínica San Jose)</li>
                                </ul>
                            </div>
                        </div>
                    </div>
                    <!-- /Azogues -->
                    <button class="img3 accordion center">
                        <b>  &nbsp; &nbsp; &nbsp; Cajeros en Biblian </b>  </button>
                    <div class="panel">
                        <div class="row-fluid">
                            <!-- Direccion 1 -->
                            <div class="span12">
                                <ul class="ico">
                                    <li>Mariscal Sucre y Daniel Muñoz</li>
                                    <li>Av. Alberto Ochoa entre 3 de Noviembre y Tomás Sacoto</li>
                                    <li>Parroquia Nazón (Alberto Moreno y 23 de Abril)</li>
                                </ul>
                            </div>
                        </div>
                    </div>
                    <!-- /Biblian -->
                    <button class="img3 accordion center">
                        <b>  &nbsp; &nbsp; &nbsp; Cajeros en Cañar </b>  </button>
                    <div class="panel">
                        <div class="row-fluid">
                            <!-- Direccion 1 -->
                            <div class="span12">
                                <ul class="ico">
                                    <li>Av. 24 de Mayo y Carrera Cuenca</li>
                                    <li>Junto al Terminal Terrestre</li>
                                    <li>Panamericana Sur y Bolívar Quezada</li>
                                </ul>
                            </div>
                        </div>
                    </div>
                    <!-- /Cañar -->
                    <button class="img3 accordion center">
                        <b>  &nbsp; &nbsp; &nbsp; Cajeros en Cuenca </b>  </button>

                    <div class="panel">
                        <div class="row-fluid">
                            <!-- Direccion 1 -->
                            <div class="span12">
                                <ul class="ico">
                                    <li>Eloy Alfaro 4-46 (sector Mercado 12 de Abril)</li>
                                    <li>Calle Carlos Vintimilla y Julio María Montesinos (sector El Arenal)</li>
                                    <li>General Torres y Presidente Córdova (sector Plaza San Francisco)</li>
                                    <li>Mall del Río (Junto a Multicines)</li>
                                    <li>Challuabamba (Centro Comercial Plaza Sur)</li>
                                    <li>Centro Comercial Batan Shopping</li>
                                </ul>
                            </div>
                        </div>
                    </div>
                    <!-- /Cuenca -->
                    <button class="img3 accordion center">
                        <b>  &nbsp; &nbsp; &nbsp; Cajeros en El Tambo </b>  </button>
                    <div class="panel">
                        <div class="row-fluid">
                            <!-- Direccion 1 -->
                            <div class="span12">
                                <ul class="ico">
                                    <li>Panamericana y Dositeo González</li>
                                </ul>
                            </div>
                        </div>
                    </div>
                    <!-- /El Tambo -->
                    <button class="img3 accordion center">
                        <b>  &nbsp; &nbsp; &nbsp; Cajeros en Gualaceo </b>  </button>
                    <div class="panel">
                        <div class="row-fluid">
                            <!-- Direccion 1 -->
                            <div class="span12">
                                <ul class="ico">
                                    <li>Av. Jaime Roldós Aguilera y Luis Cordero (Frente al Terminal Terrestre)</li>
                                    <li>Sector Bulcay - San Pedro (vía a Gualaceo)</li>
                                </ul>
                            </div>
                        </div>
                    </div>
                    <!-- /Gualaceo -->
                    <button class="img3 accordion center">
                        <b>  &nbsp; &nbsp; &nbsp; Cajeros en La Troncal </b>  </button>
                    <div class="panel">
                        <div class="row-fluid">
                            <!-- Direccion 1 -->
                            <div class="span12">
                                <ul class="ico">
                                    <li>4 de Noviembre y Ángel María Iglesias (Frente al Parque San Gerardo)</li>
                                    <li>Av. 25 de Agosto y 1ro de Mayo</li>
                                </ul>
                            </div>
                        </div>
                    </div>
                    <!-- /La Troncal -->
                    <button class="img3 accordion center">
                        <b>  &nbsp; &nbsp; &nbsp; Cajeros en Paute </b>  </button>
                    <div class="panel">
                        <div class="row-fluid">
                            <!-- Direccion 1 -->
                            <div class="span12">
                                <ul class="ico">
                                    <li>Abdón Calderón y García Moreno</li>
                                </ul>
                            </div>
                        </div>
                    </div>
                    <!-- /Paute -->
                    <button class="img3 accordion center">
                        <b>  &nbsp; &nbsp; &nbsp; Cajeros en Suscal </b>  </button>
                    <div class="panel">
                        <div class="row-fluid">
                            <!-- Direccion 1 -->
                            <div class="span12">
                                <ul class="ico">
                                    <li>Av. Diego Delgado (junto a la parada de buses)</li>
                                </ul>
                            </div>
                        </div>
                    </div>
                    <!-- /Suscal -->
                    <button class="img3 accordion center">
                        <b>  &nbsp; &nbsp; &nbsp; Cajeros en Guachapala </b>  </button>
                    <div class="panel">
                        <div class="row-fluid">
                            <!-- Direccion 1 -->
                            <div class="span12">
                                <ul class="ico">
                                    <li>Av. 3 de Noviembre y Sixto Durán Ballén (Frente al Municipio)</li>
                                </ul>
                            </div>
                        </div>
                    </div>
                    <!-- /Guachapala -->
                    <button class="img3 accordion center">
                        <b>  &nbsp; &nbsp; &nbsp; Cajeros en Sigsig </b>  </button>
                    <div class="panel">
                        <div class="row-fluid">
                            <!-- Direccion 1 -->
                            <div class="span12">
                                <ul class="ico">
                                    <li>Sucre entre Vega y Davila</li>
                                </ul>
                            </div>
                        </div>
                    </div>
                    <!-- /Sigsi -->
                </div>
                <!-- /Cajeros -->
                <!-- /Panel Direcciones -->
            </div>
        </section>
        <!-- /Career -->

<div id="pie" style="display:none"></div>

        <script src="js/vendor/jquery-1.9.1.min.js"></script>
        <script src="js/vendor/bootstrap.min.js"></script>
        <script src="js/main.js"></script>
        <!-- Required javascript files for Slider -->
        <script src="js/jquery.ba-cond.min.js"></script>
        <script src="js/jquery.slitslider.js"></script>
        <!-- /Required javascript files for Slider -->
        <!-- SL Slider -->
        <script type="text/javascript">
            $(function() {
                var Page = (function() {

                    var $navArrows = $('#nav-arrows'),
                        slitslider = $('#slider').slitslider({
                            autoplay: true
                        }),

                        init = function() {
                            initEvents();
                        },
                        initEvents = function() {
                            $navArrows.children(':last').on('click', function() {
                                slitslider.next();
                                return false;
                            });

                            $navArrows.children(':first').on('click', function() {
                                slitslider.previous();
                                return false;
                            });
                        };

                    return {
                        init: init
                    };

                })();

                Page.init();
            });

        </script>
        <script>
            var acc = document.getElementsByClassName("accordion");
            var i;
            for (i = 0; i < acc.length; i++) {
                acc[i].onclick = function() {
                    this.classList.toggle("active");
                    var panel = this.nextElementSibling;
                    if (panel.style.maxHeight) {
                        panel.style.maxHeight = null;
                    } else {
                        panel.style.maxHeight = panel.scrollHeight + "px";
                    }
                }
            }

        </script>

    </body>

</html>
