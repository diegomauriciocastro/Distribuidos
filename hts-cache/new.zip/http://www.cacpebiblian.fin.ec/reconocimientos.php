<html class="no-js">

    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">

        <meta name="description" content="">
        <meta name="viewport" content="width=device-width">

        <link rel="stylesheet" href="css/bootstrap.min.css">
        <link rel="stylesheet" href="css/bootstrap-responsive.min.css">
        <link rel="stylesheet" href="css/font-awesome.min.css">
        <link rel="stylesheet" href="css/main.css">
        <link rel="stylesheet" href="css/sl-slide.css">

        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
        <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
        <link rel="stylesheet" href="css/social.css">

        <script src="js/vendor/modernizr-2.6.2-respond-1.1.0.min.js"></script>
        <script type="text/javascript" src="js/validar.js"></script>
        <script src="js/vendor/bootstrap.min.js"></script>
        <script src="js/vendor/jquery-1.9.1.min.js"></script>
        <script type="text/javascript" src="js/funciones.js"></script>
        <script type="text/javascript" src="lib/Gruntfile/Gruntfile.js"></script>
        <script type="text/javascript" src="lib/Gruntfile/js/easy-loading.min.js"></script>
        <link rel="stylesheet" href="lib/Gruntfile/css/easy-loading.min.css">
        <script async src="//pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
        <!-- Le fav and touch icons -->
        <link rel="shortcut icon" href="images/ico/icon.ico">
        <link rel="apple-touch-icon-precomposed" sizes="144x144" href="images/ico/apple-touch-icon-144-precomposed.png">
        <link rel="apple-touch-icon-precomposed" sizes="114x114" href="images/ico/apple-touch-icon-114-precomposed.png">
        <link rel="apple-touch-icon-precomposed" sizes="72x72" href="images/ico/apple-touch-icon-72-precomposed.png">
        <link rel="apple-touch-icon-precomposed" href="images/ico/apple-touch-icon-57-precomposed.png">
        <link rel="stylesheet" href="css/img-efect.css">
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
        <script src="js/jquery-3.2.1.min.js"></script>
        <link rel="stylesheet" href="css/progress-bar.css">
        <script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
        <!--carousel-->
        <script src="js/jssor.slider-26.1.5.min.js" type="text/javascript"></script>
        <script>
            $(document).ready(function(){
                //===========FUNCION PARA PONER EL PIE DE PAGINA=============//
                $("#pie").after('<!--Bottom--><section id="bottom" class="main"><!--Container--><div class="container"><!--row-fluids--><div class="row-fluid"><!--Contact Form--><div class="span7"><h4>UBIQUENOS</h4><ul class="unstyled address"><li><i class="icon-home"></i><strong>Dirección:</strong> Mariscal Sucre 3-38 y Daniel Muñoz<br></li><li><i class="icon-envelope"></i><strong>Email: </strong> info@cbcooperativa.fin.ec</li><li><i class="icon-phone"></i><strong>Teléfono:</strong> 072230836</li></ul></div><!--End Contact Form--><!--Important Links--><div id="tweets" class="span5"><h4>&nbsp;NOSOTROS</h4><div class="span3"><ul class="arrow"><li><a href="reconocimientos.php">Información</a></li><li><a href="sucursales.php">Contactos</a></li><li><a href="mensual.php">Transparencia</a></li></ul></div><div class="span6"><ul class="arrow"><li><a href="creditos.php#pricing-table">Productos y Servicios</a></li><li><a href="solitudCredito.php">Solicite su Crédito</a></li></ul></div></div><!--Important Links--></div><!--/row-fluid--></div><!--/container--></section><!--/bottom--><!--Footer--><footer id="footer"><div class="container"><div class="row-fluid"><div class="span5 cp">&copy; 2017 <a target="_blank" href="#" title="Free Twitter Bootstrap WordPress Themes and HTML templates">CB COOPERATIVA </a>. All Rights Reserved.</div><!--/Copyright--><div class="span6"><ul class="social pull-right"><li><a href="#"><i class="icon-facebook"></i></a></li><li><a href="#"><i class="icon-twitter"></i></a></li><li><a href="#"><i class="icon-youtube"></i></a></li><li><a href="#"><i class="icon-instagram"></i></a></li></ul></div><div class="span1"><a id="gototop" class="gototop pull-right" href="#"><i class="icon-angle-up"></i></a></div><!--/Goto Top--></div></div></footer><!--/Footer-->');              
            });
        </script>

   
     <style>    
        .whatsapp {
            position:fixed;
            width:60px;
            height:60px;
            bottom:87px;
            right:25px;
            background-color:#25d366;
            color:#FFF;
            border-radius:50px;
            text-align:center;
            font-size:30px;
            z-index:100;
        }

        .whatsapp-icon {
          margin-top:15px;
        }
        
    </style>        
   
    </head>

    <body oncontextmenu="return false" onload="active();redirigirNot();" style="background-color:rgb(255,255,255)">

        <!--Header-->
        <header class="navbar navbar-fixed-top">
            <div class="navbar-inner">
                <div class="container">
                    <a class="btn btn-navbar" data-toggle="collapse" data-target=".nav-collapse">
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </a>
                    <a id="logo" class="pull-left" href="index.php"></a>
                    <div class="nav-collapse collapse pull-right">
                        <ul class="nav">
                            <li id="liIndex"><a href="index.php">Inicio</a></li>
                            <li class="dropdown" id="liNos">
                                <a href="#" class="dropdown-toggle" data-toggle="dropdown">Nosotros <i class="icon-angle-down"></i></a>
                                <ul class="dropdown-menu">
                                    <li id="liMV"><a href="misionvision.php">Misión y Visión</a></li>
                                    <li id="liRH"><a href="reconocimientos.php">Reseña Histórica</a></li>
                                    <li id="liNot"><a href="noticias.php">Noticias</a></li>
                                </ul>
                            </li>
                            <li id="liPS" class="dropdown">
                                <a href="#" class="dropdown-toggle" data-toggle="dropdown">Productos y Servicios <i class="icon-angle-down"></i></a>
                                <ul class="dropdown-menu">
                                    <li id="liCred" ><a href="creditos.php#pricing-table">Créditos</a></li>
                                    <li id="liPA" ><a href="planesAhorro.php#pricing-table">Planes de Ahorro</a></li>
                                </ul>
                            </li>

                            <li id="liCont" class="dropdown">
                                <a href="#" class="dropdown-toggle" data-toggle="dropdown">Contactos <i class="icon-angle-down"></i></a>
                                <ul class="dropdown-menu">
                                    <li id="liDS"><a href="sucursales.php">Directorio de Sucursales</a></li>
                                    <li id="liDCA"><a href="cajeros.php">Directorio de Cajeros Automáticos</a></li>

                                </ul>
                            </li>

                            <li id="liSim" class="dropdown">
                                <a href="#" class="dropdown-toggle" data-toggle="dropdown">Simuladores <i class="icon-angle-down"></i></a>
                                <ul class="dropdown-menu">
                                    <li id="liCalCred"><a href="calcCredit.php">Calcule su Crédito</a></li>
                                    <li id="liCalAho"><a href="calAhorro.php">Calcule su Ahorro</a></li>
                                </ul>
                            </li>

                            <li id="liSerOnl" class="dropdown">
                                <a href="#" class="dropdown-toggle" data-toggle="dropdown">Servicios Online <i class="icon-angle-down"></i></a>
                                <ul class="dropdown-menu">
                                    <li id="liSolCred"><a href="solitudCredito.php">Solicite su Crédito</a></li>
                                    <li id="liAbCuAq"><a href="abrircuenta.php">Abra su Cuenta Aquí</a></li>
                                </ul>
                            </li>


                            <li id="liTransp" class="dropdown">
                                <a href="#" class="dropdown-toggle" data-toggle="dropdown">Transparencia <i class="icon-angle-down"></i></a>
                                <ul class="dropdown-menu">
                                    <li id="liInfMens"><a href="mensual.php">Informacion Mensual</a></li>
                                    <li id="liInfTrim"><a href="trimestral.php">Informacion Trimestral</a></li>
                                    <li id="liInfTrim"><a href="anual.php">Informacion Anual</a></li>                                    
                                    <li id="liCosFin"><a href="costos.php">Costos Financieros</a></li>
                                    <li id="liCalifi"><a href="calificacion.php">Calificacion</a></li>
                                    <li><a href="resolucion.php">Resolución SEPS-IGT...0320</a></li>
                                </ul>
                            </li>

                            <li class="login">
                                <a data-toggle="modal" href="#loginForm"><i class="icon-lock"></i></a>
                            </li>
                        </ul>
                    </div>
                    <!--/.nav-collapse -->
                </div>
            </div>


        </header>
        <!-- /header -->
        <!-------------------------CHAT------------------------>
       <div style=" position: fixed;right: 90px;   border-color:transparent;bottom: 0; z-index: 3000;width: 350px; height: auto; align-content: right; text-align: right;">
            <button type="button" class="btn btn-lg btn-info collapsed" data-toggle="collapse" data-target="#chat_cliente" style="width: 350px;border-radius:10px;  outline:none; margin:0px; border-color:transparent;">Dejar un mensaje <i class="fa fa-comments" aria-hidden="true"></i></button>
            <div id="chat_cliente" class="collapse" style="width:100%; border: 1px solid #398aa4; border-radius: 7px">
                <div style="background-color: rgba(255,255,255,0.7); color: #444;">
                    <div class="center">
                        <br>
                        <img src="images/chat.png" style="border-radius:25px;" />
                    </div>
                    <table style="text-align: justify; font-size: 12px; margin-left: 20px;">
                        <tr>
                            <td colspan="2" style="color:#000000 ">Para consultas y sugerencias, por favor ingrese sus datos personales y presione enviar. <br>Lo antes posible nuestro personal se comunicará con usted. <strong>Gracias por su mensaje</strong> <b class="text-success">CB Cooperativa LTDA.</b></td>
                        </tr>
                        <tr>
                            <td><strong>Nombres:</strong></td>
                            <td><input name="ms1" id="ms1" type="text" onkeypress="return soloLetras(event)" required style="background:#B4CCDE     ; color:#444;border:1px solid #2A608A "></td>
                        </tr>
                        <tr>
                            <td><strong>Email:</strong></td>
                            <td><input name="ms2" id="ms2" type="email" required onkeypress="return soloCorreo(event)" style="background:#B4CCDE     ; color:#444;border:1px solid #2A608A "></td>
                        </tr>
                        <tr>
                            <td><strong>Tel&eacute;fono:</strong></td>
                            <td><input name="ms3" id="ms3" type="tel" maxlength="10" onkeypress="return soloNumeros(event)" style="background:#B4CCDE     ; color:#444;border:1px solid #2A608A "></td>
                        </tr>
                        <tr>
                            <td><strong>Direcci&oacute;n:</strong></td>
                            <td><input name="ms4" id="ms4" type="text" required onkeypress="return soloValidos(event)" style="background:#B4CCDE     ; color:#444;border:1px solid #2A608A "></td>
                        </tr>
                        <tr>
                            <td><strong>Ciudad:</strong></td>
                            <td><input name="ms5" id="ms5" type="text" required onkeypress="return soloLetras(event)" style="background:#B4CCDE     ; color:#444;border:1px solid #2A608A "></td>
                        </tr>
                        <tr>
                            <td><strong>Tema:</strong></td>
                            <td><input name="ms6" id="ms6" type="text" required onkeypress="return soloLetras(event)" style="background:#B4CCDE     ; color:#444;border:1px solid #2A608A "></td>
                        </tr>
                        <tr>
                            <td><strong>Mensaje:</strong></td>
                            <td><textarea name="ms7" id="ms7" rows="4" required onkeypress="return soloLetras(event)" style="background:#B4CCDE     ; color:#444;border:1px solid #2A608A "></textarea></td>
                        </tr>
                        <tr>
                            <td colspan="2" style="text-align: center"><input style="border-radius:10px;" class="btn zoom inputC" type="button" onclick="validarChat();" value="ENVIAR"></td>
                        </tr>
                        <tr>
                            <td colspan="2"> <br></td>
                        </tr>
                    </table>
                </div>
            </div>
        </div>
        <!-------------------------//CHAT//------------------------>
        <!-------------------------CARTILLA DE ACTUALIZACION------------------------>
        <!--
           <div style=" position: fixed;right: 302px;   border-color:transparent;bottom: 0px; z-index: 3000;width: 350px; height: auto; align-content: right; text-align: center;">
            <button type="button" class="btn btn-lg btn-info collapsed" data-toggle="collapse" data-target="#cart_actual" style="width: 250px;border-radius:10px;  outline:none; margin:0px; border-color:transparent;background: #ffa251" onclick="window.location='cartilla_actualizacion.php'">Cartilla de Actualizacion <i class="fa fa-address-card" aria-hidden="true" ></i></button>            
        </div>
        -->
        <!-------------------------//CARTILLA DE ACTUALIZACION//------------------------>

        <!--REDES SOCIALES-->
        <div class="sociales">
        <ul>
                     
            <li>
                <a href="https://www.facebook.com/cacpebiblian/?fref=ts" target="_blank" class="icon-facebook" title = "Facebook"></a>
            </li>
            <li>
                <a href="https://twitter.com/cacpe_biblian?lang=es" target="_blank" class="icon-twitter" title = "Twitter"></a>
            </li>
            <li>
                <a href="https://www.cosede.gob.ec/informacion-para-entidades-financieras/" target="_blank" class="icon-lock" style= 'background: #edb140' title = "Cosede"></a>
            </li>            
        </ul>
        </div>
        <!--/REDES SOCIALES/-->
      
     
    <!-- Load Facebook SDK for JavaScript -->
<div id="fb-root"></div>
<script>
  window.fbAsyncInit = function() {
    FB.init({
      xfbml            : true,
      version          : 'v3.3'
    });
  };

  (function(d, s, id) {
  var js, fjs = d.getElementsByTagName(s)[0];
  if (d.getElementById(id)) return;
  js = d.createElement(s); js.id = id;
  js.src = 'https://connect.facebook.net/es_ES/sdk/xfbml.customerchat.js';
  fjs.parentNode.insertBefore(js, fjs);
}(document, 'script', 'facebook-jssdk'));</script>

<!-- Your customer chat code -->
<div class="fb-customerchat"
  attribution=setup_tool
  page_id="950390831753046"
  theme_color="#0084ff"
  logged_in_greeting="¡Hola! como podemos ayudarte?"
  logged_out_greeting="¡Hola! como podemos ayudarte?">
</div>
        <a href="http://bit.ly/2UhY0ID" class="whatsapp" target="_blank"> <i class="fa fa-whatsapp whatsapp-icon"></i></a><script>      
    function active()
    {
        document.getElementById("liNos").className = "dropdown active";
        document.getElementById("liRH").className = "active";
    }
</script>
<style>
    #aEye
    {
        padding-top: 10px;
        height:30px;
    }
</style>
<title>Cacpe | Logros y Reconocimientos</title>

<section class="title">
    <div class="container">
        <div class="row-fluid">
            <div class="span6">
                <h1>Reseña Histórica</h1>
            </div>
            <div class="span6">
                <ul class="breadcrumb pull-right">
                    <li><a href="index.php">Inicio</a> <span class="divider">/</span></li>
                    <li><a href="#">Informacion</a> <span class="divider">/</span></li>
                    <li class="active">Reseña  Histórica</li>
                </ul>
            </div>
        </div>
    </div>
</section>
<!-- / .title -->


<!-- Career -->
<section id="career" class="container">


    <div class="row-fluid">

        <h2 class="center">CACPE BIBLIAN COOPERATIVA</h2>
        <p style="font-size: 16px; text-align: justify;">CACPE BIBLIÁN es una cooperativa de ahorro y crédito que ha sido controlada por la Superintendencia de Bancos y Seguros desde el año 2005, y en la actualidad regulada bajo los estatutos de la Superintendencia de Economía Popular y Solidaria, brindando sus servicios en el Austro ecuatoriano cuyos objetivos principales fomentan en los socios y terceros mejores condiciones de trabajo y el aumento de la producción y la productividad, mediante la prestación de servicios financieros competitivos y oportunos. <br> <br> Actualmente consolidada entre las mejores Cooperativas de su clase a nivel nacional, atraviesa una gran trayectoria que inició en el año 1992, cuando un grupo de artesanos del Cantón Biblián tuvieron la idea de formar una Cooperativa dedicada a brindar soluciones y alternativas a las iniciativas de progreso de todos sus socios. Después de varias gestiones, con el apoyo y respaldo de varias organizaciones internacionales, el 21 de enero de 1993 mediante Acuerdo Ministerial 000361 es aprobada e inscrita en el Registro General de Cooperativas y el 23 de abril de 1993 abre sus oficinas en el antiguo Convento Parroquial de Biblián, instalaciones que sirvieron durante 3 años para brindar atención a sus socios.<br><br>
            Gracias al trabajo profesional y al apoyo de sus socios, cumplen con un sueño muy anhelado, inaugurar su Agencia Matriz en Biblián en el año de 1996. Este gran paso marcó el punto de partida para el crecimiento de la Cooperativa y con el objetivo de extender sus servicios en nuevos mercados incrementó su cobertura en las Provincias del Cañar y Azuay.
        </p>
    </div>
    <hr>
    <div class="center">
        <h2>SUCURSALES</h2>
    </div><hr>

    <div class="row-fluid" align="justify" >
        <div class="span6">
            <ul class="arrow" style="font-size: 16px;">
                <li><strong class="text-success">Año 1993:</strong> Matriz Biblián</li>
                <li><strong class="text-success">Año 2001:</strong> Sucursal Azogues – Calle Azuay</li>
                <li><strong class="text-success">Año 2008:</strong> Ventanilla en Nazón.</li>
                <li><strong class="text-success">Año 2008:</strong> Sucursal Cuenca - Mercado 12 de abril</li>
                <li><strong class="text-success">Año 2010:</strong> Ventanilla Biblián</li>
                <li><strong class="text-success">Año 2011:</strong> Sucursal Cañar</li>
                <li><strong class="text-success">Año 2012:</strong> Sucursal Cuenca - El Arenal</li>
                <li><strong class="text-success">Año 2013:</strong> Sucursal Azogues - Av. 24 de Mayo</li>
            </ul>
        </div>

        <div class="span6">
            <ul class="arrow" style="font-size: 16px;">
                <li><strong class="text-success">Año 2015:</strong> Sucursal Suscal</li>
                <li><strong class="text-success">Año 2015:</strong> Sucursal El Tambo</li>
                <li><strong class="text-success">Año 2015:</strong> Sucursal Gualaceo</li>
                <li><strong class="text-success">Año 2016:</strong> Sucursal La Troncal</li>
                <li><strong class="text-success">Año 2016:</strong> Sucursal Paute</li>
                <li><strong class="text-success">Año 2017:</strong> Sucursal Cuenca - Plaza San Francisco</li>
                <li><strong class="text-success">Año 2018:</strong> Sucursal Sigsig - Sucursal Cuenca (Sector Plaza San Francisco) </li>
            </ul>
        </div>


    </div>

    <br>
    <div class="center">
        <h2>RECONOCIMIENTOS</h2>
    </div><hr>
    <div class="row-fluid">
        <div class="span3">
            <img src="images/reconocimiento.jpg" style="height: 400px; width: 630;">
        </div>
        <div class="span9">
            <br>
            <ul class="arrow" style="font-size: 16px; text-align: justify">
                <li><strong class="text-success">Año 2004:</strong> Primera Institución Financiera de la Provincia del Cañar en ser regulada por el control de la Superintendencia de Bancos y Seguros.</li>
                <li><strong class="text-success">Año 2007:</strong> 3er lugar entre las Cooperativas del Ecuador. (Revista financiera GESTIÓN)</li>
                <li><strong class="text-success">Año 2008:</strong> 2do lugar a nivel nacional de acuerdo a los Indicadores CAMEL. (Revista Análisis Financiero de Walter Spurrier)</li>
                <li><strong class="text-success">Año 2009:</strong> 1er lugar a la mejor Cooperativa. (Revista Ekos)</li>
                <li><strong class="text-success">Año 2010:</strong> Calificada como la número uno de su clase en el Ranking Financiero. (Revista Gestión)</li>
                <li><strong class="text-success">Año 2012:</strong> Premio Ekos de Oro a la mejor Cooperativa. (Revista Ekos)</li>
                <li><strong class="text-success">Año 2013:</strong> 2do lugar entre las Cooperativas medianas del Ecuador. (Revista Ekos)</li>
                <li><strong class="text-success">Año 2014:</strong> 2do lugar entre las cooperativas medianas a nivel nacional. (Revista Análisis Financiero de Walter Spurrier)</li>
                <li><strong class="text-success">Año 2015:</strong> 3er lugar entre las mejores cooperativas medianas del Ecuador. (Revista Ekos)</li>
                <li><strong class="text-success">Año 2016:</strong> Premio Ekos de Oro a la mejor Cooperativa del Ecuador. (Revista Ekos)</li>
            </ul>
        </div>
    </div>
    <hr>
    <div class="row-fluid">
        <div class="span6">
            <ul class="arrow" style="font-size: 16px; text-align: justify"><br><br>
                <li><strong class="text-success">Año 2016:</strong> La reconocida calificadora de riesgo PCR PACIFIC CREDIT RATING nos otorga la calificación A-.</li>
                <li><strong class="text-success">Año 2017:</strong> La revista Ekos en su edición con el tema RANKING FINANCIERO, consolidó a Cacpe Biblián como la mejor Cooperativa de Ahorro y Crédito del Ecuador, entre las Cooperativas medianas del Segmento 1 con activos menores a $160.000.000 de dólares.</li>
                <li><strong class="text-success">Año 2017:</strong> En el mes de marzo la calificadora PACIFIC CREDIT RATING (PCR), analiza el mejoramiento y crecimiento continuo de la Cooperativa y nos otorga la CALIFICACIÓN A, convirtiéndonos en una de las selectas cooperativas de ahorro y crédito en tener tan distinguida calificación.</li>
                <li><strong class="text-success">Año 2018:</strong> Reiteramos nuestra seguridad obteniendo nuevamente la CALIFICACIÓN A por la prestigiosa calificadora PACIFIC CREDIT RATING (PCR)</li>
            </ul><br>
        </div>

        <div class="span6">
            <img src="images/reconocimiento2.jpg" style="width: 100%;">
        </div>
    </div>


</section>
<!-- /Career -->


<section id="recent-works">
    <div class="container">
        <div class="center">
            <h3>Ranking Financiero</h3>
        </div>
        <div class="gap"></div>
        <ul class="gallery col-4">

            <li>
                <div class="preview">
                    <img alt=" " src="images/portfolio/full/rank1.jpg" >
                    <div class="overlay">
                    </div>
                    <div  class="links">
                        <a id="aEye" data-toggle="modal" href="#modal-1"><i class="icon-eye-open"></i></a></div>
                </div>

                <center> <div id="modal-1" class="modal hide fade"  style="width: 500px; ">
                    <a class="close-modal" href="javascript:;" data-dismiss="modal" aria-hidden="true"><i class="icon-remove"></i></a>

                    <embed src="images/pdf/ranking1.pdf#page=1&zoom=60" align="center" width="100%" height="500px">

                    </div></center>
            </li>


            <li>
                <div class="preview">
                    <img alt=" " src="images/portfolio/full/rank2.jpg">
                    <div class="overlay">
                    </div>
                    <div class="links">
                        <a id="aEye" data-toggle="modal" href="#modal-2"><i class="icon-eye-open"></i></a>
                    </div>
                </div>
                <div class="desc">

                </div>
                <div id="modal-2" class="modal hide fade">
                    <a class="close-modal" href="javascript:;" data-dismiss="modal" aria-hidden="true"><i class="icon-remove"></i></a>
                    <embed src="images/pdf/ranking2.pdf#page=1&zoom=60" align="center" width="100%" height="500px">
                </div>
            </li>

            <li>
                <div class="preview">
                    <img alt=" " src="images/portfolio/full/rank3.jpg" style="width: 100%; height: 298px;">
                    <div class="overlay">
                    </div>
                    <div class="links">
                        <a id="aEye" data-toggle="modal" href="#modal-3"><i class="icon-eye-open"></i></a>
                    </div>
                </div>

                <div id="modal-3" class="modal hide fade">

                    <a class="close-modal" href="javascript:;" data-dismiss="modal" aria-hidden="true"><i class="icon-remove"></i></a>

                    <embed src="images/pdf/ranking3.pdf#page=1&zoom=60" align="center" width="100%" height="500px">

                </div>
            </li>
            <li>
                <div class="preview">
                    <img alt=" " src="images/portfolio/full/rank4.jpg" style="width: 100%; height: 298px;">
                    <div class="overlay">
                    </div>
                    <div class="links">
                        <a id="aEye" data-toggle="modal" href="#modal-4"><i class="icon-eye-open"></i></a>
                    </div>
                </div>

                <div id="modal-4" class="modal hide fade">

                    <a class="close-modal" href="javascript:;" data-dismiss="modal" aria-hidden="true"><i class="icon-remove"></i></a>
                    <embed src="images/pdf/ranking4.pdf" align="center" width="100%" height="500px">

                </div>
            </li>




        </ul>
    </div>


</section>

<div id="pie" style="display:none"></div>

<script src="js/vendor/jquery-1.9.1.min.js"></script>
<script src="js/vendor/bootstrap.min.js"></script>
<script src="js/main.js"></script>

</body>
</html>
