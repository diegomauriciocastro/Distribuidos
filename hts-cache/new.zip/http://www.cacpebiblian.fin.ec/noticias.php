<html class="no-js">

    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">

        <meta name="description" content="">
        <meta name="viewport" content="width=device-width">

        <link rel="stylesheet" href="css/bootstrap.min.css">
        <link rel="stylesheet" href="css/bootstrap-responsive.min.css">
        <link rel="stylesheet" href="css/font-awesome.min.css">
        <link rel="stylesheet" href="css/main.css">
        <link rel="stylesheet" href="css/sl-slide.css">

        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
        <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
        <link rel="stylesheet" href="css/social.css">

        <script src="js/vendor/modernizr-2.6.2-respond-1.1.0.min.js"></script>
        <script type="text/javascript" src="js/validar.js"></script>
        <script src="js/vendor/bootstrap.min.js"></script>
        <script src="js/vendor/jquery-1.9.1.min.js"></script>
        <script type="text/javascript" src="js/funciones.js"></script>
        <script type="text/javascript" src="lib/Gruntfile/Gruntfile.js"></script>
        <script type="text/javascript" src="lib/Gruntfile/js/easy-loading.min.js"></script>
        <link rel="stylesheet" href="lib/Gruntfile/css/easy-loading.min.css">
        <script async src="//pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
        <!-- Le fav and touch icons -->
        <link rel="shortcut icon" href="images/ico/icon.ico">
        <link rel="apple-touch-icon-precomposed" sizes="144x144" href="images/ico/apple-touch-icon-144-precomposed.png">
        <link rel="apple-touch-icon-precomposed" sizes="114x114" href="images/ico/apple-touch-icon-114-precomposed.png">
        <link rel="apple-touch-icon-precomposed" sizes="72x72" href="images/ico/apple-touch-icon-72-precomposed.png">
        <link rel="apple-touch-icon-precomposed" href="images/ico/apple-touch-icon-57-precomposed.png">
        <link rel="stylesheet" href="css/img-efect.css">
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
        <script src="js/jquery-3.2.1.min.js"></script>
        <link rel="stylesheet" href="css/progress-bar.css">
        <script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
        <!--carousel-->
        <script src="js/jssor.slider-26.1.5.min.js" type="text/javascript"></script>
        <script>
            $(document).ready(function(){
                //===========FUNCION PARA PONER EL PIE DE PAGINA=============//
                $("#pie").after('<!--Bottom--><section id="bottom" class="main"><!--Container--><div class="container"><!--row-fluids--><div class="row-fluid"><!--Contact Form--><div class="span7"><h4>UBIQUENOS</h4><ul class="unstyled address"><li><i class="icon-home"></i><strong>Dirección:</strong> Mariscal Sucre 3-38 y Daniel Muñoz<br></li><li><i class="icon-envelope"></i><strong>Email: </strong> info@cbcooperativa.fin.ec</li><li><i class="icon-phone"></i><strong>Teléfono:</strong> 072230836</li></ul></div><!--End Contact Form--><!--Important Links--><div id="tweets" class="span5"><h4>&nbsp;NOSOTROS</h4><div class="span3"><ul class="arrow"><li><a href="reconocimientos.php">Información</a></li><li><a href="sucursales.php">Contactos</a></li><li><a href="mensual.php">Transparencia</a></li></ul></div><div class="span6"><ul class="arrow"><li><a href="creditos.php#pricing-table">Productos y Servicios</a></li><li><a href="solitudCredito.php">Solicite su Crédito</a></li></ul></div></div><!--Important Links--></div><!--/row-fluid--></div><!--/container--></section><!--/bottom--><!--Footer--><footer id="footer"><div class="container"><div class="row-fluid"><div class="span5 cp">&copy; 2017 <a target="_blank" href="#" title="Free Twitter Bootstrap WordPress Themes and HTML templates">CB COOPERATIVA </a>. All Rights Reserved.</div><!--/Copyright--><div class="span6"><ul class="social pull-right"><li><a href="#"><i class="icon-facebook"></i></a></li><li><a href="#"><i class="icon-twitter"></i></a></li><li><a href="#"><i class="icon-youtube"></i></a></li><li><a href="#"><i class="icon-instagram"></i></a></li></ul></div><div class="span1"><a id="gototop" class="gototop pull-right" href="#"><i class="icon-angle-up"></i></a></div><!--/Goto Top--></div></div></footer><!--/Footer-->');              
            });
        </script>

   
     <style>    
        .whatsapp {
            position:fixed;
            width:60px;
            height:60px;
            bottom:87px;
            right:25px;
            background-color:#25d366;
            color:#FFF;
            border-radius:50px;
            text-align:center;
            font-size:30px;
            z-index:100;
        }

        .whatsapp-icon {
          margin-top:15px;
        }
        
    </style>        
   
    </head>

    <body oncontextmenu="return false" onload="active();redirigirNot();" style="background-color:rgb(255,255,255)">

        <!--Header-->
        <header class="navbar navbar-fixed-top">
            <div class="navbar-inner">
                <div class="container">
                    <a class="btn btn-navbar" data-toggle="collapse" data-target=".nav-collapse">
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </a>
                    <a id="logo" class="pull-left" href="index.php"></a>
                    <div class="nav-collapse collapse pull-right">
                        <ul class="nav">
                            <li id="liIndex"><a href="index.php">Inicio</a></li>
                            <li class="dropdown" id="liNos">
                                <a href="#" class="dropdown-toggle" data-toggle="dropdown">Nosotros <i class="icon-angle-down"></i></a>
                                <ul class="dropdown-menu">
                                    <li id="liMV"><a href="misionvision.php">Misión y Visión</a></li>
                                    <li id="liRH"><a href="reconocimientos.php">Reseña Histórica</a></li>
                                    <li id="liNot"><a href="noticias.php">Noticias</a></li>
                                </ul>
                            </li>
                            <li id="liPS" class="dropdown">
                                <a href="#" class="dropdown-toggle" data-toggle="dropdown">Productos y Servicios <i class="icon-angle-down"></i></a>
                                <ul class="dropdown-menu">
                                    <li id="liCred" ><a href="creditos.php#pricing-table">Créditos</a></li>
                                    <li id="liPA" ><a href="planesAhorro.php#pricing-table">Planes de Ahorro</a></li>
                                </ul>
                            </li>

                            <li id="liCont" class="dropdown">
                                <a href="#" class="dropdown-toggle" data-toggle="dropdown">Contactos <i class="icon-angle-down"></i></a>
                                <ul class="dropdown-menu">
                                    <li id="liDS"><a href="sucursales.php">Directorio de Sucursales</a></li>
                                    <li id="liDCA"><a href="cajeros.php">Directorio de Cajeros Automáticos</a></li>

                                </ul>
                            </li>

                            <li id="liSim" class="dropdown">
                                <a href="#" class="dropdown-toggle" data-toggle="dropdown">Simuladores <i class="icon-angle-down"></i></a>
                                <ul class="dropdown-menu">
                                    <li id="liCalCred"><a href="calcCredit.php">Calcule su Crédito</a></li>
                                    <li id="liCalAho"><a href="calAhorro.php">Calcule su Ahorro</a></li>
                                </ul>
                            </li>

                            <li id="liSerOnl" class="dropdown">
                                <a href="#" class="dropdown-toggle" data-toggle="dropdown">Servicios Online <i class="icon-angle-down"></i></a>
                                <ul class="dropdown-menu">
                                    <li id="liSolCred"><a href="solitudCredito.php">Solicite su Crédito</a></li>
                                    <li id="liAbCuAq"><a href="abrircuenta.php">Abra su Cuenta Aquí</a></li>
                                </ul>
                            </li>


                            <li id="liTransp" class="dropdown">
                                <a href="#" class="dropdown-toggle" data-toggle="dropdown">Transparencia <i class="icon-angle-down"></i></a>
                                <ul class="dropdown-menu">
                                    <li id="liInfMens"><a href="mensual.php">Informacion Mensual</a></li>
                                    <li id="liInfTrim"><a href="trimestral.php">Informacion Trimestral</a></li>
                                    <li id="liInfTrim"><a href="anual.php">Informacion Anual</a></li>                                    
                                    <li id="liCosFin"><a href="costos.php">Costos Financieros</a></li>
                                    <li id="liCalifi"><a href="calificacion.php">Calificacion</a></li>
                                    <li><a href="resolucion.php">Resolución SEPS-IGT...0320</a></li>
                                </ul>
                            </li>

                            <li class="login">
                                <a data-toggle="modal" href="#loginForm"><i class="icon-lock"></i></a>
                            </li>
                        </ul>
                    </div>
                    <!--/.nav-collapse -->
                </div>
            </div>


        </header>
        <!-- /header -->
        <!-------------------------CHAT------------------------>
       <div style=" position: fixed;right: 90px;   border-color:transparent;bottom: 0; z-index: 3000;width: 350px; height: auto; align-content: right; text-align: right;">
            <button type="button" class="btn btn-lg btn-info collapsed" data-toggle="collapse" data-target="#chat_cliente" style="width: 350px;border-radius:10px;  outline:none; margin:0px; border-color:transparent;">Dejar un mensaje <i class="fa fa-comments" aria-hidden="true"></i></button>
            <div id="chat_cliente" class="collapse" style="width:100%; border: 1px solid #398aa4; border-radius: 7px">
                <div style="background-color: rgba(255,255,255,0.7); color: #444;">
                    <div class="center">
                        <br>
                        <img src="images/chat.png" style="border-radius:25px;" />
                    </div>
                    <table style="text-align: justify; font-size: 12px; margin-left: 20px;">
                        <tr>
                            <td colspan="2" style="color:#000000 ">Para consultas y sugerencias, por favor ingrese sus datos personales y presione enviar. <br>Lo antes posible nuestro personal se comunicará con usted. <strong>Gracias por su mensaje</strong> <b class="text-success">CB Cooperativa LTDA.</b></td>
                        </tr>
                        <tr>
                            <td><strong>Nombres:</strong></td>
                            <td><input name="ms1" id="ms1" type="text" onkeypress="return soloLetras(event)" required style="background:#B4CCDE     ; color:#444;border:1px solid #2A608A "></td>
                        </tr>
                        <tr>
                            <td><strong>Email:</strong></td>
                            <td><input name="ms2" id="ms2" type="email" required onkeypress="return soloCorreo(event)" style="background:#B4CCDE     ; color:#444;border:1px solid #2A608A "></td>
                        </tr>
                        <tr>
                            <td><strong>Tel&eacute;fono:</strong></td>
                            <td><input name="ms3" id="ms3" type="tel" maxlength="10" onkeypress="return soloNumeros(event)" style="background:#B4CCDE     ; color:#444;border:1px solid #2A608A "></td>
                        </tr>
                        <tr>
                            <td><strong>Direcci&oacute;n:</strong></td>
                            <td><input name="ms4" id="ms4" type="text" required onkeypress="return soloValidos(event)" style="background:#B4CCDE     ; color:#444;border:1px solid #2A608A "></td>
                        </tr>
                        <tr>
                            <td><strong>Ciudad:</strong></td>
                            <td><input name="ms5" id="ms5" type="text" required onkeypress="return soloLetras(event)" style="background:#B4CCDE     ; color:#444;border:1px solid #2A608A "></td>
                        </tr>
                        <tr>
                            <td><strong>Tema:</strong></td>
                            <td><input name="ms6" id="ms6" type="text" required onkeypress="return soloLetras(event)" style="background:#B4CCDE     ; color:#444;border:1px solid #2A608A "></td>
                        </tr>
                        <tr>
                            <td><strong>Mensaje:</strong></td>
                            <td><textarea name="ms7" id="ms7" rows="4" required onkeypress="return soloLetras(event)" style="background:#B4CCDE     ; color:#444;border:1px solid #2A608A "></textarea></td>
                        </tr>
                        <tr>
                            <td colspan="2" style="text-align: center"><input style="border-radius:10px;" class="btn zoom inputC" type="button" onclick="validarChat();" value="ENVIAR"></td>
                        </tr>
                        <tr>
                            <td colspan="2"> <br></td>
                        </tr>
                    </table>
                </div>
            </div>
        </div>
        <!-------------------------//CHAT//------------------------>
        <!-------------------------CARTILLA DE ACTUALIZACION------------------------>
        <!--
           <div style=" position: fixed;right: 302px;   border-color:transparent;bottom: 0px; z-index: 3000;width: 350px; height: auto; align-content: right; text-align: center;">
            <button type="button" class="btn btn-lg btn-info collapsed" data-toggle="collapse" data-target="#cart_actual" style="width: 250px;border-radius:10px;  outline:none; margin:0px; border-color:transparent;background: #ffa251" onclick="window.location='cartilla_actualizacion.php'">Cartilla de Actualizacion <i class="fa fa-address-card" aria-hidden="true" ></i></button>            
        </div>
        -->
        <!-------------------------//CARTILLA DE ACTUALIZACION//------------------------>

        <!--REDES SOCIALES-->
        <div class="sociales">
        <ul>
                     
            <li>
                <a href="https://www.facebook.com/cacpebiblian/?fref=ts" target="_blank" class="icon-facebook" title = "Facebook"></a>
            </li>
            <li>
                <a href="https://twitter.com/cacpe_biblian?lang=es" target="_blank" class="icon-twitter" title = "Twitter"></a>
            </li>
            <li>
                <a href="https://www.cosede.gob.ec/informacion-para-entidades-financieras/" target="_blank" class="icon-lock" style= 'background: #edb140' title = "Cosede"></a>
            </li>            
        </ul>
        </div>
        <!--/REDES SOCIALES/-->
      
     
    <!-- Load Facebook SDK for JavaScript -->
<div id="fb-root"></div>
<script>
  window.fbAsyncInit = function() {
    FB.init({
      xfbml            : true,
      version          : 'v3.3'
    });
  };

  (function(d, s, id) {
  var js, fjs = d.getElementsByTagName(s)[0];
  if (d.getElementById(id)) return;
  js = d.createElement(s); js.id = id;
  js.src = 'https://connect.facebook.net/es_ES/sdk/xfbml.customerchat.js';
  fjs.parentNode.insertBefore(js, fjs);
}(document, 'script', 'facebook-jssdk'));</script>

<!-- Your customer chat code -->
<div class="fb-customerchat"
  attribution=setup_tool
  page_id="950390831753046"
  theme_color="#0084ff"
  logged_in_greeting="¡Hola! como podemos ayudarte?"
  logged_out_greeting="¡Hola! como podemos ayudarte?">
</div>
        <a href="http://bit.ly/2UhY0ID" class="whatsapp" target="_blank"> <i class="fa fa-whatsapp whatsapp-icon"></i></a>        <title>Cacpe | Noticias</title>

        <script>
            function getParameterByName(name) {
                name = name.replace(/[\[]/, "\\[").replace(/[\]]/, "\\]");
                var regex = new RegExp("[\\?&]" + name + "=([^&#]*)"),
                    results = regex.exec(location.search);
                return results === null ? "" : decodeURIComponent(results[1].replace(/\+/g, " "));
            }
            function redirigirNot()
            {
                var id = getParameterByName('modal');
                //alert(a);
                //$('#modal-13').modal({ keyboard: false }).load   // initialized with no keyboard
                $('#'+id).modal('show')   
            }
            function active()
            {
                document.getElementById("liNos").className = "dropdown active";
                document.getElementById("liNot").className = "active";
            }
            
        </script>
<style>
    #aEye
    {
        padding-top: 10px;
        height:30px;
    }
</style>

    

        <section class="title">
            <div class="container">
                <div class="row-fluid">
                    <div class="span6">
                        <h1>Noticias</h1>
                    </div>
                    <div class="span6">
                        <ul class="breadcrumb pull-right">
                            <li><a href="index.php">Inicio</a> <span class="divider">/</span></li>
                            <li class="active"><a href="#">Noticias</a> <span class="divider">/</span></li>

                        </ul>
                    </div>
                </div>
            </div>
        </section>
        <!-- / .title-->

        <section id="portfolio" class="container main">
            <ul class="gallery col-4">

                <!--------------------------------------------------------- JONARDAS CACPECIANAS ---------------------------------------------------------------------->
                <div>
                    <h3 align="center">Las VI Jornadas Deportivas Cacpesianas</h3>
                </div>
                <!--Item-->
                <li>
                    <div class="preview">
                        <img class="img-rounded" src="images/noticias/VI-JORNADAS-DEPORTIVAS-CACPESIANAS/1.jpg" style="height: 200px">
                        <div class="overlay">
                        </div>
                        <div class="links">
                            <a id="aEye" data-toggle="modal" href="#modal-jcacpe1"><i class="icon-eye-open"></i></a><a id="aEye" href="images/noticias/VI-JORNADAS-DEPORTIVAS-CACPESIANAS/1.jpg" download="CoopCacpeBiblian"><i class="icon-download" ></i></a>
                        </div>

                    </div>
                    <div class="desc">

                    </div>
                    <div id="modal-jcacpe1" class="modal hide fade">
                        <a class="close-modal" href="javascript:;" data-dismiss="modal" aria-hidden="true"><i class="icon-remove"></i></a>
                        <div class="modal-body">
                            <img src="images/noticias/VI-JORNADAS-DEPORTIVAS-CACPESIANAS/1.jpg" alt=" " width="100%" >
                        </div>
                    </div>
                </li>
                <!--/Item-->

                <!--Item-->
                <li>
                    <div class="preview">
                        <img class="img-rounded" src="images/noticias/VI-JORNADAS-DEPORTIVAS-CACPESIANAS/2.jpg" style="height: 200px">
                        <div class="overlay">
                        </div>
                        <div class="links">
                            <a id="aEye" data-toggle="modal" href="#modal-jcacpe2"><i class="icon-eye-open"></i></a><a id="aEye" href="images/noticias/VI-JORNADAS-DEPORTIVAS-CACPESIANAS/2.jpg" download="CoopCacpeBiblian"><i class="icon-download" ></i></a>
                        </div>
                    </div>
                    <div class="desc">

                    </div>
                    <div id="modal-jcacpe2" class="modal hide fade">
                        <a class="close-modal" href="javascript:;" data-dismiss="modal" aria-hidden="true"><i class="icon-remove"></i></a>
                        <div class="modal-body">
                            <img src="images/noticias/VI-JORNADAS-DEPORTIVAS-CACPESIANAS/2.jpg" alt=" " width="100%" style="max-height:400px">
                        </div>
                    </div>
                </li>
                <!--/Item-->

                <!--Item-->
                <li>
                    <div class="preview">
                        <img class="img-rounded" src="images/noticias/VI-JORNADAS-DEPORTIVAS-CACPESIANAS/3.jpg" style="height: 200px">
                        <div class="overlay">
                        </div>
                        <div class="links">
                            <a id="aEye" data-toggle="modal" href="#modal-jcacpe3"><i class="icon-eye-open"></i></a><a id="aEye" href="images/noticias/VI-JORNADAS-DEPORTIVAS-CACPESIANAS/3.jpg" download="CoopCacpeBiblian"><i class="icon-download" ></i></a>
                        </div>
                    </div>
                    <div class="desc">

                    </div>
                    <div id="modal-jcacpe3" class="modal hide fade">
                        <a class="close-modal" href="javascript:;" data-dismiss="modal" aria-hidden="true"><i class="icon-remove"></i></a>
                        <div class="modal-body">
                            <img src="images/noticias/VI-JORNADAS-DEPORTIVAS-CACPESIANAS/3.jpg" alt=" " width="100%" style="max-height:400px">
                        </div>
                    </div>
                </li>
                <!--/Item-->

                <!--Item-->
                <li>
                    <div class="preview">
                        <img class="img-rounded" src="images/noticias/VI-JORNADAS-DEPORTIVAS-CACPESIANAS/4.jpg" style="height: 200px">
                        <div class="overlay">
                        </div>
                        <div class="links">
                            <a id="aEye" data-toggle="modal" href="#modal-jcacpe4"><i class="icon-eye-open"></i></a><a id="aEye" href="images/noticias/VI-JORNADAS-DEPORTIVAS-CACPESIANAS/4.jpg" download="CoopCacpeBiblian"><i class="icon-download" ></i></a>
                        </div>
                    </div>
                    <div class="desc">

                    </div>
                    <div id="modal-jcacpe4" class="modal hide fade">
                        <a class="close-modal" href="javascript:;" data-dismiss="modal" aria-hidden="true"><i class="icon-remove"></i></a>
                        <div class="modal-body">
                            <img src="images/noticias/VI-JORNADAS-DEPORTIVAS-CACPESIANAS/4.jpg" alt=" " width="100%" style="max-height:400px">
                        </div>
                    </div>
                </li>
                <!--/Item-->
                <!--Item-->
                <li>
                    <div class="preview">
                        <img class="img-rounded" src="images/noticias/VI-JORNADAS-DEPORTIVAS-CACPESIANAS/5.jpg" style="height: 200px">
                        <div class="overlay">
                        </div>
                        <div class="links">
                            <a id="aEye" data-toggle="modal" href="#modal-jcacpe5"><i class="icon-eye-open"></i></a><a id="aEye" href="images/noticias/VI-JORNADAS-DEPORTIVAS-CACPESIANAS/5.jpg" download="CoopCacpeBiblian"><i class="icon-download" ></i></a>
                        </div>

                    </div>
                    <div class="desc">

                    </div>
                    <div id="modal-jcacpe5" class="modal hide fade">
                        <a class="close-modal" href="javascript:;" data-dismiss="modal" aria-hidden="true"><i class="icon-remove"></i></a>
                        <div class="modal-body">
                            <img src="images/noticias/VI-JORNADAS-DEPORTIVAS-CACPESIANAS/5.jpg" alt=" " width="100%" >
                        </div>
                    </div>
                </li>
                <!--/Item-->

                <!--Item-->
                <li>
                    <div class="preview">
                        <img class="img-rounded" src="images/noticias/VI-JORNADAS-DEPORTIVAS-CACPESIANAS/6.jpg" style="height: 200px">
                        <div class="overlay">
                        </div>
                        <div class="links">
                            <a id="aEye" data-toggle="modal" href="#modal-jcacpe6"><i class="icon-eye-open"></i></a><a id="aEye" href="images/noticias/VI-JORNADAS-DEPORTIVAS-CACPESIANAS/6.jpg" download="CoopCacpeBiblian"><i class="icon-download" ></i></a>
                        </div>
                    </div>
                    <div class="desc">

                    </div>
                    <div id="modal-jcacpe6" class="modal hide fade">
                        <a class="close-modal" href="javascript:;" data-dismiss="modal" aria-hidden="true"><i class="icon-remove"></i></a>
                        <div class="modal-body">
                            <img src="images/noticias/VI-JORNADAS-DEPORTIVAS-CACPESIANAS/6.jpg" alt=" " width="100%" style="max-height:400px">
                        </div>
                    </div>
                </li>
                <!--/Item-->

                <!--Item-->
                <li>
                    <div class="preview">
                        <img class="img-rounded" src="images/noticias/VI-JORNADAS-DEPORTIVAS-CACPESIANAS/7.jpg" style="height: 200px">
                        <div class="overlay">
                        </div>
                        <div class="links">
                            <a id="aEye" data-toggle="modal" href="#modal-jcacpe7"><i class="icon-eye-open"></i></a><a id="aEye" href="images/noticias/VI-JORNADAS-DEPORTIVAS-CACPESIANAS/7.jpg" download="CoopCacpeBiblian"><i class="icon-download" ></i></a>
                        </div>
                    </div>
                    <div class="desc">

                    </div>
                    <div id="modal-jcacpe7" class="modal hide fade">
                        <a class="close-modal" href="javascript:;" data-dismiss="modal" aria-hidden="true"><i class="icon-remove"></i></a>
                        <div class="modal-body">
                            <img src="images/noticias/VI-JORNADAS-DEPORTIVAS-CACPESIANAS/7.jpg" alt=" " width="100%" style="max-height:400px">
                        </div>
                    </div>
                </li>
                <!--/Item-->

                <!--Item-->
                <li>
                    <div class="preview">
                        <img class="img-rounded" src="images/noticias/VI-JORNADAS-DEPORTIVAS-CACPESIANAS/8.jpg" style="height: 200px">
                        <div class="overlay">
                        </div>
                        <div class="links">
                            <a id="aEye" data-toggle="modal" href="#modal-jcacpe8"><i class="icon-eye-open"></i></a><a id="aEye" href="images/noticias/VI-JORNADAS-DEPORTIVAS-CACPESIANAS/8.jpg" download="CoopCacpeBiblian"><i class="icon-download" ></i></a>
                        </div>
                    </div>
                    <div class="desc">

                    </div>
                    <div id="modal-jcacpe8" class="modal hide fade">
                        <a class="close-modal" href="javascript:;" data-dismiss="modal" aria-hidden="true"><i class="icon-remove"></i></a>
                        <div class="modal-body">
                            <img src="images/noticias/VI-JORNADAS-DEPORTIVAS-CACPESIANAS/8.jpg" alt=" " width="100%" style="max-height:400px">
                        </div>
                    </div>
                </li>
                <!--/Item-->

                <!--------------------------------------------------- JONARDAS CACPECIANAS --------------------------------------------------------------->

                <!------------------------------------------------------- RUTA NOCTURNA 7K  --------------------------------------------------------------->
                <div>
                    <h3 align="center">Ruta Nocturna 7K "25 Años Junto a CACPE BIBLIÁN"</h3>
                </div>
                <!--Item-->
                <li>
                    <div class="preview">
                        <img class="img-rounded" src="images/noticias/RUTA-NOCTURNA-7K/1.jpg" style="height: 200px">
                        <div class="overlay">
                        </div>
                        <div class="links">
                            <a id="aEye" data-toggle="modal" href="#modal-r7k1"><i class="icon-eye-open"></i></a><a id="aEye" href="images/noticias/RUTA-NOCTURNA-7K/1.jpg" download="CoopCacpeBiblian"><i class="icon-download" ></i></a>
                        </div>

                    </div>
                    <div class="desc">

                    </div>
                    <div id="modal-r7k1" class="modal hide fade">
                        <a class="close-modal" href="javascript:;" data-dismiss="modal" aria-hidden="true"><i class="icon-remove"></i></a>
                        <div class="modal-body">
                            <img src="images/noticias/RUTA-NOCTURNA-7K/1.jpg" alt=" " width="100%" >
                        </div>
                    </div>
                </li>
                <!--/Item-->

                <!--Item-->
                <li>
                    <div class="preview">
                        <img class="img-rounded" src="images/noticias/RUTA-NOCTURNA-7K/2.jpg" style="height: 200px">
                        <div class="overlay">
                        </div>
                        <div class="links">
                            <a id="aEye" data-toggle="modal" href="#modal-r7k2"><i class="icon-eye-open"></i></a><a id="aEye" href="images/noticias/RUTA-NOCTURNA-7K/2.jpg" download="CoopCacpeBiblian"><i class="icon-download" ></i></a>
                        </div>
                    </div>
                    <div class="desc">

                    </div>
                    <div id="modal-r7k2" class="modal hide fade">
                        <a class="close-modal" href="javascript:;" data-dismiss="modal" aria-hidden="true"><i class="icon-remove"></i></a>
                        <div class="modal-body">
                            <img src="images/noticias/RUTA-NOCTURNA-7K/2.jpg" alt=" " width="100%" style="max-height:400px">
                        </div>
                    </div>
                </li>
                <!--/Item-->

                <!--Item-->
                <li>
                    <div class="preview">
                        <img class="img-rounded" src="images/noticias/RUTA-NOCTURNA-7K/3.jpg" style="height: 200px">
                        <div class="overlay">
                        </div>
                        <div class="links">
                            <a id="aEye" data-toggle="modal" href="#modal-r7k3"><i class="icon-eye-open"></i></a><a id="aEye" href="images/noticias/RUTA-NOCTURNA-7K/3.jpg" download="CoopCacpeBiblian"><i class="icon-download" ></i></a>
                        </div>
                    </div>
                    <div class="desc">

                    </div>
                    <div id="modal-r7k3" class="modal hide fade">
                        <a class="close-modal" href="javascript:;" data-dismiss="modal" aria-hidden="true"><i class="icon-remove"></i></a>
                        <div class="modal-body">
                            <img src="images/noticias/RUTA-NOCTURNA-7K/3.jpg" alt=" " width="100%" style="max-height:400px">
                        </div>
                    </div>
                </li>
                <!--/Item-->

                <!--Item-->
                <li>
                    <div class="preview">
                        <img class="img-rounded" src="images/noticias/RUTA-NOCTURNA-7K/4.jpg" style="height: 200px">
                        <div class="overlay">
                        </div>
                        <div class="links">
                            <a id="aEye" data-toggle="modal" href="#modal-r7k4"><i class="icon-eye-open"></i></a><a id="aEye" href="images/noticias/RUTA-NOCTURNA-7K/4.jpg" download="CoopCacpeBiblian"><i class="icon-download" ></i></a>
                        </div>
                    </div>
                    <div class="desc">

                    </div>
                    <div id="modal-r7k4" class="modal hide fade">
                        <a class="close-modal" href="javascript:;" data-dismiss="modal" aria-hidden="true"><i class="icon-remove"></i></a>
                        <div class="modal-body">
                            <img src="images/noticias/RUTA-NOCTURNA-7K/4.jpg" alt=" " width="100%" style="max-height:400px">
                        </div>
                    </div>
                </li>
                <!--/Item-->
                <!--Item-->
                <li>
                    <div class="preview">
                        <img class="img-rounded" src="images/noticias/RUTA-NOCTURNA-7K/5.jpg" style="height: 200px">
                        <div class="overlay">
                        </div>
                        <div class="links">
                            <a id="aEye" data-toggle="modal" href="#modal-r7k5"><i class="icon-eye-open"></i></a><a id="aEye" href="images/noticias/RUTA-NOCTURNA-7K/5.jpg" download="CoopCacpeBiblian"><i class="icon-download" ></i></a>
                        </div>

                    </div>
                    <div class="desc">

                    </div>
                    <div id="modal-r7k5" class="modal hide fade">
                        <a class="close-modal" href="javascript:;" data-dismiss="modal" aria-hidden="true"><i class="icon-remove"></i></a>
                        <div class="modal-body">
                            <img src="images/noticias/RUTA-NOCTURNA-7K/5.jpg" alt=" " width="100%" >
                        </div>
                    </div>
                </li>
                <!--/Item-->

                <!--Item-->
                <li>
                    <div class="preview">
                        <img class="img-rounded" src="images/noticias/RUTA-NOCTURNA-7K/6.jpg" style="height: 200px">
                        <div class="overlay">
                        </div>
                        <div class="links">
                            <a id="aEye" data-toggle="modal" href="#modal-r7k6"><i class="icon-eye-open"></i></a><a id="aEye" href="images/noticias/RUTA-NOCTURNA-7K/6.jpg" download="CoopCacpeBiblian"><i class="icon-download" ></i></a>
                        </div>
                    </div>
                    <div class="desc">

                    </div>
                    <div id="modal-r7k6" class="modal hide fade">
                        <a id="aEye" class="close-modal" href="javascript:;" data-dismiss="modal" aria-hidden="true"><i class="icon-remove"></i></a>
                        <div class="modal-body">
                            <img src="images/noticias/RUTA-NOCTURNA-7K/6.jpg" alt=" " width="100%" style="max-height:400px">
                        </div>
                    </div>
                </li>
                <!--/Item-->

                <!--Item-->
                <li>
                    <div class="preview">
                        <img class="img-rounded" src="images/noticias/RUTA-NOCTURNA-7K/7.jpg" style="height: 200px">
                        <div class="overlay">
                        </div>
                        <div class="links">
                            <a id="aEye" data-toggle="modal" href="#modal-r7k7"><i class="icon-eye-open"></i></a><a id="aEye" href="images/noticias/RUTA-NOCTURNA-7K/7.jpg" download="CoopCacpeBiblian"><i class="icon-download" ></i></a>
                        </div>
                    </div>
                    <div class="desc">

                    </div>
                    <div id="modal-r7k7" class="modal hide fade">
                        <a class="close-modal" href="javascript:;" data-dismiss="modal" aria-hidden="true"><i class="icon-remove"></i></a>
                        <div class="modal-body">
                            <img src="images/noticias/RUTA-NOCTURNA-7K/7.jpg" alt=" " width="100%" style="max-height:400px">
                        </div>
                    </div>
                </li>
                <!--/Item-->

                <!--Item-->
                <li>
                    <div class="preview">
                        <img class="img-rounded" src="images/noticias/RUTA-NOCTURNA-7K/8.jpg" style="height: 200px">
                        <div class="overlay">
                        </div>
                        <div class="links">
                            <a id="aEye" data-toggle="modal" href="#modal-r7k8"><i class="icon-eye-open"></i></a><a id="aEye" href="images/noticias/RUTA-NOCTURNA-7K/8.jpg" download="CoopCacpeBiblian"><i class="icon-download" ></i></a>
                        </div>
                    </div>
                    <div class="desc">

                    </div>
                    <div id="modal-r7k8" class="modal hide fade">
                        <a class="close-modal" href="javascript:;" data-dismiss="modal" aria-hidden="true"><i class="icon-remove"></i></a>
                        <div class="modal-body">
                            <img src="images/noticias/RUTA-NOCTURNA-7K/8.jpg" alt=" " width="100%" style="max-height:400px">
                        </div>
                    </div>
                </li>
                <!--/Item-->

                <!--------------------------------------------------- RUTA NOCTURNA 7K --------------------------------------------------------------->


                <!--------------------------------------------------------- Sucursal el Sigsig  ---------------------------------------------------------------------->
                <div>
                    <h3 align="center">Inaguración de nuestra nueva Sucursal en el Cantón Sigsig</h3>
                </div>
                <!--Item-->
                <li>
                    <div class="preview">
                        <img class="img-rounded" src="images/noticias/NUEVA-SUCURSAL-SIGSIG/1.jpg" style="height: 200px">
                        <div class="overlay">
                        </div>
                        <div class="links">
                            <a id="aEye" data-toggle="modal" href="#modal-sigsig1"><i class="icon-eye-open"></i></a><a id="aEye" href="images/noticias/NUEVA-SUCURSAL-SIGSIG/1.jpg" download="CoopCacpeBiblian"><i class="icon-download" ></i></a>
                        </div>

                    </div>
                    <div class="desc">

                    </div>
                    <div id="modal-sigsig1" class="modal hide fade">
                        <a class="close-modal" href="javascript:;" data-dismiss="modal" aria-hidden="true"><i class="icon-remove"></i></a>
                        <div class="modal-body">
                            <img src="images/noticias/NUEVA-SUCURSAL-SIGSIG/1.jpg" alt=" " width="100%" >
                        </div>
                    </div>
                </li>
                <!--/Item-->

                <!--Item-->
                <li>
                    <div class="preview">
                        <img class="img-rounded" src="images/noticias/NUEVA-SUCURSAL-SIGSIG/2.jpg" style="height: 200px">
                        <div class="overlay">
                        </div>
                        <div class="links">
                            <a id="aEye" data-toggle="modal" href="#modal-sigsig2"><i class="icon-eye-open"></i></a><a id="aEye" href="images/noticias/NUEVA-SUCURSAL-SIGSIG/2.jpg" download="CoopCacpeBiblian"><i class="icon-download" ></i></a>
                        </div>
                    </div>
                    <div class="desc">

                    </div>
                    <div id="modal-sigsig2" class="modal hide fade">
                        <a class="close-modal" href="javascript:;" data-dismiss="modal" aria-hidden="true"><i class="icon-remove"></i></a>
                        <div class="modal-body">
                            <img src="images/noticias/NUEVA-SUCURSAL-SIGSIG/2.jpg" alt=" " width="100%" style="max-height:400px">
                        </div>
                    </div>
                </li>
                <!--/Item-->

                <!--Item-->
                <li>
                    <div class="preview">
                        <img class="img-rounded" src="images/noticias/NUEVA-SUCURSAL-SIGSIG/3.jpg" style="height: 200px">
                        <div class="overlay">
                        </div>
                        <div class="links">
                            <a id="aEye" data-toggle="modal" href="#modal-sigsig3"><i class="icon-eye-open"></i></a><a id="aEye" href="images/noticias/NUEVA-SUCURSAL-SIGSIG/3.jpg" download="CoopCacpeBiblian"><i class="icon-download" ></i></a>
                        </div>
                    </div>
                    <div class="desc">

                    </div>
                    <div id="modal-sigsig3" class="modal hide fade">
                        <a class="close-modal" href="javascript:;" data-dismiss="modal" aria-hidden="true"><i class="icon-remove"></i></a>
                        <div class="modal-body">
                            <img src="images/noticias/NUEVA-SUCURSAL-SIGSIG/3.jpg" alt=" " width="100%" style="max-height:400px">
                        </div>
                    </div>
                </li>
                <!--/Item-->

                <!--Item-->
                <li>
                    <div class="preview">
                        <img class="img-rounded" src="images/noticias/NUEVA-SUCURSAL-SIGSIG/4.jpg" style="height: 200px">
                        <div class="overlay">
                        </div>
                        <div class="links">
                            <a id="aEye" data-toggle="modal" href="#modal-sigsig4"><i class="icon-eye-open"></i></a><a id="aEye" href="images/noticias/NUEVA-SUCURSAL-SIGSIG/4.jpg" download="CoopCacpeBiblian"><i class="icon-download" ></i></a>
                        </div>
                    </div>
                    <div class="desc">

                    </div>
                    <div id="modal-sigsig4" class="modal hide fade">
                        <a class="close-modal" href="javascript:;" data-dismiss="modal" aria-hidden="true"><i class="icon-remove"></i></a>
                        <div class="modal-body">
                            <img src="images/noticias/NUEVA-SUCURSAL-SIGSIG/4.jpg" alt=" " width="100%" style="max-height:400px">
                        </div>
                    </div>
                </li>
                <!--/Item-->

                <!--------------------------------------------------- Sucursal el Sigsig --------------------------------------------------------------->


                <!--------------------------------------------------------- Cantonización de Paute  ---------------------------------------------------------------------->
                <div>
                    <h3 align="center">Desfile cívico por los 158 años de Cantonización de Paute</h3>
                </div>
                <!--Item-->
                <li>
                    <div class="preview">
                        <img class="img-rounded" src="images/noticias/CANTONIZACION-DE-PAUTE-158/1.jpg" style="height: 200px">
                        <div class="overlay">
                        </div>
                        <div class="links">
                            <a id="aEye" data-toggle="modal" href="#modal-cpaute1"><i class="icon-eye-open"></i></a><a id="aEye" href="images/noticias/CANTONIZACION-DE-PAUTE-158/1.jpg" download="CoopCacpeBiblian"><i class="icon-download" ></i></a>
                        </div>

                    </div>
                    <div class="desc">

                    </div>
                    <div id="modal-cpaute1" class="modal hide fade">
                        <a class="close-modal" href="javascript:;" data-dismiss="modal" aria-hidden="true"><i class="icon-remove"></i></a>
                        <div class="modal-body">
                            <img src="images/noticias/CANTONIZACION-DE-PAUTE-158/1.jpg" alt=" " width="100%" >
                        </div>
                    </div>
                </li>
                <!--/Item-->

                <!--Item-->
                <li>
                    <div class="preview">
                        <img class="img-rounded" src="images/noticias/CANTONIZACION-DE-PAUTE-158/2.jpg" style="height: 200px">
                        <div class="overlay">
                        </div>
                        <div class="links">
                            <a id="aEye" data-toggle="modal" href="#modal-cpaute2"><i class="icon-eye-open"></i></a><a id="aEye" href="images/noticias/CANTONIZACION-DE-PAUTE-158/2.jpg" download="CoopCacpeBiblian"><i class="icon-download" ></i></a>
                        </div>
                    </div>
                    <div class="desc">

                    </div>
                    <div id="modal-cpaute2" class="modal hide fade">
                        <a class="close-modal" href="javascript:;" data-dismiss="modal" aria-hidden="true"><i class="icon-remove"></i></a>
                        <div class="modal-body">
                            <img src="images/noticias/CANTONIZACION-DE-PAUTE-158/2.jpg" alt=" " width="100%" style="max-height:400px">
                        </div>
                    </div>
                </li>
                <!--/Item-->

                <!--Item-->
                <li>
                    <div class="preview">
                        <img class="img-rounded" src="images/noticias/CANTONIZACION-DE-PAUTE-158/4.jpg" style="height: 200px">
                        <div class="overlay">
                        </div>
                        <div class="links">
                            <a id="aEye" data-toggle="modal" href="#modal-cpaute3"><i class="icon-eye-open"></i></a><a id="aEye" href="images/noticias/CANTONIZACION-DE-PAUTE-158/4.jpg" download="CoopCacpeBiblian"><i class="icon-download" ></i></a>
                        </div>
                    </div>
                    <div class="desc">

                    </div>
                    <div id="modal-cpaute3" class="modal hide fade">
                        <a class="close-modal" href="javascript:;" data-dismiss="modal" aria-hidden="true"><i class="icon-remove"></i></a>
                        <div class="modal-body">
                            <img src="images/noticias/CANTONIZACION-DE-PAUTE-158/4.jpg" alt=" " width="100%" style="max-height:400px">
                        </div>
                    </div>
                </li>
                <!--/Item-->

                <!--Item-->
                <li>
                    <div class="preview">
                        <img class="img-rounded" src="images/noticias/CANTONIZACION-DE-PAUTE-158/5.jpg" style="height: 200px">
                        <div class="overlay">
                        </div>
                        <div class="links">
                            <a id="aEye" data-toggle="modal" href="#modal-cpaute4"><i class="icon-eye-open"></i></a><a id="aEye" href="images/noticias/CANTONIZACION-DE-PAUTE-158/5.jpg" download="CoopCacpeBiblian"><i class="icon-download" ></i></a>
                        </div>
                    </div>
                    <div class="desc">

                    </div>
                    <div id="modal-cpaute4" class="modal hide fade">
                        <a class="close-modal" href="javascript:;" data-dismiss="modal" aria-hidden="true"><i class="icon-remove"></i></a>
                        <div class="modal-body">
                            <img src="images/noticias/CANTONIZACION-DE-PAUTE-158/5.jpg" alt=" " width="100%" style="max-height:400px">
                        </div>
                    </div>
                </li>
                <!--/Item-->

                <!--------------------------------------------------- Cantonización de Paute --------------------------------------------------------------->


                <!--------------------------------------------------------- UCACSUR  ---------------------------------------------------------------------->
                <div>
                    <h3 align="center">Asamblea General Ucacsur (Unión de Cooperativas de Ahorro y Crédito del Sur)</h3>
                </div>
                <!--Item-->
                <li>
                    <div class="preview">
                        <img class="img-rounded" src="images/noticias/UCACSUR/1.jpg" style="height: 200px">
                        <div class="overlay">
                        </div>
                        <div class="links">
                            <a id="aEye" data-toggle="modal" href="#modal-ucacsur1"><i class="icon-eye-open"></i></a><a id="aEye" href="images/noticias/UCACSUR/1.jpg" download="CoopCacpeBiblian"><i class="icon-download" ></i></a>
                        </div>

                    </div>
                    <div class="desc">

                    </div>
                    <div id="modal-ucacsur1" class="modal hide fade">
                        <a class="close-modal" href="javascript:;" data-dismiss="modal" aria-hidden="true"><i class="icon-remove"></i></a>
                        <div class="modal-body">
                            <img src="images/noticias/UCACSUR/1.jpg" alt=" " width="100%" >
                        </div>
                    </div>
                </li>
                <!--/Item-->

                <!--Item-->
                <li>
                    <div class="preview">
                        <img class="img-rounded" src="images/noticias/UCACSUR/2.jpg" style="height: 200px">
                        <div class="overlay">
                        </div>
                        <div class="links">
                            <a id="aEye" data-toggle="modal" href="#modal-ucacsur2"><i class="icon-eye-open"></i></a><a id="aEye" href="images/noticias/UCACSUR/2.jpg" download="CoopCacpeBiblian"><i class="icon-download" ></i></a>
                        </div>
                    </div>
                    <div class="desc">

                    </div>
                    <div id="modal-ucacsur2" class="modal hide fade">
                        <a class="close-modal" href="javascript:;" data-dismiss="modal" aria-hidden="true"><i class="icon-remove"></i></a>
                        <div class="modal-body">
                            <img src="images/noticias/UCACSUR/2.jpg" alt=" " width="100%" style="max-height:400px">
                        </div>
                    </div>
                </li>
                <!--/Item-->

                <!--Item-->
                <li>
                    <div class="preview">
                        <img class="img-rounded" src="images/noticias/UCACSUR/3.jpg" style="height: 200px">
                        <div class="overlay">
                        </div>
                        <div class="links">
                            <a id="aEye" data-toggle="modal" href="#modal-ucacsur3"><i class="icon-eye-open"></i></a><a id="aEye" href="images/noticias/UCACSUR/3.jpg" download="CoopCacpeBiblian"><i class="icon-download" ></i></a>
                        </div>
                    </div>
                    <div class="desc">

                    </div>
                    <div id="modal-ucacsur3" class="modal hide fade">
                        <a class="close-modal" href="javascript:;" data-dismiss="modal" aria-hidden="true"><i class="icon-remove"></i></a>
                        <div class="modal-body">
                            <img src="images/noticias/UCACSUR/3.jpg" alt=" " width="100%" style="max-height:400px">
                        </div>
                    </div>
                </li>
                <!--/Item-->

                <!--Item-->
                <li>
                    <div class="preview">
                        <img class="img-rounded" src="images/noticias/UCACSUR/4.jpg" style="height: 200px">
                        <div class="overlay">
                        </div>
                        <div class="links">
                            <a id="aEye" data-toggle="modal" href="#modal-ucacsur4"><i class="icon-eye-open"></i></a><a id="aEye" href="images/noticias/UCACSUR/4.jpg" download="CoopCacpeBiblian"><i class="icon-download" ></i></a>
                        </div>
                    </div>
                    <div class="desc">

                    </div>
                    <div id="modal-ucacsur4" class="modal hide fade">
                        <a class="close-modal" href="javascript:;" data-dismiss="modal" aria-hidden="true"><i class="icon-remove"></i></a>
                        <div class="modal-body">
                            <img src="images/noticias/UCACSUR/4.jpg" alt=" " width="100%" style="max-height:400px">
                        </div>
                    </div>
                </li>
                <!--/Item-->

                <!--------------------------------------------------- UCACSUR --------------------------------------------------------------->

                <!--------------------------------------------------/ NUEVOS ---------------------------------------------------------------->

                <!--/Item 12-->
                <div>
                    <h3 align="center">Ganadores del sorteo 2017</h3>
                </div>
                <!--Item 9-->
                <li>
                    <div class="preview">
                        <img class="img-rounded" src="images/noticias/not1.jpg">
                        <div class="overlay">
                        </div>
                        <div class="links">
                            <a id="aEye" data-toggle="modal" href="#modal-13"><i class="icon-eye-open"></i></a><a id="aEye" href="images/noticias/not1.jpg" download="CoopCacpeBiblian"><i class="icon-download" ></i></a>
                        </div>

                    </div>
                    <div class="desc">

                    </div>
                    <div id="modal-13" class="modal hide fade">
                        <a class="close-modal" href="javascript:;" data-dismiss="modal" aria-hidden="true"><i class="icon-remove"></i></a>
                        <div class="modal-body">
                            <img src="images/noticias/not1.jpg" alt=" " width="100%" style="max-height:400px">
                        </div>
                    </div>
                </li>
                <!--/Item 9-->

                <!--Item 10-->
                <li>
                    <div class="preview">
                        <img class="img-rounded" src="images/noticias/not2.jpg">
                        <div class="overlay">
                        </div>
                        <div class="links">
                            <a id="aEye" data-toggle="modal" href="#modal-14"><i class="icon-eye-open"></i></a><a id="aEye" href="images/noticias/not2.jpg" download="CoopCacpeBiblian"><i class="icon-download" ></i></a>
                        </div>
                    </div>
                    <div class="desc">

                    </div>
                    <div id="modal-14" class="modal hide fade">
                        <a class="close-modal" href="javascript:;" data-dismiss="modal" aria-hidden="true"><i class="icon-remove"></i></a>
                        <div class="modal-body">
                            <img src="images/noticias/not2.jpg" alt=" " width="100%" style="max-height:400px">
                        </div>
                    </div>
                </li>
                <!--/Item 10-->

                <!--Item 11-->
                <li>
                    <div class="preview">
                        <img class="img-rounded" src="images/noticias/not3.jpg">
                        <div class="overlay">
                        </div>
                        <div class="links">
                            <a id="aEye" data-toggle="modal" href="#modal-15"><i class="icon-eye-open"></i></a><a id="aEye" href="images/noticias/not3.jpg" download="CoopCacpeBiblian"><i class="icon-download" ></i></a>
                        </div>
                    </div>
                    <div class="desc">

                    </div>
                    <div id="modal-15" class="modal hide fade">
                        <a class="close-modal" href="javascript:;" data-dismiss="modal" aria-hidden="true"><i class="icon-remove"></i></a>
                        <div class="modal-body">
                            <img src="images/noticias/not3.jpg" alt=" " width="100%" style="max-height:400px">
                        </div>
                    </div>
                </li>
                <!--/Item 11-->

                <!--Item 12-->
                <li>
                    <div class="preview">
                        <img class="img-rounded" src="images/noticias/not4.jpg" >
                        <div class="overlay">
                        </div>
                        <div class="links">
                            <a id="aEye" data-toggle="modal" href="#modal-16"><i class="icon-eye-open"></i></a><a id="aEye" href="images/noticias/not4.jpg" download="CoopCacpeBiblian"><i class="icon-download" ></i></a>
                        </div>
                    </div>
                    <div class="desc">

                    </div>
                    <div id="modal-16" class="modal hide fade">
                        <a class="close-modal" href="javascript:;" data-dismiss="modal" aria-hidden="true"><i class="icon-remove"></i></a>
                        <div class="modal-body">
                            <img src="images/noticias/not4.jpg" alt=" " width="100%" style="max-height:400px">
                        </div>
                    </div>
                </li>
                <!--/Item 12-->


                <!-- MODAL (sorteo-#) -->
                <li>
                    <div class="preview">
                        <img class="img-rounded" src="images/noticias/Ganadores2017/1.jpg">
                        <div class="overlay">
                        </div>
                        <div class="links">
                            <a id="aEye" data-toggle="modal" href="#sorteo-1"><i class="icon-eye-open"></i></a><a id="aEye" href="images/noticias/Ganadores2017/1.jpg" download="CoopCacpeBiblian"><i class="icon-download" ></i></a>
                        </div>

                    </div>
                    <div class="desc">

                    </div>
                    <div id="sorteo-1" class="modal hide fade">
                        <a class="close-modal" href="javascript:;" data-dismiss="modal" aria-hidden="true"><i class="icon-remove"></i></a>
                        <div class="modal-body">
                            <img src="images/noticias/Ganadores2017/1.jpg" alt=" " width="100%" style="max-height:400px">
                        </div>
                    </div>
                </li>

                <li>
                    <div class="preview">
                        <img class="img-rounded" src="images/noticias/Ganadores2017/2.jpg">
                        <div class="overlay">
                        </div>
                        <div class="links">
                            <a id="aEye" data-toggle="modal" href="#sorteo-2"><i class="icon-eye-open"></i></a><a id="aEye" href="images/noticias/Ganadores2017/2.jpg" download="CoopCacpeBiblian"><i class="icon-download" ></i></a>
                        </div>
                    </div>
                    <div class="desc">

                    </div>
                    <div id="sorteo-2" class="modal hide fade">
                        <a class="close-modal" href="javascript:;" data-dismiss="modal" aria-hidden="true"><i class="icon-remove"></i></a>
                        <div class="modal-body">
                            <img src="images/noticias/Ganadores2017/2.jpg" alt=" " width="100%" style="max-height:400px">
                        </div>
                    </div>
                </li>


                <li>
                    <div class="preview">
                        <img class="img-rounded" src="images/noticias/Ganadores2017/3.jpg">
                        <div class="overlay">
                        </div>
                        <div class="links">
                            <a id="aEye" data-toggle="modal" href="#sorteo-3"><i class="icon-eye-open"></i></a><a id="aEye" href="images/noticias/Ganadores2017/3.jpg" download="CoopCacpeBiblian"><i class="icon-download" ></i></a>
                        </div>

                    </div>
                    <div class="desc">

                    </div>
                    <div id="sorteo-3" class="modal hide fade">
                        <a class="close-modal" href="javascript:;" data-dismiss="modal" aria-hidden="true"><i class="icon-remove"></i></a>
                        <div class="modal-body">
                            <img src="images/noticias/Ganadores2017/3.jpg" alt=" " width="100%" style="max-height:400px">
                        </div>
                    </div>
                </li>

                <li>
                    <div class="preview">
                        <img class="img-rounded" src="images/noticias/Ganadores2017/4.jpg">
                        <div class="overlay">
                        </div>
                        <div class="links">
                            <a id="aEye" data-toggle="modal" href="#sorteo-4"><i class="icon-eye-open"></i></a><a id="aEye" href="images/noticias/Ganadores2017/4.jpg" download="CoopCacpeBiblian"><i class="icon-download" ></i></a>
                        </div>
                    </div>
                    <div class="desc">

                    </div>
                    <div id="sorteo-4" class="modal hide fade">
                        <a class="close-modal" href="javascript:;" data-dismiss="modal" aria-hidden="true"><i class="icon-remove"></i></a>
                        <div class="modal-body">
                            <img src="images/noticias/Ganadores2017/4.jpg" alt=" " width="100%" style="max-height:400px">
                        </div>
                    </div>
                </li>

                <li>
                    <div class="preview">
                        <img class="img-rounded" src="images/noticias/Ganadores2017/5.jpg">
                        <div class="overlay">
                        </div>
                        <div class="links">
                            <a id="aEye" data-toggle="modal" href="#sorteo-5"><i class="icon-eye-open"></i></a><a id="aEye" href="images/noticias/Ganadores2017/5.jpg" download="CoopCacpeBiblian"><i class="icon-download" ></i></a>
                        </div>

                    </div>
                    <div class="desc">

                    </div>
                    <div id="sorteo-5" class="modal hide fade">
                        <a class="close-modal" href="javascript:;" data-dismiss="modal" aria-hidden="true"><i class="icon-remove"></i></a>
                        <div class="modal-body">
                            <img src="images/noticias/Ganadores2017/5.jpg" alt=" " width="100%" style="max-height:400px">
                        </div>
                    </div>
                </li>

                <li>
                    <div class="preview">
                        <img class="img-rounded" src="images/noticias/Ganadores2017/6.jpg">
                        <div class="overlay">
                        </div>
                        <div class="links">
                            <a id="aEye" data-toggle="modal" href="#sorteo-6"><i class="icon-eye-open"></i></a><a id="aEye" href="images/noticias/Ganadores2017/6.jpg" download="CoopCacpeBiblian"><i class="icon-download" ></i></a>
                        </div>
                    </div>
                    <div class="desc">

                    </div>
                    <div id="sorteo-6" class="modal hide fade">
                        <a class="close-modal" href="javascript:;" data-dismiss="modal" aria-hidden="true"><i class="icon-remove"></i></a>
                        <div class="modal-body">
                            <img src="images/noticias/Ganadores2017/6.jpg" alt=" " width="100%" style="max-height:400px">
                        </div>
                    </div>
                </li>


                <li>
                    <div class="preview">
                        <img class="img-rounded" src="images/noticias/Ganadores2017/7.jpg">
                        <div class="overlay">
                        </div>
                        <div class="links">
                            <a id="aEye" data-toggle="modal" href="#sorteo-7"><i class="icon-eye-open"></i></a><a id="aEye" href="images/noticias/Ganadores2017/7.jpg" download="CoopCacpeBiblian"><i class="icon-download" ></i></a>
                        </div>
                    </div>
                    <div class="desc">

                    </div>
                    <div id="sorteo-7" class="modal hide fade">
                        <a class="close-modal" href="javascript:;" data-dismiss="modal" aria-hidden="true"><i class="icon-remove"></i></a>
                        <div class="modal-body">
                            <img src="images/noticias/Ganadores2017/7.jpg" alt=" " width="100%" style="max-height:400px">
                        </div>
                    </div>
                </li>

                <li>
                    <div class="preview">
                        <img class="img-rounded" src="images/noticias/Ganadores2017/8.jpg">
                        <div class="overlay">
                        </div>
                        <div class="links">
                            <a id="aEye" data-toggle="modal" href="#sorteo-8"><i class="icon-eye-open"></i></a><a id="aEye" href="images/noticias/Ganadores2017/8.jpg" download="CoopCacpeBiblian"><i class="icon-download" ></i></a>
                        </div>
                    </div>
                    <div class="desc">

                    </div>
                    <div id="sorteo-8" class="modal hide fade">
                        <a class="close-modal" href="javascript:;" data-dismiss="modal" aria-hidden="true"><i class="icon-remove"></i></a>
                        <div class="modal-body">
                            <img src="images/noticias/Ganadores2017/8.jpg" alt=" " width="100%" style="max-height:400px">
                        </div>
                    </div>
                </li>


                <li>
                    <div class="preview">
                        <img class="img-rounded" src="images/noticias/Ganadores2017/9.jpg">
                        <div class="overlay">
                        </div>
                        <div class="links">
                            <a id="aEye" data-toggle="modal" href="#sorteo-9"><i class="icon-eye-open"></i></a><a id="aEye" href="images/noticias/Ganadores2017/9.jpg" download="CoopCacpeBiblian"><i class="icon-download" ></i></a>
                        </div>

                    </div>
                    <div class="desc">

                    </div>
                    <div id="sorteo-9" class="modal hide fade">
                        <a class="close-modal" href="javascript:;" data-dismiss="modal" aria-hidden="true"><i class="icon-remove"></i></a>
                        <div class="modal-body">
                            <img src="images/noticias/Ganadores2017/9.jpg" alt=" " width="100%" style="max-height:400px">
                        </div>
                    </div>
                </li>

                <li>
                    <div class="preview">
                        <img class="img-rounded" src="images/noticias/Ganadores2017/10.jpg">
                        <div class="overlay">
                        </div>
                        <div class="links">
                            <a id="aEye" data-toggle="modal" href="#sorteo-10"><i class="icon-eye-open"></i></a><a id="aEye" href="images/noticias/Ganadores2017/10.jpg" download="CoopCacpeBiblian"><i class="icon-download" ></i></a>
                        </div>
                    </div>
                    <div class="desc">

                    </div>
                    <div id="sorteo-10" class="modal hide fade">
                        <a class="close-modal" href="javascript:;" data-dismiss="modal" aria-hidden="true"><i class="icon-remove"></i></a>
                        <div class="modal-body">
                            <img src="images/noticias/Ganadores2017/10.jpg" alt=" " width="100%" style="max-height:400px">
                        </div>
                    </div>
                </li>


                <li>
                    <div class="preview">
                        <img class="img-rounded" src="images/noticias/Ganadores2017/11.jpg">
                        <div class="overlay">
                        </div>
                        <div class="links">
                            <a id="aEye" data-toggle="modal" href="#sorteo-11"><i class="icon-eye-open"></i></a><a id="aEye" href="images/noticias/Ganadores2017/11.jpg" download="CoopCacpeBiblian"><i class="icon-download" ></i></a>
                        </div>
                    </div>
                    <div class="desc">

                    </div>
                    <div id="sorteo-11" class="modal hide fade">
                        <a class="close-modal" href="javascript:;" data-dismiss="modal" aria-hidden="true"><i class="icon-remove"></i></a>
                        <div class="modal-body">
                            <img src="images/noticias/Ganadores2017/11.jpg" alt=" " width="100%" style="max-height:400px">
                        </div>
                    </div>
                </li>

                <li>
                    <div class="preview">
                        <img class="img-rounded" src="images/noticias/Ganadores2017/12.jpg">
                        <div class="overlay">
                        </div>
                        <div class="links">
                            <a id="aEye" data-toggle="modal" href="#sorteo-12"><i class="icon-eye-open"></i></a><a id="aEye" href="images/noticias/Ganadores2017/12.jpg" download="CoopCacpeBiblian"><i class="icon-download" ></i></a>
                        </div>
                    </div>
                    <div class="desc">

                    </div>
                    <div id="sorteo-12" class="modal hide fade">
                        <a class="close-modal" href="javascript:;" data-dismiss="modal" aria-hidden="true"><i class="icon-remove"></i></a>
                        <div class="modal-body">
                            <img src="images/noticias/Ganadores2017/12.jpg" alt=" " width="100%" style="max-height:400px">
                        </div>
                    </div>
                </li>

                <li>
                    <div class="preview">
                        <img class="img-rounded" src="images/noticias/Ganadores2017/13.jpg">
                        <div class="overlay">
                        </div>
                        <div class="links">
                            <a id="aEye" data-toggle="modal" href="#sorteo-13"><i class="icon-eye-open"></i></a><a id="aEye" href="images/noticias/Ganadores2017/13.jpg" download="CoopCacpeBiblian"><i class="icon-download" ></i></a>
                        </div>

                    </div>
                    <div class="desc">

                    </div>
                    <div id="sorteo-13" class="modal hide fade">
                        <a class="close-modal" href="javascript:;" data-dismiss="modal" aria-hidden="true"><i class="icon-remove"></i></a>
                        <div class="modal-body">
                            <img src="images/noticias/Ganadores2017/13.jpg" alt=" " width="100%" style="max-height:400px">
                        </div>
                    </div>
                </li>

                <li>
                    <div class="preview">
                        <img class="img-rounded" src="images/noticias/Ganadores2017/14.jpg">
                        <div class="overlay">
                        </div>
                        <div class="links">
                            <a id="aEye" data-toggle="modal" href="#sorteo-14"><i class="icon-eye-open"></i></a><a id="aEye" href="images/noticias/Ganadores2017/14.jpg" download="CoopCacpeBiblian"><i class="icon-download" ></i></a>
                        </div>
                    </div>
                    <div class="desc">

                    </div>
                    <div id="sorteo-14" class="modal hide fade">
                        <a class="close-modal" href="javascript:;" data-dismiss="modal" aria-hidden="true"><i class="icon-remove"></i></a>
                        <div class="modal-body">
                            <img src="images/noticias/Ganadores2017/14.jpg" alt=" " width="100%" style="max-height:400px">
                        </div>
                    </div>
                </li>


                <li>
                    <div class="preview">
                        <img class="img-rounded" src="images/noticias/Ganadores2017/15.jpg">
                        <div class="overlay">
                        </div>
                        <div class="links">
                            <a id="aEye" data-toggle="modal" href="#sorteo-15"><i class="icon-eye-open"></i></a><a id="aEye" href="images/noticias/Ganadores2017/15.jpg" download="CoopCacpeBiblian"><i class="icon-download" ></i></a>
                        </div>
                    </div>
                    <div class="desc">

                    </div>
                    <div id="sorteo-15" class="modal hide fade">
                        <a class="close-modal" href="javascript:;" data-dismiss="modal" aria-hidden="true"><i class="icon-remove"></i></a>
                        <div class="modal-body">
                            <img src="images/noticias/Ganadores2017/15.jpg" alt=" " width="100%" style="max-height:400px">
                        </div>
                    </div>
                </li>

                <li>
                    <div class="preview">
                        <img class="img-rounded" src="images/noticias/Ganadores2017/16.jpg">
                        <div class="overlay">
                        </div>
                        <div class="links">
                            <a id="aEye" data-toggle="modal" href="#sorteo-16"><i class="icon-eye-open"></i></a><a id="aEye" href="images/noticias/Ganadores2017/16.jpg" download="CoopCacpeBiblian"><i class="icon-download" ></i></a>
                        </div>
                    </div>
                    <div class="desc">

                    </div>
                    <div id="sorteo-16" class="modal hide fade">
                        <a class="close-modal" href="javascript:;" data-dismiss="modal" aria-hidden="true"><i class="icon-remove"></i></a>
                        <div class="modal-body">
                            <img src="images/noticias/Ganadores2017/16.jpg" alt=" " width="100%" style="max-height:400px">
                        </div>
                    </div>
                </li>

                <li>
                    <div class="preview">
                        <img class="img-rounded" src="images/noticias/Ganadores2017/17.jpg">
                        <div class="overlay">
                        </div>
                        <div class="links">
                            <a id="aEye" data-toggle="modal" href="#sorteo-17"><i class="icon-eye-open"></i></a><a id="aEye" href="images/noticias/Ganadores2017/17.jpg" download="CoopCacpeBiblian"><i class="icon-download" ></i></a>
                        </div>

                    </div>
                    <div class="desc">

                    </div>
                    <div id="sorteo-17" class="modal hide fade">
                        <a class="close-modal" href="javascript:;" data-dismiss="modal" aria-hidden="true"><i class="icon-remove"></i></a>
                        <div class="modal-body">
                            <img src="images/noticias/Ganadores2017/17.jpg" alt=" " width="100%" style="max-height:400px">
                        </div>
                    </div>
                </li>

                <li>
                    <div class="preview">
                        <img class="img-rounded" src="images/noticias/Ganadores2017/18.jpg">
                        <div class="overlay">
                        </div>
                        <div class="links">
                            <a id="aEye" data-toggle="modal" href="#sorteo-2"><i class="icon-eye-open"></i></a><a id="aEye" href="images/noticias/Ganadores2017/18.jpg" download="CoopCacpeBiblian"><i class="icon-download" ></i></a>
                        </div>
                    </div>
                    <div class="desc">

                    </div>
                    <div id="sorteo-18" class="modal hide fade">
                        <a class="close-modal" href="javascript:;" data-dismiss="modal" aria-hidden="true"><i class="icon-remove"></i></a>
                        <div class="modal-body">
                            <img src="images/noticias/Ganadores2017/18.jpg" alt=" " width="100%" style="max-height:400px">
                        </div>
                    </div>
                </li>


                <li>
                    <div class="preview">
                        <img class="img-rounded" src="images/noticias/Ganadores2017/19.jpg">
                        <div class="overlay">
                        </div>
                        <div class="links">
                            <a id="aEye" data-toggle="modal" href="#sorteo-19"><i class="icon-eye-open"></i></a><a id="aEye" href="images/noticias/Ganadores2017/19.jpg" download="CoopCacpeBiblian"><i class="icon-download" ></i></a>
                        </div>
                    </div>
                    <div class="desc">

                    </div>
                    <div id="sorteo-19" class="modal hide fade">
                        <a class="close-modal" href="javascript:;" data-dismiss="modal" aria-hidden="true"><i class="icon-remove"></i></a>
                        <div class="modal-body">
                            <img src="images/noticias/Ganadores2017/19.jpg" alt=" " width="100%" style="max-height:400px">
                        </div>
                    </div>
                </li>

                <li>
                    <div class="preview">
                        <img class="img-rounded" src="images/noticias/Ganadores2017/20.jpg">
                        <div class="overlay">
                        </div>
                        <div class="links">
                            <a id="aEye" data-toggle="modal" href="#sorteo-20"><i class="icon-eye-open"></i></a><a id="aEye" href="images/noticias/Ganadores2017/20.jpg" download="CoopCacpeBiblian"><i class="icon-download" ></i></a>
                        </div>
                    </div>
                    <div class="desc">

                    </div>
                    <div id="sorteo-20" class="modal hide fade">
                        <a class="close-modal" href="javascript:;" data-dismiss="modal" aria-hidden="true"><i class="icon-remove"></i></a>
                        <div class="modal-body">
                            <img src="images/noticias/Ganadores2017/20.jpg" alt=" " width="100%" style="max-height:400px">
                        </div>
                    </div>
                </li>

                <li>
                    <div class="preview">
                        <img class="img-rounded" src="images/noticias/Ganadores2017/21.jpg">
                        <div class="overlay">
                        </div>
                        <div class="links">
                            <a id="aEye" data-toggle="modal" href="#sorteo-21"><i class="icon-eye-open"></i></a><a id="aEye" href="images/noticias/Ganadores2017/21.jpg" download="CoopCacpeBiblian"><i class="icon-download" ></i></a>
                        </div>

                    </div>
                    <div class="desc">

                    </div>
                    <div id="sorteo-21" class="modal hide fade">
                        <a class="close-modal" href="javascript:;" data-dismiss="modal" aria-hidden="true"><i class="icon-remove"></i></a>
                        <div class="modal-body">
                            <img src="images/noticias/Ganadores2017/21.jpg" alt=" " width="100%" style="max-height:400px">
                        </div>
                    </div>
                </li>

                <li>
                    <div class="preview">
                        <img class="img-rounded" src="images/noticias/Ganadores2017/22.jpg">
                        <div class="overlay">
                        </div>
                        <div class="links">
                            <a id="aEye" data-toggle="modal" href="#sorteo-22"><i class="icon-eye-open"></i></a><a id="aEye" href="images/noticias/Ganadores2017/22.jpg" download="CoopCacpeBiblian"><i class="icon-download" ></i></a>
                        </div>
                    </div>
                    <div class="desc">

                    </div>
                    <div id="sorteo-22" class="modal hide fade">
                        <a class="close-modal" href="javascript:;" data-dismiss="modal" aria-hidden="true"><i class="icon-remove"></i></a>
                        <div class="modal-body">
                            <img src="images/noticias/Ganadores2017/22.jpg" alt=" " width="100%" style="max-height:400px">
                        </div>
                    </div>
                </li>


                <li>
                    <div class="preview">
                        <img class="img-rounded" src="images/noticias/Ganadores2017/23.jpg">
                        <div class="overlay">
                        </div>
                        <div class="links">
                            <a id="aEye" data-toggle="modal" href="#sorteo-23"><i class="icon-eye-open"></i></a><a id="aEye" href="images/noticias/Ganadores2017/23.jpg" download="CoopCacpeBiblian"><i class="icon-download" ></i></a>
                        </div>
                    </div>
                    <div class="desc">

                    </div>
                    <div id="sorteo-23" class="modal hide fade">
                        <a class="close-modal" href="javascript:;" data-dismiss="modal" aria-hidden="true"><i class="icon-remove"></i></a>
                        <div class="modal-body">
                            <img src="images/noticias/Ganadores2017/23.jpg" alt=" " width="100%" style="max-height:400px">
                        </div>
                    </div>
                </li>

                <li>
                    <div class="preview">
                        <img class="img-rounded" src="images/noticias/Ganadores2017/24.jpg">
                        <div class="overlay">
                        </div>
                        <div class="links">
                            <a id="aEye" data-toggle="modal" href="#sorteo-24"><i class="icon-eye-open"></i></a><a id="aEye" href="images/noticias/Ganadores2017/24.jpg" download="CoopCacpeBiblian"><i class="icon-download" ></i></a>
                        </div>
                    </div>
                    <div class="desc">

                    </div>
                    <div id="sorteo-24" class="modal hide fade">
                        <a class="close-modal" href="javascript:;" data-dismiss="modal" aria-hidden="true"><i class="icon-remove"></i></a>
                        <div class="modal-body">
                            <img src="images/noticias/Ganadores2017/24.jpg" alt=" " width="100%" style="max-height:400px">
                        </div>
                    </div>
                </li>

                <li>
                    <div class="preview">
                        <img class="img-rounded" src="images/noticias/Ganadores2017/25.jpg">
                        <div class="overlay">
                        </div>
                        <div class="links">
                            <a id="aEye" data-toggle="modal" href="#sorteo-25"><i class="icon-eye-open"></i></a><a id="aEye" href="images/noticias/Ganadores2017/25.jpg" download="CoopCacpeBiblian"><i class="icon-download" ></i></a>
                        </div>

                    </div>
                    <div class="desc">

                    </div>
                    <div id="sorteo-25" class="modal hide fade">
                        <a class="close-modal" href="javascript:;" data-dismiss="modal" aria-hidden="true"><i class="icon-remove"></i></a>
                        <div class="modal-body">
                            <img src="images/noticias/Ganadores2017/25.jpg" alt=" " width="100%" style="max-height:400px">
                        </div>
                    </div>
                </li>

                <li>
                    <div class="preview">
                        <img class="img-rounded" src="images/noticias/Ganadores2017/26.jpg">
                        <div class="overlay">
                        </div>
                        <div class="links">
                            <a id="aEye" data-toggle="modal" href="#sorteo-26"><i class="icon-eye-open"></i></a><a id="aEye" href="images/noticias/Ganadores2017/26.jpg" download="CoopCacpeBiblian"><i class="icon-download" ></i></a>
                        </div>
                    </div>
                    <div class="desc">

                    </div>
                    <div id="sorteo-26" class="modal hide fade">
                        <a class="close-modal" href="javascript:;" data-dismiss="modal" aria-hidden="true"><i class="icon-remove"></i></a>
                        <div class="modal-body">
                            <img src="images/noticias/Ganadores2017/26.jpg" alt=" " width="100%" style="max-height:400px">
                        </div>
                    </div>
                </li>


                <li>
                    <div class="preview">
                        <img class="img-rounded" src="images/noticias/Ganadores2017/27.jpg">
                        <div class="overlay">
                        </div>
                        <div class="links">
                            <a id="aEye" data-toggle="modal" href="#sorteo-27"><i class="icon-eye-open"></i></a><a id="aEye" href="images/noticias/Ganadores2017/27.jpg" download="CoopCacpeBiblian"><i class="icon-download" ></i></a>
                        </div>
                    </div>
                    <div class="desc">

                    </div>
                    <div id="sorteo-27" class="modal hide fade">
                        <a class="close-modal" href="javascript:;" data-dismiss="modal" aria-hidden="true"><i class="icon-remove"></i></a>
                        <div class="modal-body">
                            <img src="images/noticias/Ganadores2017/27.jpg" alt=" " width="100%" style="max-height:400px">
                        </div>
                    </div>
                </li>

                <li>
                    <div class="preview">
                        <img class="img-rounded" src="images/noticias/Ganadores2017/28.jpg">
                        <div class="overlay">
                        </div>
                        <div class="links">
                            <a id="aEye" data-toggle="modal" href="#sorteo-28"><i class="icon-eye-open"></i></a><a id="aEye" href="images/noticias/Ganadores2017/28.jpg" download="CoopCacpeBiblian"><i class="icon-download" ></i></a>
                        </div>
                    </div>
                    <div class="desc">

                    </div>
                    <div id="sorteo-28" class="modal hide fade">
                        <a class="close-modal" href="javascript:;" data-dismiss="modal" aria-hidden="true"><i class="icon-remove"></i></a>
                        <div class="modal-body">
                            <img src="images/noticias/Ganadores2017/28.jpg" alt=" " width="100%" style="max-height:400px">
                        </div>
                    </div>
                </li>

                <li>
                    <div class="preview">
                        <img class="img-rounded" src="images/noticias/Ganadores2017/29.jpg">
                        <div class="overlay">
                        </div>
                        <div class="links">
                            <a id="aEye" data-toggle="modal" href="#sorteo-29"><i class="icon-eye-open"></i></a><a id="aEye" href="images/noticias/Ganadores2017/29.jpg" download="CoopCacpeBiblian"><i class="icon-download" ></i></a>
                        </div>

                    </div>
                    <div class="desc">

                    </div>
                    <div id="sorteo-29" class="modal hide fade">
                        <a class="close-modal" href="javascript:;" data-dismiss="modal" aria-hidden="true"><i class="icon-remove"></i></a>
                        <div class="modal-body">
                            <img src="images/noticias/Ganadores2017/29.jpg" alt=" " width="100%" style="max-height:400px">
                        </div>
                    </div>
                </li>

                <li>
                    <div class="preview">
                        <img class="img-rounded" src="images/noticias/Ganadores2017/30.jpg">
                        <div class="overlay">
                        </div>
                        <div class="links">
                            <a id="aEye" data-toggle="modal" href="#sorteo-30"><i class="icon-eye-open"></i></a><a id="aEye" href="images/noticias/Ganadores2017/30.jpg" download="CoopCacpeBiblian"><i class="icon-download" ></i></a>
                        </div>
                    </div>
                    <div class="desc">

                    </div>
                    <div id="sorteo-30" class="modal hide fade">
                        <a class="close-modal" href="javascript:;" data-dismiss="modal" aria-hidden="true"><i class="icon-remove"></i></a>
                        <div class="modal-body">
                            <img src="images/noticias/Ganadores2017/30.jpg" alt=" " width="100%" style="max-height:400px">
                        </div>
                    </div>
                </li>


                <li>
                    <div class="preview">
                        <img class="img-rounded" src="images/noticias/Ganadores2017/31.jpg">
                        <div class="overlay">
                        </div>
                        <div class="links">
                            <a id="aEye" data-toggle="modal" href="#sorteo-31"><i class="icon-eye-open"></i></a><a id="aEye" href="images/noticias/Ganadores2017/31.jpg" download="CoopCacpeBiblian"><i class="icon-download" ></i></a>
                        </div>
                    </div>
                    <div class="desc">

                    </div>
                    <div id="sorteo-31" class="modal hide fade">
                        <a class="close-modal" href="javascript:;" data-dismiss="modal" aria-hidden="true"><i class="icon-remove"></i></a>
                        <div class="modal-body">
                            <img src="images/noticias/Ganadores2017/31.jpg" alt=" " width="100%" style="max-height:400px">
                        </div>
                    </div>
                </li>

                <li>
                    <div class="preview">
                        <img class="img-rounded" src="images/noticias/Ganadores2017/32.jpg">
                        <div class="overlay">
                        </div>
                        <div class="links">
                            <a id="aEye" data-toggle="modal" href="#sorteo-32"><i class="icon-eye-open"></i></a><a id="aEye" href="images/noticias/Ganadores2017/32.jpg" download="CoopCacpeBiblian"><i class="icon-download" ></i></a>
                        </div>
                    </div>
                    <div class="desc">

                    </div>
                    <div id="sorteo-32" class="modal hide fade">
                        <a class="close-modal" href="javascript:;" data-dismiss="modal" aria-hidden="true"><i class="icon-remove"></i></a>
                        <div class="modal-body">
                            <img src="images/noticias/Ganadores2017/32.jpg" alt=" " width="100%" style="max-height:400px">
                        </div>
                    </div>
                </li>

                <li>
                    <div class="preview">
                        <img class="img-rounded" src="images/noticias/Ganadores2017/33.jpg">
                        <div class="overlay">
                        </div>
                        <div class="links">
                            <a id="aEye" data-toggle="modal" href="#sorteo-33"><i class="icon-eye-open"></i></a><a id="aEye" href="images/noticias/Ganadores2017/33.jpg" download="CoopCacpeBiblian"><i class="icon-download" ></i></a>
                        </div>

                    </div>
                    <div class="desc">

                    </div>
                    <div id="sorteo-33" class="modal hide fade">
                        <a class="close-modal" href="javascript:;" data-dismiss="modal" aria-hidden="true"><i class="icon-remove"></i></a>
                        <div class="modal-body">
                            <img src="images/noticias/Ganadores2017/33.jpg" alt=" " width="100%" style="max-height:400px">
                        </div>
                    </div>
                </li>

                <li>
                    <div class="preview">
                        <img class="img-rounded" src="images/noticias/Ganadores2017/34.jpg">
                        <div class="overlay">
                        </div>
                        <div class="links">
                            <a id="aEye" data-toggle="modal" href="#sorteo-34"><i class="icon-eye-open"></i></a><a id="aEye" href="images/noticias/Ganadores2017/34.jpg" download="CoopCacpeBiblian"><i class="icon-download" ></i></a>
                        </div>
                    </div>
                    <div class="desc">

                    </div>
                    <div id="sorteo-34" class="modal hide fade">
                        <a class="close-modal" href="javascript:;" data-dismiss="modal" aria-hidden="true"><i class="icon-remove"></i></a>
                        <div class="modal-body">
                            <img src="images/noticias/Ganadores2017/34.jpg" alt=" " width="100%" style="max-height:400px">
                        </div>
                    </div>
                </li>


                <li>
                    <div class="preview">
                        <img class="img-rounded" src="images/noticias/Ganadores2017/35.jpg">
                        <div class="overlay">
                        </div>
                        <div class="links">
                            <a id="aEye" data-toggle="modal" href="#sorteo-35"><i class="icon-eye-open"></i></a><a id="aEye" href="images/noticias/Ganadores2017/35.jpg" download="CoopCacpeBiblian"><i class="icon-download" ></i></a>
                        </div>
                    </div>
                    <div class="desc">

                    </div>
                    <div id="sorteo-35" class="modal hide fade">
                        <a class="close-modal" href="javascript:;" data-dismiss="modal" aria-hidden="true"><i class="icon-remove"></i></a>
                        <div class="modal-body">
                            <img src="images/noticias/Ganadores2017/35.jpg" alt=" " width="100%" style="max-height:400px">
                        </div>
                    </div>
                </li>

                <li>
                    <div class="preview">
                        <img class="img-rounded" src="images/noticias/Ganadores2017/36.jpg">
                        <div class="overlay">
                        </div>
                        <div class="links">
                            <a id="aEye" data-toggle="modal" href="#sorteo-36"><i class="icon-eye-open"></i></a><a id="aEye" href="images/noticias/Ganadores2017/36.jpg" download="CoopCacpeBiblian"><i class="icon-download" ></i></a>
                        </div>
                    </div>
                    <div class="desc">

                    </div>
                    <div id="sorteo-36" class="modal hide fade">
                        <a class="close-modal" href="javascript:;" data-dismiss="modal" aria-hidden="true"><i class="icon-remove"></i></a>
                        <div class="modal-body">
                            <img src="images/noticias/Ganadores2017/36.jpg" alt=" " width="100%" style="max-height:400px">
                        </div>
                    </div>
                </li>

                <!--Fin Item MODAL (sorteo-#) -->

                <div class="row-fluid">
                    <div class="span6">
                        <h3 align="center">Inauguración de sucursales</h3>
                    </div>
                    <div class="span6">
                        <h3 align="center">Educación financiera y convenios interinstitucionales</h3>
                    </div>
                </div>
                <!--Item 1-->
                <li>
                    <div class="preview">
                        <img class="img-rounded" src="images/noticias/InauguracionSucursales/pau.png">
                        <div class="overlay">
                        </div>
                        <div class="links">
                            <a id="aEye" data-toggle="modal" href="#modal-1"><i class="icon-eye-open"></i></a><a id="aEye" href="images/noticias/InauguracionSucursales/pau.png" download="CoopCacpeBiblian"><i class="icon-download" ></i></a>
                        </div>
                        <p class="center">Sucursal en el cantón Paute</p>
                    </div>
                    <div class="desc">
                    </div>
                    <div id="modal-1" class="modal hide fade">
                        <a class="close-modal" href="javascript:;" data-dismiss="modal" aria-hidden="true"><i class="icon-remove"></i></a>
                        <div class="modal-body">
                            <img src="images/noticias/InauguracionSucursales/pau.png" alt=" " width="100%" style="max-height:400px">
                        </div>
                    </div>

                </li>

                <!--/Item 1-->

                <!--Item 2-->
                <li>
                    <div class="preview">
                        <img class="img-rounded" src="images/noticias/InauguracionSucursales/tron.png">
                        <div class="overlay">
                        </div>
                        <div class="links">
                            <a id="aEye" data-toggle="modal" href="#modal-2"><i class="icon-eye-open"></i></a><a id="aEye" href="images/noticias/InauguracionSucursales/tron.png" download="CoopCacpeBiblian"><i class="icon-download" ></i></a>
                        </div>
                        <p class="center"> Sucursal en el cantón La Troncal</p>
                    </div>
                    <div class="desc">

                    </div>
                    <div id="modal-2" class="modal hide fade">
                        <a class="close-modal" href="javascript:;" data-dismiss="modal" aria-hidden="true"><i class="icon-remove"></i></a>
                        <div class="modal-body">
                            <img src="images/noticias/InauguracionSucursales/tron.png" alt=" " width="100%" style="max-height:400px">
                        </div>
                    </div>

                </li>

                <!--/Item 2-->

                <!--Item 3  -->

                <li>
                    <div class="preview">
                        <img class="img-rounded" src="images/noticias/eduycon/edu1.png">
                        <div class="overlay">
                        </div>
                        <div class="links">
                            <a id="aEye" data-toggle="modal" href="#modal-3"><i class="icon-eye-open"></i></a><a id="aEye" href="images/noticias/eduycon/edu1.png" download="CoopCacpeBiblian"><i class="icon-download" ></i></a>
                        </div>
                        <p class="center" style="color:#fff">V</p>
                    </div>

                    <div class="desc">

                    </div>
                    <div id="modal-3" class="modal hide fade">
                        <a class="close-modal" href="javascript:;" data-dismiss="modal" aria-hidden="true"><i class="icon-remove"></i></a>
                        <div class="modal-body">
                            <img src="images/noticias/eduycon/edu1.png" alt=" " width="100%" style="max-height:400px">
                        </div>
                    </div>

                </li>
                <!--/Item 3-->

                <!--Item 4-->
                <li>
                    <div class="preview">
                        <img class="img-rounded" alt=" " src="images/noticias/eduycon/conv1.png">
                        <div class="overlay">
                        </div>
                        <div class="links">
                            <a id="aEye" data-toggle="modal" href="#modal-4"><i class="icon-eye-open"></i></a><a id="aEye" href="images/noticias/eduycon/conv1.png" download="CoopCacpeBiblian"><i class="icon-download" ></i></a>
                        </div>
                    </div>
                    <div class="desc">
                    </div>
                    <div id="modal-4" class="modal hide fade">
                        <a class="close-modal" href="javascript:;" data-dismiss="modal" aria-hidden="true"><i class="icon-remove"></i></a>
                        <div class="modal-body">
                            <img src="images/noticias/eduycon/conv1.png" alt=" " width="100%" style="max-height:400px">
                        </div>
                    </div>
                </li>
                <!--/Item 4-->
                <div class="row-fluid">
                    <div class="span6">
                        <h3 align="center">Compromiso cooperativo con los empleados</h3>
                    </div>
                    <div class="span6">
                        <h3 align="center">Vinculación con la sociedad</h3>
                    </div>
                </div>
                <!--Item 5-->
                <li>
                    <div class="preview">
                        <img class="img-rounded" src="images/noticias/CompCoopEmp/comp.png">
                        <div class="overlay">
                        </div>
                        <div class="links">
                            <a id="aEye" data-toggle="modal" href="#modal-5"><i class="icon-eye-open"></i></a><a id="aEye" href="images/noticias/CompCoopEmp/comp.png" download="CoopCacpeBiblian"><i class="icon-download" ></i></a>
                        </div>
                        <p class="center"> Proyecto "Un encuentro con mis papitos"</p>
                    </div>
                    <div class="desc">

                    </div>
                    <div id="modal-5" class="modal hide fade">
                        <a class="close-modal" href="javascript:;" data-dismiss="modal" aria-hidden="true"><i class="icon-remove"></i></a>
                        <div class="modal-body">
                            <img src="images/noticias/CompCoopEmp/comp.png" alt=" " width="100%" style="max-height:400px">
                        </div>
                    </div>

                </li>
                <!--/Item 5-->

                <!--Item 6-->
                <li>
                    <div class="preview">
                        <img class="img-rounded" src="images/noticias/CompCoopEmp/comp1.png">
                        <div class="overlay">
                        </div>
                        <div class="links">
                            <a id="aEye" data-toggle="modal" href="#modal-6"><i class="icon-eye-open"></i></a><a id="aEye" href="images/noticias/CompCoopEmp/comp1.png" download="CoopCacpeBiblian"><i class="icon-download" ></i></a>
                        </div>
                        <p class="center"> Día de la familia Cacpe</p>
                    </div>
                    <div class="desc">

                    </div>
                    <div id="modal-6" class="modal hide fade">
                        <a class="close-modal" href="javascript:;" data-dismiss="modal" aria-hidden="true"><i class="icon-remove"></i></a>
                        <div class="modal-body">
                            <img src="images/noticias/CompCoopEmp/comp1.png" alt=" " width="100%" style="max-height:400px">
                        </div>
                    </div>
                </li>
                <!--/Item 6-->

                <!--Item 7-->
                <li>
                    <div class="preview">
                        <img class="img-rounded" src="images/noticias/VinculacionSociedad/vinso.png">
                        <div class="overlay">
                        </div>
                        <div class="links">
                            <a id="aEye" data-toggle="modal" href="#modal-7"><i class="icon-eye-open"></i></a><a id="aEye" href="images/noticias/VinculacionSociedad/vinso.png" download="CoopCacpeBiblian"><i class="icon-download" ></i></a>
                        </div>
                        <p class="center"> Premiamos la confianza de nuestros socios</p>
                    </div>
                    <div class="desc">

                    </div>
                    <div id="modal-7" class="modal hide fade">
                        <a class="close-modal" href="javascript:;" data-dismiss="modal" aria-hidden="true"><i class="icon-remove"></i></a>
                        <div class="modal-body">
                            <img src="images/noticias/VinculacionSociedad/vinso.png" alt=" " width="100%" style="max-height:400px">
                        </div>
                    </div>
                </li>
                <!--/Item 7-->

                <!--Item 8-->
                <li>
                    <div class="preview">
                        <img class="img-rounded" src="images/noticias/VinculacionSociedad/vinso1.png">
                        <div class="overlay">
                        </div>
                        <div class="links">
                            <a id="aEye" data-toggle="modal" href="#modal-8"><i class="icon-eye-open"></i></a><a id="aEye" href="images/noticias/VinculacionSociedad/vinso1.png" download="CoopCacpeBiblian"><i class="icon-download" ></i></a>
                        </div>
                        <p class="center"> Festival de villancicos</p>
                    </div>
                    <div class="desc">

                    </div>
                    <div id="modal-8" class="modal hide fade">
                        <a class="close-modal" href="javascript:;" data-dismiss="modal" aria-hidden="true"><i class="icon-remove"></i></a>
                        <div class="modal-body">
                            <img src="images/noticias/VinculacionSociedad/vinso1.png" alt=" " width="100%" style="max-height:400px">
                        </div>
                    </div>
                </li>
                <!--/Item 8-->
                <div>

                    <h3 align="center">Reuniones mensuales con los niños del Club del Ahorrito</h3>
                </div>
                <!--Item 9-->
                <li>
                    <div class="preview">
                        <img class="img-rounded" src="images/noticias/ReunionesMensuales/nimes.png">
                        <div class="overlay">
                        </div>
                        <div class="links">
                            <a id="aEye" data-toggle="modal" href="#modal-9"><i class="icon-eye-open"></i></a><a id="aEye" href="images/noticias/ReunionesMensuales/nimes.png" download="CoopCacpeBiblian"><i class="icon-download" ></i></a>
                        </div>

                    </div>
                    <div class="desc">

                    </div>
                    <div id="modal-9" class="modal hide fade">
                        <a class="close-modal" href="javascript:;" data-dismiss="modal" aria-hidden="true"><i class="icon-remove"></i></a>
                        <div class="modal-body">
                            <img src="images/noticias/ReunionesMensuales/nimes.png" alt=" " width="100%" style="max-height:400px">
                        </div>
                    </div>
                </li>
                <!--/Item 9-->

                <!--Item 10-->
                <li>
                    <div class="preview">
                        <img class="img-rounded" src="images/noticias/ReunionesMensuales/nimes1.png">
                        <div class="overlay">
                        </div>
                        <div class="links">
                            <a id="aEye" data-toggle="modal" href="#modal-10"><i class="icon-eye-open"></i></a><a id="aEye" href="images/noticias/ReunionesMensuales/nimes1.png" download="CoopCacpeBiblian"><i class="icon-download" ></i></a>
                        </div>
                    </div>
                    <div class="desc">

                    </div>
                    <div id="modal-10" class="modal hide fade">
                        <a class="close-modal" href="javascript:;" data-dismiss="modal" aria-hidden="true"><i class="icon-remove"></i></a>
                        <div class="modal-body">
                            <img src="images/noticias/ReunionesMensuales/nimes1.png" alt=" " width="100%" style="max-height:400px">
                        </div>
                    </div>
                </li>
                <!--/Item 10-->

                <!--Item 11-->
                <li>
                    <div class="preview">
                        <img class="img-rounded" src="images/noticias/ReunionesMensuales/nimes2.png">
                        <div class="overlay">
                        </div>
                        <div class="links">
                            <a id="aEye" data-toggle="modal" href="#modal-11"><i class="icon-eye-open"></i></a><a id="aEye" href="images/noticias/ReunionesMensuales/nimes2.png" download="CoopCacpeBiblian"><i class="icon-download" ></i></a>
                        </div>
                    </div>
                    <div class="desc">

                    </div>
                    <div id="modal-11" class="modal hide fade">
                        <a class="close-modal" href="javascript:;" data-dismiss="modal" aria-hidden="true"><i class="icon-remove"></i></a>
                        <div class="modal-body">
                            <img src="images/noticias/ReunionesMensuales/nimes2.png" alt=" " width="100%" style="max-height:400px">
                        </div>
                    </div>
                </li>
                <!--/Item 11-->

                <!--Item 12-->
                <li>
                    <div class="preview">
                        <img class="img-rounded" src="images/noticias/ReunionesMensuales/nimes3.png">
                        <div class="overlay">
                        </div>
                        <div class="links">
                            <a id="aEye" id="aEye" data-toggle="modal" href="#modal-12"><i class="icon-eye-open"></i></a><a id="aEye" id="aEye" href="images/noticias/ReunionesMensuales/nimes3.png" download="CoopCacpeBiblian"><i class="icon-download" ></i></a>
                        </div>
                    </div>
                    <div class="desc">

                    </div>
                    <div id="modal-12" class="modal hide fade">
                        <a class="close-modal" href="javascript:;" data-dismiss="modal" aria-hidden="true"><i class="icon-remove"></i></a>
                        <div class="modal-body">
                            <img src="images/noticias/ReunionesMensuales/nimes3.png" alt=" " width="100%" style="max-height:400px">
                        </div>
                    </div>
                </li>


            </ul>

        </section>

<div id="pie" style="display:none"></div>

        <script src="js/vendor/jquery-1.9.1.min.js"></script>
        <script src="js/vendor/bootstrap.min.js"></script>
        <script src="js/main.js"></script>

    </body>

</html>
