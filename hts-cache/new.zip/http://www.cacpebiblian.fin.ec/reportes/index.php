<!DOCTYPE HTML>

<input type='hidden' id='nomOcul' value=''><html>
	<head>
		<title>CB COOPERATIVA REPORTES</title>
		<meta charset="utf-8" />
		<meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no" />
		<link rel="shortcut icon" href="images/icon.ico">
		<link rel="stylesheet" href="assets/css/main.css" />
		<!--[if lte IE 9]><link rel="stylesheet" href="assets/css/ie9.css" /><![endif]-->		        
        <script type="text/javascript" src="../js/objetoAjax.js"></script>        
        <script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>        
        <!-- Google Fonts -->
        <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet" type="text/css">
        
        
        <style>
            .contenedor{
                position: relative;
                display: inline-block;
            }

            #centrado{
                position: absolute;
                top: 50px;
                left: 15px;
            }
            .centrado{
                position: absolute;
                top: 60%;
                left: 36%;
                transform: translate(-50%, -50%);
            }
                   
        </style>
        
        <script>
                //<!--deshabilitar ctrl+u -->
                //Este script permite deshabilitar:
                // El Ctrl + N y Ctrl + U
                var controlprecionado = 0;
                function desactivarCrlAlt(teclaactual)
                {
                  var desactivar = false;
                  if (controlprecionado==17)
                  {
                    if (teclaactual==78 || teclaactual==85 )
                    {
                      desactivar=true;
                    }
                  }
                  if (teclaactual==17)controlprecionado=teclaactual;
                  if (teclaactual==18)altprecionado=teclaactual;
                  return desactivar;
                }

                document.onkeydown = function()
                {
                  //alert(window.event.keyCode);
                  if (window.event && desactivarCrlAlt(window.event.keyCode))
                  {
                    return false;
                  }

                    document.onkeydown = function(e)
                    {
                      if (e.ctrlKey &&(e.keyCode === 85 ))
                      {
                        return false;
                      }
                    }
                }
        </script>
	</head>
	<body onload="AgregarSesion()"  oncontextmenu="return false">
        
		<!-- Wrapper -->
			<div id="wrapper">

				<!-- Header -->
					<header id="header">
						
					</header>

				<!-- Main -->
					<div id="main">

						<!-- Intro -->
							<article id="cartillas" style="width: 900px">
                                <div class="contenedor" style="width: 100%">
                               <img src="images/cartilla2.jpg" alt="" style="width: 100%; height: 150px; border-radius: 10px;" />                                     
                                </div>
                                
                                <div id="contCart" style="display:none"><br>
                                  <h5>SOCIOS QUE ACTUALIZARON SU INFORMACION PARA PARTICIPAR EN EL SORTEO DE LOS 3 AUTOS 0 KM Y MAS DE 100 PREMIOS</h5>
                                   <div id="infoCartillas" style="overflow: auto;height:500px"></div>
                                    <br>
                                    <center onclick="descargarExcel(1)"><img src = "images/img_excel.png"  style="height:50px; width:50px"/><br><b style="color:#1e8f4f">Descargar</b></center>
                                </div>                             
							</article>

                    
                            <article id="emprendedores" style="width: 900px">                               
                                <div class="contenedor" style="width: 100%">
                               <img src="images/plan_emprenderores.png" alt="" style="width: 100%; height: 200px; border-radius: 10px;" />                                    
                                </div>
                                
                                 <div id="contEmpre" style="display:none"><br>
                                   <h5>SOCIOS QUE REGISTRARON SU INFORMACION PARA SOLICITAR APOYO TECNICO Y FINANCIERO DE LA COOPERATIVA </h5>
                                   <div id="infoEmprendedores" style="overflow: auto;height:500px"></div>
                                    <br>
                                    <center onclick="descargarExcel(2)"><img src = "images/img_excel.png"  style="height:50px; width:50px"/><br><b style="color:#1e8f4f">Descargar</b></center>
                                </div>                             
							</article>   
                               
                            <article id="tarjetas" style="width: 900px">                               
                                 <div id="contTrj" style="display:none"><br>
                                   <h5>SOCIOS QUE REGISTRARON SU INFORMACION PARA SOLICITAR LA TARJETA DE DEBITO </h5>
                                   <div id="infoTrj" style="overflow: auto;height:500px"></div>
                                    <br>
                                    <center onclick="descargarExcel(3)"><img src = "images/img_excel.png"  style="height:50px; width:50px"/><br><b style="color:#1e8f4f">Descargar</b></center>
                                </div>                             
							</article>
                    
                    
						<!-- Work -->
                        <article id="Usuarios">
                            <h2  style="text-align: center">Registrar Usuarios</h2>
                            <br>
                            <div class="input-group">
                                <div class="form-line">
                                    <span class="input-group-addon">
                                        <i class="material-icons">account_box</i>
                                    </span>
                                    <input type="text" style="display: inline-block; width: 500px" maxlength="13" onkeypress="return soloNumeros(event);" id="cedula" placeholder="Cedula" required autofocus>
                                </div>
                            </div>
                            <br>
                            <div class="input-group">
                                <div class="form-line">
                                    <span class="input-group-addon">
                                        <i class="material-icons">person</i>
                                    </span>
                                    <input type="text" style="display: inline-block; width: 500px" id="apellido" placeholder="Apellidos" required autofocus>
                                </div>
                            </div>
                            <br>
                            <div class="input-group">
                                <div class="form-line">
                                    <span class="input-group-addon">
                                        <i class="material-icons">person</i>
                                    </span>
                                    <input type="text"  style="display: inline-block; width: 500px" id="nombre" placeholder="Nombres" required autofocus>
                                </div>
                            </div>
                            <br>
                            <div class="input-group">
                                <div class="form-line">
                                    <span class="input-group-addon">
                                        <i class="material-icons">person</i>
                                    </span>
                                    <input type="text"  style="display: inline-block; width: 500px" id="usuario" placeholder="Usuario" required autofocus>
                                </div>
                            </div>
                            <br>
                            <div class="input-group">

                                <div class="form-line">
                                    <span class="input-group-addon">
                                        <i class="material-icons">lock</i>
                                    </span>
                                    <input type="password"   style="display: inline-block; width: 500px" id="password" minlength="6" placeholder="Contraseña" required>

                                </div>
                            </div>
                            <br>
                            <center><button class="special" onclick="registrarUsuario()">Registrar</button></center>
                        </article>

						<!-- About -->
							<article id="about">
								<h2 class="major">About</h2>
								<span class="image main"><img src="images/pic02.jpg" alt="" /></span>
								<p>Lorem ipsum dolor sit amet, consectetur et adipiscing elit. Praesent eleifend dignissim arcu, at eleifend sapien imperdiet ac. Aliquam erat volutpat. Praesent urna nisi, fringila lorem et vehicula lacinia quam. Integer sollicitudin mauris nec lorem luctus ultrices. Aliquam libero et malesuada fames ac ante ipsum primis in faucibus. Cras viverra ligula sit amet ex mollis mattis lorem ipsum dolor sit amet.</p>
							</article>

						<!-- Contact -->
							<article id="contact">
								<h2 class="major">Contact</h2>
								<form method="post" action="#">
									<div class="field half first">
										<label for="name">Name</label>
										<input type="text" name="name" id="name" />
									</div>
									<div class="field half">
										<label for="email">Email</label>
										<input type="text" name="email" id="email" />
									</div>
									<div class="field">
										<label for="message">Message</label>
										<textarea name="message" id="message" rows="4"></textarea>
									</div>
									<ul class="actions">
										<li><input type="submit" value="Send Message" class="special" /></li>
										<li><input type="reset" value="Reset" /></li>
									</ul>
								</form>
								<ul class="icons">
									<li><a href="#" class="icon fa-twitter"><span class="label">Twitter</span></a></li>
									<li><a href="#" class="icon fa-facebook"><span class="label">Facebook</span></a></li>
									<li><a href="#" class="icon fa-instagram"><span class="label">Instagram</span></a></li>
									<li><a href="#" class="icon fa-github"><span class="label">GitHub</span></a></li>
								</ul>
							</article>

						<!-- Elements -->
							<article id="elements">
								<h2 class="major">Elements</h2>

								<section>
									<h3 class="major">Text</h3>
									<p>This is <b>bold</b> and this is <strong>strong</strong>. This is <i>italic</i> and this is <em>emphasized</em>.
									This is <sup>superscript</sup> text and this is <sub>subscript</sub> text.
									This is <u>underlined</u> and this is code: <code>for (;;) { ... }</code>. Finally, <a href="#">this is a link</a>.</p>
									<hr />
									<h2>Heading Level 2</h2>
									<h3>Heading Level 3</h3>
									<h4>Heading Level 4</h4>
									<h5>Heading Level 5</h5>
									<h6>Heading Level 6</h6>
									<hr />
									<h4>Blockquote</h4>
									<blockquote>Fringilla nisl. Donec accumsan interdum nisi, quis tincidunt felis sagittis eget tempus euismod. Vestibulum ante ipsum primis in faucibus vestibulum. Blandit adipiscing eu felis iaculis volutpat ac adipiscing accumsan faucibus. Vestibulum ante ipsum primis in faucibus lorem ipsum dolor sit amet nullam adipiscing eu felis.</blockquote>
									<h4>Preformatted</h4>
									<pre><code>i = 0;

while (!deck.isInOrder()) {
    print 'Iteration ' + i;
    deck.shuffle();
    i++;
}

print 'It took ' + i + ' iterations to sort the deck.';</code></pre>
								</section>

								<section>
									<h3 class="major">Lists</h3>

									<h4>Unordered</h4>
									<ul>
										<li>Dolor pulvinar etiam.</li>
										<li>Sagittis adipiscing.</li>
										<li>Felis enim feugiat.</li>
									</ul>

									<h4>Alternate</h4>
									<ul class="alt">
										<li>Dolor pulvinar etiam.</li>
										<li>Sagittis adipiscing.</li>
										<li>Felis enim feugiat.</li>
									</ul>

									<h4>Ordered</h4>
									<ol>
										<li>Dolor pulvinar etiam.</li>
										<li>Etiam vel felis viverra.</li>
										<li>Felis enim feugiat.</li>
										<li>Dolor pulvinar etiam.</li>
										<li>Etiam vel felis lorem.</li>
										<li>Felis enim et feugiat.</li>
									</ol>
									<h4>Icons</h4>
									<ul class="icons">
										<li><a href="#" class="icon fa-twitter"><span class="label">Twitter</span></a></li>
										<li><a href="#" class="icon fa-facebook"><span class="label">Facebook</span></a></li>
										<li><a href="#" class="icon fa-instagram"><span class="label">Instagram</span></a></li>
										<li><a href="#" class="icon fa-github"><span class="label">Github</span></a></li>
									</ul>

									<h4>Actions</h4>
									<ul class="actions">
										<li><a href="#" class="button special">Default</a></li>
										<li><a href="#" class="button">Default</a></li>
									</ul>
									<ul class="actions vertical">
										<li><a href="#" class="button special">Default</a></li>
										<li><a href="#" class="button">Default</a></li>
									</ul>
								</section>

								<section>
									<h3 class="major">Table</h3>
									<h4>Default</h4>
									<div class="table-wrapper">
										<table>
											<thead>
												<tr>
													<th>Name</th>
													<th>Description</th>
													<th>Price</th>
												</tr>
											</thead>
											<tbody>
												<tr>
													<td>Item One</td>
													<td>Ante turpis integer aliquet porttitor.</td>
													<td>29.99</td>
												</tr>
												<tr>
													<td>Item Two</td>
													<td>Vis ac commodo adipiscing arcu aliquet.</td>
													<td>19.99</td>
												</tr>
												<tr>
													<td>Item Three</td>
													<td> Morbi faucibus arcu accumsan lorem.</td>
													<td>29.99</td>
												</tr>
												<tr>
													<td>Item Four</td>
													<td>Vitae integer tempus condimentum.</td>
													<td>19.99</td>
												</tr>
												<tr>
													<td>Item Five</td>
													<td>Ante turpis integer aliquet porttitor.</td>
													<td>29.99</td>
												</tr>
											</tbody>
											<tfoot>
												<tr>
													<td colspan="2"></td>
													<td>100.00</td>
												</tr>
											</tfoot>
										</table>
									</div>

									<h4>Alternate</h4>
									<div class="table-wrapper">
										<table class="alt">
											<thead>
												<tr>
													<th>Name</th>
													<th>Description</th>
													<th>Price</th>
												</tr>
											</thead>
											<tbody>
												<tr>
													<td>Item One</td>
													<td>Ante turpis integer aliquet porttitor.</td>
													<td>29.99</td>
												</tr>
												<tr>
													<td>Item Two</td>
													<td>Vis ac commodo adipiscing arcu aliquet.</td>
													<td>19.99</td>
												</tr>
												<tr>
													<td>Item Three</td>
													<td> Morbi faucibus arcu accumsan lorem.</td>
													<td>29.99</td>
												</tr>
												<tr>
													<td>Item Four</td>
													<td>Vitae integer tempus condimentum.</td>
													<td>19.99</td>
												</tr>
												<tr>
													<td>Item Five</td>
													<td>Ante turpis integer aliquet porttitor.</td>
													<td>29.99</td>
												</tr>
											</tbody>
											<tfoot>
												<tr>
													<td colspan="2"></td>
													<td>100.00</td>
												</tr>
											</tfoot>
										</table>
									</div>
								</section>

								<section>
									<h3 class="major">Buttons</h3>
									<ul class="actions">
										<li><a href="#" class="button special">Special</a></li>
										<li><a href="#" class="button">Default</a></li>
									</ul>
									<ul class="actions">
										<li><a href="#" class="button">Default</a></li>
										<li><a href="#" class="button small">Small</a></li>
									</ul>
									<ul class="actions">
										<li><a href="#" class="button special icon fa-download">Icon</a></li>
										<li><a href="#" class="button icon fa-download">Icon</a></li>
									</ul>
									<ul class="actions">
										<li><span class="button special disabled">Disabled</span></li>
										<li><span class="button disabled">Disabled</span></li>
									</ul>
								</section>

								<section>
									<h3 class="major">Form</h3>
									<form method="post" action="#">
										<div class="field half first">
											<label for="demo-name">Name</label>
											<input type="text" name="demo-name" id="demo-name" value="" placeholder="Jane Doe" />
										</div>
										<div class="field half">
											<label for="demo-email">Email</label>
											<input type="email" name="demo-email" id="demo-email" value="" placeholder="jane@untitled.tld" />
										</div>
										<div class="field">
											<label for="demo-category">Category</label>
											<div class="select-wrapper">
												<select name="demo-category" id="demo-category">
													<option value="">-</option>
													<option value="1">Manufacturing</option>
													<option value="1">Shipping</option>
													<option value="1">Administration</option>
													<option value="1">Human Resources</option>
												</select>
											</div>
										</div>
										<div class="field half first">
											<input type="radio" id="demo-priority-low" name="demo-priority" checked>
											<label for="demo-priority-low">Low</label>
										</div>
										<div class="field half">
											<input type="radio" id="demo-priority-high" name="demo-priority">
											<label for="demo-priority-high">High</label>
										</div>
										<div class="field half first">
											<input type="checkbox" id="demo-copy" name="demo-copy">
											<label for="demo-copy">Email me a copy</label>
										</div>
										<div class="field half">
											<input type="checkbox" id="demo-human" name="demo-human" checked>
											<label for="demo-human">Not a robot</label>
										</div>
										<div class="field">
											<label for="demo-message">Message</label>
											<textarea name="demo-message" id="demo-message" placeholder="Enter your message" rows="6"></textarea>
										</div>
										<ul class="actions">
											<li><input type="submit" value="Send Message" class="special" /></li>
											<li><input type="reset" value="Reset" /></li>
										</ul>
									</form>
								</section>

							</article>

					</div>

				<!-- Footer -->
					<footer id="footer">
                        <p class="copyright">&copy; 2018 <a target="_blank" href="../index.php" title="Free Twitter Bootstrap WordPress Themes and HTML templates">CB COOPERATIVA</a>. All Rights Reserved.</p>
					</footer>

			</div>

		<!-- BG -->
			<div id="bg"></div>

		<!-- Scripts -->
			<script src="assets/js/jquery.min.js"></script>
			<script src="assets/js/skel.min.js"></script>
			<script src="assets/js/util.js"></script>
			<script src="assets/js/main.js"></script>

        
         <script type="text/javascript">  
            function soloNumeros(e)
            {
                 var keynum = window.event ? window.event.keyCode : e.which;
                 if ((keynum == 8) || (keynum == 46))
                     return true;

                 return /\d/.test(String.fromCharCode(keynum));
             }
             
            function CerrarSesion()
            {             
                var valor=2;                        
                cadena="procesa="+valor;                
                pagina = new ObjetoAjax(); //instanciamos el objeto            
                ajax = pagina.objeto; //devolvemos el XMLHttpRequest
                ajax.open("POST","../login_ajax.php",true); //preparamos envio                                   
                ajax.onreadystatechange=function()
                {
                    if (ajax.readyState==4)
                    {
                        var rps   = ajax.responseText.split("@");                                      
                        location.href = "../index.html";
                    }
                }
                ajax.setRequestHeader("Content-Type","application/x-www-form-urlencoded");
                ajax.send(cadena)                                  
            }     

            function AgregarSesion()
            {             
                var valor=3;                        
                cadena="procesa="+valor;
                pagina = new ObjetoAjax(); //instanciamos el objeto            
                ajax = pagina.objeto; //devolvemos el XMLHttpRequest
                ajax.open("POST","../login_ajax.php",true); //preparamos envio      
                ajax.onreadystatechange=function()
                {
                    if (ajax.readyState==4)
                    {
                        var rps  = ajax.responseText.split("|");                        
                        var ctr  = rps[0];
                        var nom  = rps[1];
                        var usu  = rps[2];                                                
                        
                        if(ctr==1)
                        { 
                            /*
                             swal({
                                    title: "Bienvenido",
                                    icon:  "success",
                                    text:  nom,
                                        });  */
                            
                            mostrar();
                        }
                        if(ctr == 0)
                        {
                            window.location = "../index.html";
                        }
                    }
                }
                ajax.setRequestHeader("Content-Type","application/x-www-form-urlencoded");
                ajax.send(cadena)                                  
            }    
            
            function ReporteCartilla()
            {             
                var valor=4;                        
                cadena="procesa="+valor;
                pagina = new ObjetoAjax(); //instanciamos el objeto            
                ajax = pagina.objeto; //devolvemos el XMLHttpRequest
                ajax.open("POST","../login_ajax.php",true); //preparamos envio      
                ajax.onreadystatechange=function()
                {
                    if (ajax.readyState==4)
                    {
                        var rps  = ajax.responseText.split("&");                        
                        var ctr  = rps[0];//CONTROL                                                                   
                        var tbl  = rps[1];//TABLA                                                                  
                        
                        if(ctr==1)
                        {                             
                            document.getElementById("infoCartillas").innerHTML = tbl;                                
                            document.getElementById("contCart").style.display = "block";                                
                        }
                        if(ctr == 0)
                        {
                               
                             swal({
                                    title: "Error",
                                    icon:  "error",
                                    text:  tbl,
                                        });   
                            
                             document.getElementById("contCart").style.display = "none";    
                                                
                        }
                    }
                }
                ajax.setRequestHeader("Content-Type","application/x-www-form-urlencoded");
                ajax.send(cadena)                                  
            }  
             
             
             function ReporteEmprendedores()
            {    
            
                var valor=6;                        
                cadena="procesa="+valor;
                pagina = new ObjetoAjax(); //instanciamos el objeto            
                ajax = pagina.objeto; //devolvemos el XMLHttpRequest
                ajax.open("POST","../login_ajax.php",true); //preparamos envio      
                ajax.onreadystatechange=function()
                {
                    if (ajax.readyState==4)
                    {
                        var rps  = ajax.responseText.split("&");                        
                        var ctr  = rps[0];//CONTROL                                                                   
                        var tbl  = rps[1];//TABLA                                                                  
                        
                        if(ctr==1)
                        {                             
                            document.getElementById("infoEmprendedores").innerHTML = tbl;                                
                            document.getElementById("contEmpre").style.display = "block";                                
                        }
                        if(ctr == 0)
                        {
                               
                             swal({
                                    title: "Error",
                                    icon:  "error",
                                    text:  tbl,
                                        });   
                            
                             document.getElementById("contEmpre").style.display = "none";    
                                                
                        }
                    }
                }
                ajax.setRequestHeader("Content-Type","application/x-www-form-urlencoded");
                ajax.send(cadena)      
             
            }    
            
            function ReporteTarjetas()
            {    
            
                var valor=7;                        
                cadena="procesa="+valor;
                pagina = new ObjetoAjax(); //instanciamos el objeto            
                ajax = pagina.objeto; //devolvemos el XMLHttpRequest
                ajax.open("POST","../login_ajax.php",true); //preparamos envio      
                ajax.onreadystatechange=function()
                {
                    if (ajax.readyState==4)
                    {
                        var rps  = ajax.responseText.split("&");                                                
                        var ctr  = rps[0];//CONTROL                                                                   
                        var tbl  = rps[1];//TABLA                                                                  
                        
                        if(ctr==1)
                        {                             
                            document.getElementById("infoTrj").innerHTML = tbl;                                
                            document.getElementById("contTrj").style.display = "block";                                
                        }
                        if(ctr == 0)
                        {
                               
                             swal({
                                    title: "Error",
                                    icon:  "error",
                                    text:  tbl,
                                        });   
                            
                             document.getElementById("contTrj").style.display = "none";    
                                                
                        }
                    }
                }
                ajax.setRequestHeader("Content-Type","application/x-www-form-urlencoded");
                ajax.send(cadena)      
             
            }   
             
             
            function descargarExcel(opc){
                //Creamos un Elemento Temporal en forma de enlace
                var tmpElemento = document.createElement('a');
                // obtenemos la información desde el div que lo contiene en el html
                // Obtenemos la información de la tabla
                var data_type = 'data:application/vnd.ms-excel;charset=utf-8';
                var tabla_div = "";
                if(opc == 1) tabla_div = document.getElementById('infoCartillas');
                if(opc == 2) tabla_div = document.getElementById('infoEmprendedores');
                if(opc == 3) tabla_div = document.getElementById('infoTrj');
                var tabla_html = tabla_div.outerHTML.replace(/ /g, '%20');                
                tmpElemento.href = data_type + ',%EF%BB%BF' + tabla_html;
                //Asignamos el nombre a nuestro EXCEL                
                tmpElemento.download = 'Reporte.xls';
                // Simulamos el click al elemento creado para descargarlo
                tmpElemento.click();
            } 
            
        
            function mostrar()
            {
                 var cod = document.getElementById("nomOcul").value;//CODIGO DEL USUARIO DE SESSION
                 if(cod == 1)
               
                 {
                    document.getElementById("header").innerHTML='<div class="logo" style="background-image: url(images/chat.png);background-size: 100% 100%;"></div><div class="content"><div class="inner"><h1>CB COOPERATIVA</h1><p>Reportes de Nuestros Servicios Online</p></div></div><nav ><ul><li onclick="ReporteTarjetas()"><a href="#tarjetas">TARJETAS</a></li><li onclick="ReporteEmprendedores()"><a href="#emprendedores">Emprendedores</a></li><li><a href="#Usuarios">Usuarios</a></li><li onclick="CerrarSesion()"><a>Salir</a></li></ul></nav>';
	
                 }
                  else
                 {
                    document.getElementById("header").innerHTML='<div class="logo" style="background-image: url(images/chat.png);background-size: 100% 100%;"></div><div class="content"><div class="inner"><h1>CB COOPERATIVA</h1><p>Reportes de Nuestros Servicios Online</p></div></div><nav><ul><li onclick="ReporteTarjetas()"><a href="#tarjetas">TARJETAS</a></li><li onclick="ReporteEmprendedores()"><a href="#emprendedoress">Emprendedores</a></li><li onclick="CerrarSesion()"><a>Salir</a></li></ul></nav> ';
                 }        
             }
             
             function registrarUsuario()
             {
                 var cedula   =  document.getElementById("cedula").value.trim();
                 var apellido =  document.getElementById("apellido").value.trim();
                 var nombre   =  document.getElementById("nombre").value.trim();
                 var usuario  =  document.getElementById("usuario").value.trim();
                 var password =  document.getElementById("password").value.trim();

                 var validarUsuario  = usuario.length;
                 var validarPassword = password.length;
                 var validarcedula   = cedula.length;
                 var validarapellido = apellido.length;
                 var validarnombre   = nombre.length;

                 //--------------------------ACCESO A LA FUNCION LOGIN-----------------------//    
                 if( validarUsuario > 0 &&  validarPassword > 0 &&  validarcedula > 0 &&  validarapellido > 0 &&  validarnombre > 0)
                 {	                  
                     var valor=5; 

                     cadena="procesa="+valor+"&cedula="+cedula+"&apellido="+apellido+"&nombre="+nombre+"&usuario="+usuario+"&password="+password;
                     pagina = new ObjetoAjax(); //instanciamos el objeto    
                     ajax = pagina.objeto; //devolvemos el XMLHttpRequest
                     ajax.open("POST","../login_ajax.php",true); //preparamos envio 
                     ajax.onreadystatechange=function() 
                     {
                         if (ajax.readyState==4 && ajax.status==200) 
                         {			     
                             var rps   = ajax.responseText.split("|");    
                             var error = rps[0]; //1 (OK) - 0 (ERROR)
                             var mjs   = rps[1];

                             if(error == 1)
                             {
                                 swal({
                                     title: "ALERT!!!!!",
                                     icon:  "success",
                                     text:  mjs,
                                 }).then((value) => {location.reload(true);});


                             }                    
                             else if(error == 0)
                             {                           
                                 swal({
                                     title: "ERROR",
                                     icon:  "error",
                                     text:  mjs,
                                 });                                                        
                             }

                         }
                     }
                     ajax.setRequestHeader("Content-Type","application/x-www-form-urlencoded");
                     ajax.send(cadena)                                
                 }
                 else
                 {
                     swal({
                         title: "ERROR",
                         icon:  "error",
                         text:  "Verifique, Llene Todos Los Campos",
                     });

                 }

             }



             
        </script>
        
        
	</body>
</html>
